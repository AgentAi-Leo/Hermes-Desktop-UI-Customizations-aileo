# Briefs V26 — pointer-only volume, full cumulative refinement

**Use this package only. Do not apply V24 or V25.**

V26 applies directly to the existing V23 isolated preview and includes all requested visual/Stock refinements plus the final AI input contract:

- Volume can change only through direct mouse/pointer interaction with the slider.
- The slider is removed from keyboard tab order.
- Every keyboard event at the slider is suppressed before a browser-native range action can occur.
- Arrow Left/Right/Up and Space remain AI player commands through a capture-phase player listener.
- Initial AI commands are queued until the archive iframe is ready.

## Prerequisite

The isolated preview already has V23 installed. This installer does not touch production `9119`.

## Apply

```bash
bash /absolute/path/to/v26-pointer-only-volume/scripts/apply-v26.sh \
  "$HOME/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW"
```

The installer snapshots all managed files before patching and supports both Git checkouts and non-Git source exports.
