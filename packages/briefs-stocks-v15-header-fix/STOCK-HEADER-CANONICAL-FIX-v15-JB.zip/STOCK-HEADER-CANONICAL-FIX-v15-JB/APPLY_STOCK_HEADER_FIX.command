#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
PREVIEW="${HERMES_PREVIEW_ROOT:-$HOME/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
AGENT_ROOT="${HERMES_AGENT_ROOT:-/Users/jb3/.hermes/hermes-agent}"
PYTHON="${HERMES_PYTHON:-$AGENT_ROOT/venv/bin/python}"
WEB="$PREVIEW/web"
DIST="$PREVIEW/hermes_cli/web_dist"
SOURCE="$WEB/src/lib/briefs.ts"
TEST="$WEB/src/lib/briefs.test.ts"
PAGE="$WEB/src/pages/BriefsPage.tsx"
PORT="${HERMES_PREVIEW_PORT:-9120}"
PROFILE="local-ai-assist1"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/.hermes/backups/stock-header-canonical-fix-v15-$STAMP"
LOG="$HOME/.hermes/logs/stock-header-canonical-fix-v15-${PORT}.log"
OLD_SOURCE_SHA="e477e995f2f750fa6cb9ab051ef72b2961d25f65a74d113e0e2fcc691567e894"
NEW_SOURCE_SHA="486b516a5290f7b4ab44e734cf1e837ebedc190242942553b3418daa91f4ce87"
AUDITED_TEST_SHA="398e94979304caa9f6693c7978c8b141b352dc41f983d9f4f9e5bc2b717fedbf"
CANDIDATE_TEST_SHA="398e94979304caa9f6693c7978c8b141b352dc41f983d9f4f9e5bc2b717fedbf"
NEW_TEST_SHA="6f0613d409f45526f97bdececddba0fd974b34d555c84aee71cdd3bb76be8b40"
PAGE_SHA="8e4473ac81ca9104c8fb55b999a2fb476f3ff601ca7c5c086b7aa26ccbf9116d"
MARKER="v15-canonical-stock-header"
BACKUP_READY=0
SERVER_TOUCHED=0

sha256_file() { shasum -a 256 "$1" | cut -d ' ' -f 1; }
stop_preview() {
  local pids i
  pids="$(lsof -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true)"
  if [[ -n "$pids" ]]; then
    kill $pids 2>/dev/null || true
    for i in $(seq 1 50); do
      [[ -z "$(lsof -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true)" ]] && return 0
      sleep 0.1
    done
    pids="$(lsof -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true)"
    [[ -z "$pids" ]] || kill -9 $pids 2>/dev/null || true
  fi
}
start_preview() {
  mkdir -p "$(dirname "$LOG")"
  (cd "$PREVIEW" && nohup env PYTHONPATH="$PREVIEW" HERMES_WEB_DIST="$DIST" "$PYTHON" -m hermes_cli.main --profile "$PROFILE" dashboard --isolated --port "$PORT" --no-open >"$LOG" 2>&1 &)
}
wait_preview() {
  local i
  for i in $(seq 1 60); do
    curl -fsS "http://127.0.0.1:$PORT/" >/dev/null 2>&1 && return 0
    sleep 1
  done
  return 1
}
restore_after_failure() {
  if [[ "$BACKUP_READY" == "1" ]]; then
    cp "$BACKUP/briefs.ts" "$SOURCE"
    cp "$BACKUP/briefs.test.ts" "$TEST"
    rm -rf "$DIST"
    cp -R "$BACKUP/web_dist" "$DIST"
    if [[ "$SERVER_TOUCHED" == "1" ]]; then
      stop_preview || true
      start_preview || true
      wait_preview || true
    fi
    echo "RESTORED_AFTER_FAILURE=$BACKUP" >&2
  fi
}
trap 'r=$?; if [[ $r -ne 0 ]]; then restore_after_failure; fi; exit $r' EXIT

for required in "$ROOT/CHECKSUMS.sha256" "$ROOT/SOURCE/briefs.ts" "$ROOT/SOURCE/briefs.test.ts" "$PYTHON" "$SOURCE" "$TEST" "$PAGE" "$WEB/package.json" "$DIST/index.html"; do
  [[ -e "$required" ]] || { echo "Missing required path: $required" >&2; exit 1; }
done
[[ -x "$PYTHON" ]] || { echo "Hermes Python is not executable: $PYTHON" >&2; exit 1; }
(cd "$ROOT" && shasum -a 256 -c CHECKSUMS.sha256)
[[ "$(sha256_file "$ROOT/SOURCE/briefs.ts")" == "$NEW_SOURCE_SHA" ]] || { echo "Packaged briefs.ts checksum mismatch" >&2; exit 1; }
[[ "$(sha256_file "$ROOT/SOURCE/briefs.test.ts")" == "$NEW_TEST_SHA" ]] || { echo "Packaged briefs.test.ts checksum mismatch" >&2; exit 1; }
[[ "$(sha256_file "$PAGE")" == "$PAGE_SHA" ]] || { echo "FAIL_CLOSED_INCOMPATIBLE_PAGE" >&2; exit 1; }

SOURCE_BEFORE="$(sha256_file "$SOURCE")"
TEST_BEFORE="$(sha256_file "$TEST")"
if [[ "$SOURCE_BEFORE" == "$OLD_SOURCE_SHA" && ( "$TEST_BEFORE" == "$AUDITED_TEST_SHA" || "$TEST_BEFORE" == "$CANDIDATE_TEST_SHA" ) ]]; then
  SOURCE_STATE_BEFORE="v14-july17-contract"
elif [[ "$SOURCE_BEFORE" == "$NEW_SOURCE_SHA" && "$TEST_BEFORE" == "$NEW_TEST_SHA" ]]; then
  SOURCE_STATE_BEFORE="already-fixed-v15"
else
  echo "FAIL_CLOSED_INCOMPATIBLE_SOURCE" >&2
  echo "briefs.ts=$SOURCE_BEFORE" >&2
  echo "briefs.test.ts=$TEST_BEFORE" >&2
  exit 1
fi

mkdir -p "$BACKUP"
cp "$SOURCE" "$BACKUP/briefs.ts"
cp "$TEST" "$BACKUP/briefs.test.ts"
cp -R "$DIST" "$BACKUP/web_dist"
BACKUP_READY=1

cp "$ROOT/SOURCE/briefs.ts" "$SOURCE"
cp "$ROOT/SOURCE/briefs.test.ts" "$TEST"
[[ "$(sha256_file "$SOURCE")" == "$NEW_SOURCE_SHA" ]]
[[ "$(sha256_file "$TEST")" == "$NEW_TEST_SHA" ]]

cd "$WEB"
npm test -- --run src/lib/briefs.test.ts
npx tsc --noEmit
npm run build

"$PYTHON" - "$DIST" "$MARKER" <<'PY'
import re, sys
from pathlib import Path
dist, marker = Path(sys.argv[1]), sys.argv[2].encode()
index = (dist / "index.html").read_text()
match = re.search(r'src="([^"]*index-[^"]+\.js)"', index)
if not match:
    raise SystemExit("Built JavaScript asset missing from index.html")
asset = dist / match.group(1).lstrip("./").lstrip("/")
data = asset.read_bytes()
for required in (marker, b"v61-date-load-keyboard-focus", b"v74-ticker-above-company", b"hermes-stock-row-date", b"#ffe08a"):
    if required not in data:
        raise SystemExit(f"Built asset missing marker: {required.decode()}")
print(f"BUILT_ASSET={asset.name}")
PY

if [[ "${HERMES_TEST_FORCE_POST_BUILD_FAILURE:-0}" == "1" ]]; then
  echo "FORCED_POST_BUILD_FAILURE" >&2
  exit 97
fi

if [[ "${SKIP_RESTART:-0}" != "1" ]]; then
  SERVER_TOUCHED=1
  stop_preview
  start_preview
  wait_preview || { echo "Preview did not become ready; see $LOG" >&2; exit 1; }
  LIVE_INDEX="$BACKUP/live-index.html"
  LIVE_ASSET="$BACKUP/live-asset.js"
  curl -fsS "http://127.0.0.1:$PORT/" -o "$LIVE_INDEX"
  ASSET_PATH="$("$PYTHON" -c 'import re,sys; from pathlib import Path; h=Path(sys.argv[1]).read_text(); m=re.search(r"src=.(?P<a>[^ >]*index-[^ >]+[.]js).",h); print(m.group("a") if m else "")' "$LIVE_INDEX")"
  [[ -n "$ASSET_PATH" ]] || { echo "Live asset path missing" >&2; exit 1; }
  curl -fsS "http://127.0.0.1:$PORT/${ASSET_PATH#/}" -o "$LIVE_ASSET"
  grep -q "$MARKER" "$LIVE_ASSET" || { echo "Live asset missing $MARKER" >&2; exit 1; }
fi

[[ "$(sha256_file "$SOURCE")" == "$NEW_SOURCE_SHA" ]]
[[ "$(sha256_file "$TEST")" == "$NEW_TEST_SHA" ]]
trap - EXIT
BACKUP_READY=0
if [[ "${SKIP_OPEN:-0}" != "1" && "${SKIP_RESTART:-0}" != "1" ]]; then
  open "http://127.0.0.1:$PORT/briefs-stocks?profile=$PROFILE&fix=v15-$(date +%s)"
fi
echo "STOCK_HEADER_CANONICAL_FIX_V15=PASS"
echo "SOURCE_STATE_BEFORE=$SOURCE_STATE_BEFORE"
echo "FOCUSED_TESTS=55/55"
echo "TYPECHECK=PASS"
echo "BUILD=PASS"
echo "LIVE_MARKER=$MARKER"
echo "BACKUP=$BACKUP"
echo "PRODUCTION_9119=UNTOUCHED"
