#!/bin/bash
set -euo pipefail

PREVIEW_ROOT="${1:-/Users/jb3/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
PROFILE_ROOT="${2:-/Users/jb3/.hermes/profiles/local-ai-assist1}"
AGENT_PYTHON="${HERMES_PYTHON:-/Users/jb3/.hermes/hermes-agent/venv/bin/python}"
SCRIPT_ROOT="$(cd "$(dirname "$0")" && pwd)"
LOG="$PREVIEW_ROOT/v39-dashboard-9120.log"
EXPECTED_ASSET="index-DzIN_ZpW.js"

if [ ! -x "$AGENT_PYTHON" ]; then
  echo "Required Hermes Python is missing or not executable: $AGENT_PYTHON" >&2
  exit 1
fi

HERMES_PYTHON="$AGENT_PYTHON" \
  bash "$SCRIPT_ROOT/apply-v39-single-exports-default-ai.sh" "$PREVIEW_ROOT" "$PROFILE_ROOT"

cd "$PREVIEW_ROOT"
PID="$(lsof -tiTCP:9120 -sTCP:LISTEN 2>/dev/null || true)"
if [ -n "$PID" ]; then
  kill "$PID" 2>/dev/null || true
  for _ in {1..30}; do
    if ! lsof -tiTCP:9120 -sTCP:LISTEN >/dev/null 2>&1; then break; fi
    sleep 0.2
  done
fi

: > "$LOG"
nohup env \
  PYTHONPATH="$PREVIEW_ROOT" \
  HERMES_WEB_DIST="$PREVIEW_ROOT/hermes_cli/web_dist" \
  "$AGENT_PYTHON" -m hermes_cli.main \
  --profile local-ai-assist1 \
  dashboard --isolated --port 9120 --no-open \
  >"$LOG" 2>&1 &
DASHBOARD_PID=$!

READY=0
for _ in {1..60}; do
  if ! kill -0 "$DASHBOARD_PID" 2>/dev/null; then
    echo "Dashboard exited before readiness:" >&2
    tail -80 "$LOG" >&2
    exit 1
  fi
  if curl -fsS http://127.0.0.1:9120/ 2>/dev/null | grep -q "$EXPECTED_ASSET"; then
    READY=1
    break
  fi
  sleep 1
done

if [ "$READY" -ne 1 ]; then
  echo "Dashboard did not serve $EXPECTED_ASSET within 60 seconds:" >&2
  tail -80 "$LOG" >&2
  exit 1
fi

# Open the dashboard root to verify its BRIEFS-AI default redirect.
open "http://127.0.0.1:9120/?profile=local-ai-assist1&v39=single-exports-default-ai"
printf '\nV39_LIVE_ACCEPTANCE=PASS asset=%s port=9120 pid=%s default=/briefs-ai\n' "$EXPECTED_ASSET" "$DASHBOARD_PID"
