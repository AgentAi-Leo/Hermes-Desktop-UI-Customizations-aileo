#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
shasum -a 256 -c CHECKSUMS.sha256
/usr/bin/python3 -m py_compile server.py TEMPLATE-SOURCE/materializer/*.py
(
  cd TEMPLATE-SOURCE/materializer
  /usr/bin/python3 -m unittest -v
)
echo "BRIEFS_TEMPLATES_V28_VERIFY=PASS"
