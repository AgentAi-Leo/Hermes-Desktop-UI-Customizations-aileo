# Offline reference contract

The five files named `BRIEFS-STOCKS - YYYY-MM-DD.html` form one offline navigation set. Each has zero external scripts and zero external stylesheets; all CSS and JavaScript are inline. Previous/next navigation changes between the companion files and transports exact `scrollX,scrollY` coordinates in the `#hermes-stock-viewport=` hash. Keep filenames unchanged and in one directory. Yahoo Finance links are optional outbound source links and are not rendering dependencies.
