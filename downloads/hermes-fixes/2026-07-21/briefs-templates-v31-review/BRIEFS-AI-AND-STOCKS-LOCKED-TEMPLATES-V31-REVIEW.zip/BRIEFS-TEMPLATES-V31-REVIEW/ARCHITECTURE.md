# Briefs locked-template architecture

## Runtime flow

```text
AI/Stocks cron model output (strict JSON data only)
                    │
                    ▼
profile-local no-agent host materializer
                    │
                    ▼
strict schema validation → deterministic renderer
                    │
                    ▼
output validation → atomic replace → retain five dates
                    │
                    ▼
dashboard-owned presentation/controller/export functions
                    │
          ┌─────────┴─────────┐
          ▼                   ▼
 live sandboxed preview   standalone HTML/Markdown
                          (inline CSS/JS + comments)
```

## Ownership boundary

Cron/model output is data only. It cannot define CSS, JavaScript, navigation, filesystem paths, or dashboard controls. Presentation and interaction remain in tracked dashboard/materializer source.

## Locked assets

- `TEMPLATE-SOURCE/materializer/schemas/`: strict AI and Stocks JSON contracts.
- `TEMPLATE-SOURCE/materializer/brief_renderer.py`: deterministic HTML/Markdown/CSV renderer.
- `TEMPLATE-SOURCE/materializer/brief_materializer.py`: fail-closed session reader and atomic publisher.
- `TEMPLATE-SOURCE/dashboard/src/lib/briefs.ts`: canonical presentation, inline export controllers, and cyclic archive-ring logic.
- `TEMPLATE-SOURCE/dashboard/src/pages/BriefsPage.tsx`: archive rail, downloads, fullscreen, and per-date state.
- `REFERENCES/*-DATA/`: canonical data-only payloads for the five review dates.
- `REFERENCES/AI` and `REFERENCES/STOCK`: deterministic raw renderer output; Stocks CSV is frozen/read-only.
- `EXPORTS/`: dashboard-transformed HTML, semantic Markdown, and Position Comparison CSV generated from the same functions.
- `web_dist/`: compiled read-only review application.

## Export contract

HTML is the accepted visual/interactive standalone form. Every HTML export embeds required CSS and JavaScript, includes explanatory comments, uses no external script/stylesheet dependency, and implements the same cyclic date ring as the dashboard. The neighboring date HTML files are the only files needed for offline archive navigation.

Markdown intentionally carries content and hierarchy rather than CSS/browser behavior; its inline note points to the companion HTML for the accepted presentation.

## Dependency and safety boundary

Host materializer defaults resolve from `Path.home()/.hermes/zDownloads/...`; they do not depend on `_BRIEFS-DASHBOARD-V3-PREVIEW`. This review server serves only bundled files on isolated port `9125`.

No production cutover is performed. Port `9119`, production files, and active cron jobs remain unchanged until explicit approval.
