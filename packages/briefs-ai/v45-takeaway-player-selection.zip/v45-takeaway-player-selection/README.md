# BRIEFS-AI V45 — Takeaways and deterministic player selection

This candidate starts from the accepted/restored V42 layout and changes only the AI preview renderer and its regression tests.

## Changes

- Founder Takeaways list/details span the full usable card width.
- Takeaways TTS explicitly reads `Takeaway 1` through `Takeaway 7`.
- Each Takeaway title and description are separated by sentence punctuation for a natural pause.
- Clicking or keyboard-selecting a topic resolves the exact current card, stops nested event propagation, focuses it without an extra jump, scrolls it smoothly with `block: nearest`, then speaks it.
- The outer document guide and inactive topic-card borders are cyan (`#67e8f9`).
- The current/playing topic-card selector border and glow are yellow (`#ffd166`).

## Safety

- Requires the exact accepted V42 source hashes, or an already-applied V45 candidate.
- Backs up `briefs.ts`, `briefs.test.ts`, and the built `web_dist` before changes.
- Runs all 35 Briefs tests and a production build.
- Verifies source and built-asset fingerprints.
- Restores the pre-install snapshot automatically on validation failure.
- Restarts only isolated preview port `9120`; production port `9119` is untouched.
- Does not trigger audible TTS during automated acceptance.

## Installer

Run `scripts/install-build-restart-open-v45.sh` from this extracted package. The dashboard opens directly to `/briefs-ai` after readiness passes.
