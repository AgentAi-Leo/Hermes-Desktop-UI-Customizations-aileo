# Briefs locked-template architecture

## Runtime flow

```text
01_AI-MORNING-BRIEF             02_BRIEF-STOCKS
(strict JSON generator)         (strict JSON generator)
          │                              │
          ▼                              ▼
01B_AI-HOST-MATERIALIZER        02B_STOCKS-HOST-MATERIALIZER
(no-agent Python)               (no-agent Python)
          │                              │
          └──────────────┬───────────────┘
                         ▼
 strict schema validation → locked deterministic renderer
                         ▼
 output validation → atomic replace → retain five dates
                         ▼
              dashboard canonical view
```

## Locked assets

- `TEMPLATE-SOURCE/materializer/schemas/`: strict AI and Stocks JSON contracts.
- `TEMPLATE-SOURCE/materializer/brief_renderer.py`: deterministic HTML/Markdown/CSV producer.
- `TEMPLATE-SOURCE/materializer/brief_materializer.py`: fail-closed session reader and atomic publisher.
- `TEMPLATE-SOURCE/dashboard/src/lib/briefs.ts`: one canonical dashboard-owned presentation and controller per Brief type.
- `TEMPLATE-SOURCE/dashboard/src/pages/BriefsPage.tsx`: archive rail, exports, fullscreen, and per-date state.
- `web_dist/`: compiled read-only review application.

## Dependency boundary

The host materializer defaults resolve from `Path.home()/.hermes/zDownloads/...`; they do not refer to `_BRIEFS-DASHBOARD-V3-PREVIEW`. The review server and all reference data are bundled here. This package can therefore be reviewed after the old preview folder is removed.

A production cutover is intentionally not performed by this review package. Production port `9119` remains unchanged until this V30 presentation is approved.
