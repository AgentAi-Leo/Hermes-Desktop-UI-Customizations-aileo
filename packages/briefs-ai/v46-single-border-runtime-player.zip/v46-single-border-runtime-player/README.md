# BRIEFS-AI V46 preview candidate

Corrects the rejected V45 preview without creating a final layout archive.

- Repairs the runtime numbered-heading regex so shared-section topics become seven sibling playable cards.
- Neutralizes the shared archive container, leaving one border per topic card.
- Removes the accidental page-level cyan line and active-card glow.
- Normal cards use one cyan border; the selected/playing card replaces it with one yellow border.
- Clears width caps from the Takeaways list, items, and all direct item children.
- Reads Takeaway numbers explicitly and queues number/title separately from detail with a controlled pause.
- Preserves exact-card click/focus/nearest-scroll behavior.
- Runs 36 tests with a temporary candidate test file, restores the Mac host test unchanged, builds, fingerprints the asset, snapshots rollback state, and restarts only port 9120.
