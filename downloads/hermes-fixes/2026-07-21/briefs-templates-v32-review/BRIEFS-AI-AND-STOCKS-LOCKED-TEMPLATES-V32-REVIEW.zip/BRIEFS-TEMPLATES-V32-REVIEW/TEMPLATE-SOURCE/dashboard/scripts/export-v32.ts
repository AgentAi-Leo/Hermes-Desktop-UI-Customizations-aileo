import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { JSDOM } from "jsdom";
import { briefDashboardHtml, briefDashboardMarkdown, stockPortfolioCsv, stockPortfolioCsvName } from "./src/lib/briefs";

const dom = new JSDOM("<!doctype html><html><body></body></html>");
Object.assign(globalThis, {
  DOMParser: dom.window.DOMParser,
  Node: dom.window.Node,
  Element: dom.window.Element,
  HTMLElement: dom.window.HTMLElement,
});

const sourceRoot = "/root/v32-live/references";
const targetRoot = "/root/v32-live/exports";
const dates = ["2026-07-20", "2026-07-18", "2026-07-17", "2026-07-16", "2026-07-15"];
for (const kind of ["ai", "stock"] as const) {
  const stream = kind === "ai" ? "AI" : "STOCK";
  const label = kind === "ai" ? "BRIEFS-AI" : "BRIEFS-STOCKS";
  mkdirSync(join(targetRoot, stream), { recursive: true });
  for (const date of dates) {
    const basename = `${label} - ${date}`;
    const sourceHtml = readFileSync(join(sourceRoot, stream, `${basename}.html`), "utf8");
    const generatedAt = Math.floor(Date.parse(`${date}T${kind === "ai" ? "08" : "14"}:00:00-07:00`) / 1000);
    const exportedHtml = briefDashboardHtml(sourceHtml, kind, date, dates, generatedAt);
    const exportedMarkdown = briefDashboardMarkdown(sourceHtml, kind, generatedAt);
    writeFileSync(join(targetRoot, stream, `${basename}.html`), exportedHtml);
    writeFileSync(join(targetRoot, stream, `${basename}.md`), exportedMarkdown);
    if (kind === "stock") {
      // Mirror the dashboard toolbar exactly: UTF-8 BOM + CRLF portfolio CSV.
      // Both quote and portfolio CSV products end with Agent=HERMES in V32.
      writeFileSync(join(targetRoot, stream, stockPortfolioCsvName(date)), `\uFEFF${stockPortfolioCsv(sourceHtml, date)}`);
    }
  }
}
console.log("V32_EXPORTS_REBUILT=10_HTML+10_MD+5_PORTFOLIO_CSV");
