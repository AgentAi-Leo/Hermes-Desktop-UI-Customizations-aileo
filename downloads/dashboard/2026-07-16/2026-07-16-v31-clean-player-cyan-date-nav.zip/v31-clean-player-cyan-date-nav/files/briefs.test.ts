// @ts-expect-error jsdom is a transitive test-only dependency without bundled declarations.
import { JSDOM } from "jsdom";
import { describe, expect, it } from "vitest";
import type { BriefEntry } from "@/lib/api";
import {
  BRIEF_DATE_NAV_MESSAGE_TYPE,
  BRIEF_PLAYER_MESSAGE_TYPE,
  BRIEF_PREVIEW_SANDBOX,
  adjacentBriefDate,
  briefDashboardHtml,
  briefDashboardMarkdown,
  briefDownloadName,
  briefHtmlDownloadName,
  briefRoute,
  filterBriefs,
  focusBriefPreview,
  isBriefPlayerShortcut,
  isBriefPlayerTextEditingTarget,
  matchingStockPortfolioCsv,
  paginateBriefs,
  prepareBriefPreviewHtml,
  stockPortfolioCsv,
  stockPortfolioCsvName,
} from "./briefs";

const entries: BriefEntry[] = [
  {
    date: "2026-07-14",
    html_exists: true,
    markdown_exists: true,
    html_route: "/api/briefs/ai/html/2026-07-14",
    markdown_route: "/api/briefs/ai/markdown/2026-07-14",
  },
  {
    date: "2026-07-13",
    html_exists: true,
    markdown_exists: false,
    html_route: "/api/briefs/ai/html/2026-07-13",
    markdown_route: null,
  },
];

describe("brief helpers", () => {
  it("builds archive routes", () => {
    expect(briefRoute("stock", "html", "2026-07-14")).toBe(
      "/api/briefs/stock/html/2026-07-14",
    );
  });

  it("filters entries by date", () => {
    expect(filterBriefs(entries, "07-13")).toEqual([entries[1]]);
    expect(filterBriefs(entries, "   ")).toEqual(entries);
  });

  it("paginates date rails newest-first without expanding their width", () => {
    const dated = Array.from({ length: 15 }, (_, index) => ({ ...entries[0], date: `2026-07-${String(15 - index).padStart(2, "0")}` }));
    expect(paginateBriefs(dated, 0).map((entry) => entry.date)).toHaveLength(5);
    expect(paginateBriefs(dated, 1).map((entry) => entry.date)).toEqual(dated.slice(5, 10).map((entry) => entry.date));
    expect(paginateBriefs(dated, 2).map((entry) => entry.date)).toEqual(dated.slice(10, 15).map((entry) => entry.date));
  });

  it("selects adjacent cron dates without wrapping at archive boundaries", () => {
    expect(adjacentBriefDate(entries, "2026-07-14", "older")?.date).toBe("2026-07-13");
    expect(adjacentBriefDate(entries, "2026-07-13", "newer")?.date).toBe("2026-07-14");
    expect(adjacentBriefDate(entries, "2026-07-14", "newer")).toBeNull();
    expect(adjacentBriefDate(entries, "2026-07-13", "older")).toBeNull();
  });

  it("builds stable download filenames", () => {
    expect(briefDownloadName("ai", "2026-07-14")).toBe(
      "AI Morning Brief - 2026-07-14.md",
    );
    expect(briefDownloadName("stock", "2026-07-14")).toBe(
      "Stock Brief - 2026-07-14.md",
    );
    expect(briefHtmlDownloadName("ai", "2026-07-14")).toBe("BRIEFS-AI - 2026-07-14.html");
    expect(briefHtmlDownloadName("stock", "2026-07-14")).toBe("BRIEFS-STOCKS - 2026-07-14.html");
  });

  it("removes archived scripts and injects one network-isolated controller", () => {
    const archivedScript = `
      <script>
        function toggleSpeech() { speechSynthesis.speak(new SpeechSynthesisUtterance("brief")); }
        document.addEventListener("keydown", archivedKeyboardHandler);
      </script>`;

    const result = prepareBriefPreviewHtml(`<!doctype html><html><head>
      <style>body { color: navy; }</style>
      <script src="https://cdn.example.test/player.js"></script>
      ${archivedScript}
    </head><body><h1>Morning brief</h1></body></html>`);

    expect(result).not.toContain("toggleSpeech");
    expect(result).not.toContain("archivedKeyboardHandler");
    expect(result).toContain('id="hermes-brief-player-controller"');
    expect(result).toContain("<style>body { color: navy; }</style>");
    expect(result).toContain("<h1>Morning brief</h1>");
    expect(result).not.toContain("cdn.example.test");
    expect(result).toContain('http-equiv="Content-Security-Policy"');
    expect(result).toContain("default-src 'none'");
    expect(result).toContain("script-src 'unsafe-inline'");
    expect(result).toContain("connect-src 'none'");
  });

  it("removes every external script regardless of attribute order or quote style", () => {
    const result = prepareBriefPreviewHtml(`<html><body>
      <script defer SRC='https://example.test/a.js'>fallbackA()</script>
      <script src=/relative.js async>fallbackB()</script>
      <script data-purpose="src=example">keepInline()</script>
    </body></html>`);

    expect(result).not.toContain("example.test/a.js");
    expect(result).not.toContain("/relative.js");
    expect(result).not.toContain("fallbackA()");
    expect(result).not.toContain("fallbackB()");
    expect(result).not.toContain('data-purpose="src=example"');
    expect(result).not.toContain("keepInline()");
    expect(result.match(/<script\b/gi)).toHaveLength(1);
  });

  it("removes archived inline handlers, javascript URLs, srcdoc, and meta refresh", () => {
    const result = prepareBriefPreviewHtml(`<!doctype html><html><head>
      <meta http-equiv="refresh" content="0;url=https://example.test">
      <meta http-equiv="Content-Security-Policy" content="script-src *">
    </head><body onload="oldLoad()">
      <section class="card" onclick='oldClick()' onkeydown=oldKey()>
        <a href="javascript:oldLink()">Unsafe link</a>
        <a href="java
script:oldObfuscatedLink()">Obfuscated unsafe link</a>
        <iframe srcdoc="&lt;script&gt;oldFrame()&lt;/script&gt;"></iframe>
      </section>
    </body></html>`);

    expect(result).not.toMatch(/\son(?:load|click|keydown)\s*=/i);
    expect(result).not.toMatch(/href\s*=\s*["']?\s*javascript:/i);
    expect(result).not.toMatch(/\ssrcdoc\s*=/i);
    expect(result).not.toMatch(/http-equiv\s*=\s*["']refresh/i);
    expect(result).not.toContain("oldLoad()");
    expect(result).not.toContain("oldClick()");
    expect(result).not.toContain("oldKey()");
    expect(result).not.toContain("oldLink()");
    expect(result).not.toContain("oldObfuscatedLink()");
    expect(result).not.toContain("oldFrame()");
    expect(result).not.toContain("script-src *");
  });

  it("injects one fixed player supporting historical and current controls", () => {
    const result = prepareBriefPreviewHtml(`<!doctype html><html><head></head><body>
      <main class="wrap"><header><h1>AI Morning Brief</h1>
      <div class="tts"><button id="prev">previous</button><button id="play">play</button><button id="next">next</button><input id="vol" type="range"></div>
      </header><section class="card"><h2>First topic</h2><p class="summary">Summary</p></section></main>
      <script>document.addEventListener('keydown', brokenArchivedHandler)</script>
    </body></html>`);

    expect(result).not.toContain("brokenArchivedHandler");
    expect(result).toContain("hermes-brief-player-sticky");
    expect(result).toContain("position: fixed !important");
    expect(result).toContain("hermes-brief-player-placeholder");
    expect(result).toContain("ResizeObserver");
    expect(result).toContain("ensureHermesPlayer");
    expect(result).toContain('player.id = "hermes-brief-player"');
    expect(result).toContain('id="tts-volume"');
    expect(result).toContain('class="hermes-player-volume"><input');
    expect(result).not.toContain('class="hermes-player-volume">Volume ');
    expect(result).not.toContain('id="tts-status"');
    expect(result).not.toContain('statusElement = document.getElementById("tts-status")');
    expect(result).toContain("width: 137.5px !important");
    expect(result).toContain(".wrap { width: 100% !important");
    expect(result).not.toContain("Keys: Space Play/Pause · ← Previous · → Next · ↑ Founder takeaways / first topic + Play");
    expect(result).toContain("function selectAndPlay(selectedIndex)");
    expect(result).toContain("function setVolume(value)");
    expect(result).toContain("volumeRestartTimer");
    expect(result).toContain("configureNaturalVoice(utterance)");
    expect(result).toContain("utterance.rate = 1");
    expect(result).not.toContain("utterance.rate = 1.15");
    expect(result).not.toContain("utterance.rate = 1.25");
    expect(result).toContain('card.addEventListener("click"');
    expect(result).toContain("selectAndPlay(cardIndex)");
    expect(result).toContain('card.setAttribute("role", "button")');
    expect(result).toContain("playButton.textContent = paused || !playing ?");
    expect(result).toContain(BRIEF_PLAYER_MESSAGE_TYPE);
    expect(result).toContain(BRIEF_DATE_NAV_MESSAGE_TYPE);
    expect(result).toContain('navigator.setAttribute("aria-label", "Cron date navigation")');
    expect(result).toContain('id="hermes-date-newer"');
    expect(result).toContain('id="hermes-date-older"');
    expect(result).toContain('pill.insertAdjacentElement("afterend", navigator)');
    expect(result).toContain("event.source !== window.parent");
    expect(result).toContain("function isVolumeControl(target)");
    expect(result).toContain("if (textEditingTarget(event.target) && !isVolumeControl(event.target)) return;");
    expect(result).toContain("volumeInput.tabIndex = -1;");
    expect(result).toContain('volumeInput.addEventListener("keydown", (event) => {');
    expect(result).toContain("// The slider is pointer-only: preserve player keys and suppress every native range key.");
    expect(result).toContain("runCommand(command);\n    }, true);");
    expect(result).toContain("selectAndPlay(0)");
  });

  it("adds precise portfolio comparisons to stock briefs", () => {
    const stockHtml = `<!doctype html><html><head></head><body><main>
      <header><h1>Stock Brief — 2026-07-06</h1></header>
      <section aria-label="Stock price cards">
        <article class="card"><h2>AAPL — Apple</h2><p class="positive">▲ +3.96 (+1.28%)</p><strong>$312.59</strong></article>
        <article class="card"><h2>GOOGL — Alphabet</h2><p class="positive">▲ +1.48 (+0.41%)</p><strong>$361.39</strong></article>
        <article class="card"><h2>AMZN — Amazon</h2><p class="positive">▲ +0.04 (+0.02%)</p><strong>$242.71</strong></article>
        <article class="card"><h2>MSFT — Microsoft</h2><p class="negative">▼ -2.03 (-0.52%)</p><strong>$385.49</strong></article>
        <article class="card"><h2>NVDA — NVIDIA</h2><p class="positive">▲ +5.44 (+2.86%)</p><strong>$195.82</strong></article>
        <article class="card"><h2>DIS — Disney</h2><p class="negative">▼ -2.07 (-2.08%)</p><strong>$95.87</strong></article>
        <article class="card"><h2>SNAP — Snap</h2><p class="negative">▼ -0.10 (-2.06%)</p><strong>$4.75</strong></article>
      </section>
    </main></body></html>`;

    const result = prepareBriefPreviewHtml(stockHtml, "stock");

    expect(result).toContain('id="hermes-portfolio-comparison"');
    expect(result).toContain("Portfolio Position Comparison");
    expect(result).toContain("APPLE-1");
    expect(result).toContain("APPLE-2");
    expect(result).toContain("AMAZON-1");
    expect(result).toContain("AMAZON-2");
    expect(result).toContain("ALPHABET-1");
    expect(result).toContain("ALPHABET-2");
    expect(result).not.toContain("ALPHA/GOOGLE");
    expect(result).toContain("MICROSOFT");
    expect(result).toContain("DISNEY");
    expect(result).toContain("Stock Brief — 2026-07-06");
    expect(result).not.toContain("BRIEFS-STOCKS 2026-07-06");
    expect(result).toContain('<th>Position</th><th class="hermes-portfolio-shares">Shares</th><th class="hermes-portfolio-purchase">Purchased price</th><th>Current price</th><th>+/-</th><th>Cost basis</th><th>Current value</th><th>Gain / loss</th><th>Return</th>');
    expect(result).not.toContain("<th>(%)</th>");
    expect(result).toContain('<span class="hermes-portfolio-position">APPLE-1 · AAPL</span>');
    expect(result).toContain('<span class="hermes-portfolio-position">NVIDIA · NVDA</span>');
    expect(result).toContain('<span class="hermes-portfolio-position">DISNEY · DIS</span><span class="hermes-portfolio-meta">8/05/66</span>');
    expect(result).toContain('<section class="hermes-stock-row" data-ticker="AAPL">');
    expect(result).toContain(".hermes-stock-row { grid-column: 1 / -1 !important;");
    expect(result).toContain("grid-template-columns: minmax(280px, 1.65fr) repeat(5, minmax(104px, 1fr)) !important");
    expect(result).toContain('<span class="hermes-stock-ticker">NVDA</span>');
    expect(result).toContain('<strong class="hermes-stock-price">$195.82</strong>');
    expect(result).toContain('<span class="hermes-stock-ticker">DIS</span>');
    expect(result).toContain('<strong class="hermes-stock-price">$95.87</strong>');
    expect(result).not.toContain('<article class="card"><h2>AAPL');
    expect(result).not.toContain("<strong>$312.59</strong>");
    expect(result).toContain('<td class="hermes-portfolio-shares">146</td><td class="hermes-portfolio-purchase">$191.00</td><td>$312.59</td><td class="hermes-portfolio-positive">+$121.59</td><td>$27,886.00</td>');
    expect(result).toContain('<td class="hermes-portfolio-shares">1,786</td><td class="hermes-portfolio-purchase">$6.18</td><td>$4.75</td><td class="hermes-portfolio-negative">-$1.43</td><td>$11,037.48</td>');
    expect(result).toContain('<span class="hermes-portfolio-meta">5/29/24</span>');
    expect(result).not.toContain("$25K");
    expect(result).not.toContain("$15K");
    expect(result).not.toContain("· bought");
    expect(result).not.toContain("146 @ $191.00");
    expect(result).toContain("$45,638.14");
    expect(result).toContain("+$17,752.14");
    expect(result).toContain("+63.66%");
    expect(result).toContain("$293,653.24");
    expect(result).toContain("+$59,670.76");
    expect(result).toContain("+25.50%");
    expect(result).toContain("Precise basis uses shares × purchased price");
    expect(result).toContain(".hermes-portfolio-comparison h2 { color: #ffd166 !important;");
    expect(result).toContain(".hermes-portfolio-table { width: 100%; min-width: 1360px; table-layout: fixed;");
    expect(result).toContain(".hermes-portfolio-table th:first-child, .hermes-portfolio-table td:first-child { width: 20%; min-width: 230px; }");
    expect(result).toContain(".hermes-stock-price { grid-column: 1 !important; grid-row: 2 !important; color: #ffe08a !important; font-size: 1.84rem !important;");
    expect(result).toContain(".hermes-stock-metrics dd { margin: 4px 0 0 !important; color: var(--text, #f4f7fb) !important; font-size: 1.4375rem !important;");
    expect(result).toContain('<tfoot><tr><td colspan="5">Available-position total</td>');
    expect(result.indexOf("DISNEY · DIS")).toBeLessThan(result.indexOf("APPLE-1 · AAPL"));
    expect(result.indexOf("MICROSOFT · MSFT")).toBeGreaterThan(result.indexOf("SNAP · SNAP"));

    const missingSnapHtml = stockHtml.replace(
      /\s*<article class="card"><h2>SNAP — Snap<\/h2><p class="negative">▼ -0\.10 \(-2\.06%\)<\/p><strong>\$4\.75<\/strong><\/article>/,
      "",
    );
    const missingSnapResult = prepareBriefPreviewHtml(missingSnapHtml, "stock");
    expect(missingSnapResult).toContain(
      '<td class="hermes-portfolio-unavailable" colspan="6">Current SNAP price unavailable</td>',
    );

    const csv = stockPortfolioCsv(stockHtml, "2026-07-06");
    const lines = csv.trim().split("\r\n");
    expect(lines).toHaveLength(11);
    lines.forEach((line) => expect(line.split(",")).toHaveLength(12));
    expect(lines[0]).toBe(
      "Brief Date,Position,Ticker,Purchase Date,Shares,Purchased Price,Current Price,Price Difference,Cost Basis,Current Value,Gain Loss,Position Return Percent",
    );
    expect(lines[1]).toBe(
      "2026-07-06,DISNEY,DIS,8/05/66,268,25.00,95.87,70.87,6700.00,25693.16,18993.16,283.48",
    );
    expect(lines[2]).toBe(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,312.59,121.59,27886.00,45638.14,17752.14,63.66",
    );
    expect(lines).toContain(
      "2026-07-06,SNAP,SNAP,2/3/26,1786,6.18,4.75,-1.43,11037.48,8483.50,-2553.98,-23.14",
    );
    expect(csv).not.toContain("$");
    expect(csv).not.toContain("bought");
    expect(stockPortfolioCsvName("2026-07-06")).toBe("Stock Portfolio - 2026-07-06.csv");

    const missingSnapCsv = stockPortfolioCsv(missingSnapHtml, "2026-07-06");
    expect(missingSnapCsv).toContain(
      "2026-07-06,SNAP,SNAP,2/3/26,1786,6.18,,,11037.48,,,",
    );

    const crossCardHtml = "<h2>AAPL — price unavailable</h2><h2>AMZN — Amazon $242.71</h2>";
    const crossCardCsv = stockPortfolioCsv(crossCardHtml, "2026-07-06").split("\r\n");
    expect(crossCardCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,,,27886.00,,,",
    );
    expect(crossCardCsv).toContain(
      "2026-07-06,AMAZON-1,AMZN,5/29/24,138,181.00,242.71,61.71,24978.00,33493.98,8515.98,34.09",
    );
    const crossCardUi = prepareBriefPreviewHtml(crossCardHtml, "stock");
    expect(crossCardUi).toContain("Current AAPL price unavailable");
    expect(crossCardUi).toContain(">$242.71</td>");

    const tableRowsHtml =
      "<table><tr><td>AAPL — price unavailable</td></tr><tr><td>AMZN</td><td>Amazon</td><td>$242.71</td></tr></table>";
    const tableRowsCsv = stockPortfolioCsv(tableRowsHtml, "2026-07-06").split("\r\n");
    expect(tableRowsCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,,,27886.00,,,",
    );
    expect(tableRowsCsv).toContain(
      "2026-07-06,AMAZON-1,AMZN,5/29/24,138,181.00,242.71,61.71,24978.00,33493.98,8515.98,34.09",
    );

    const alternateHeadingCsv = stockPortfolioCsv(
      "<h2>Amazon (AMZN) | $242.71</h2><section class=\"card\">SNAP — Snap $4.75</section>",
      "2026-07-06",
    ).split("\r\n");
    expect(alternateHeadingCsv).toContain(
      "2026-07-06,AMAZON-1,AMZN,5/29/24,138,181.00,242.71,61.71,24978.00,33493.98,8515.98,34.09",
    );
    expect(alternateHeadingCsv).toContain(
      "2026-07-06,SNAP,SNAP,2/3/26,1786,6.18,4.75,-1.43,11037.48,8483.50,-2553.98,-23.14",
    );

    const unrelatedDollarHtml =
      "<article><h2>AAPL — Apple</h2><p>Price unavailable. Market cap rose by $12.5 billion.</p></article><h2>AMZN — Amazon $242.71</h2>";
    const unrelatedDollarCsv = stockPortfolioCsv(unrelatedDollarHtml, "2026-07-06").split("\r\n");
    expect(unrelatedDollarCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,,,27886.00,,,",
    );
    expect(unrelatedDollarCsv).toContain(
      "2026-07-06,AMAZON-1,AMZN,5/29/24,138,181.00,242.71,61.71,24978.00,33493.98,8515.98,34.09",
    );

    const unavailableHeadingCsv = stockPortfolioCsv(
      "<h2>AAPL — Apple price unavailable; market cap $12.5 billion</h2>",
      "2026-07-06",
    ).split("\r\n");
    expect(unavailableHeadingCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,,,27886.00,,,",
    );

    const companyProseCsv = stockPortfolioCsv(
      "<h2>AAPL — Supplier SNAP — social platform note $312.59</h2>",
      "2026-07-06",
    ).split("\r\n");
    expect(companyProseCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,312.59,121.59,27886.00,45638.14,17752.14,63.66",
    );
    expect(companyProseCsv).toContain(
      "2026-07-06,SNAP,SNAP,2/3/26,1786,6.18,,,11037.48,,,",
    );

    const datedCsv = { date: "2026-07-06", content: csv };
    expect(matchingStockPortfolioCsv(datedCsv, "2026-07-06")).toBe(datedCsv);
    expect(matchingStockPortfolioCsv(datedCsv, "2026-07-14")).toBeNull();
  });

  it("normalizes actual section-card stock archives into one horizontal quote row per ticker", () => {
    const stockHtml = `<!doctype html><html><body><main class="grid">
      <section class="card" id="AAPL"><div class="top"><div><div class="ticker">AAPL</div><div class="company">Apple Inc.</div></div><div><div class="price">$327.50</div><div class="change up">+$12.64</div></div></div><dl><div><dt>Day High</dt><dd>$328.72</dd></div><div><dt>Day Low</dt><dd>$317.32</dd></div><div><dt>52-week High</dt><dd>$328.72</dd></div><div><dt>52-week Low</dt><dd>$201.50</dd></div><div><dt>Volume</dt><dd>60,780,931</dd></div></dl><div class="sources"><a href="https://example.test">Yahoo source</a></div></section>
    </main></body></html>`;
    const result = prepareBriefPreviewHtml(stockHtml, "stock");

    expect(result).toContain('<section class="hermes-stock-row" data-ticker="AAPL">');
    expect(result).toContain('<span class="hermes-stock-ticker">AAPL</span>');
    expect(result).toContain('<span class="hermes-stock-company">Apple Inc.</span>');
    expect(result).toContain('<span class="hermes-stock-change hermes-portfolio-positive">+$12.64</span>');
    expect(result).toContain('<strong class="hermes-stock-price hermes-portfolio-positive">$327.50</strong>');
    expect(result).toContain('<dt>Day High</dt><dd>$328.72</dd>');
    expect(result).toContain('.hermes-stock-row { grid-column: 1 / -1 !important;');
    expect(result).not.toContain("Yahoo source");
    expect(result).not.toContain('id="hermes-brief-player-controller"');
  });

  it("uses cyan archive metadata and a weighted Founder Takeaways keypoint hierarchy", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><header><div class="date">Wednesday, July 15, 2026</div><div class="sub">America/Los_Angeles date: 2026-07-15 · USD</div></header><main><div class="takeaways"><h2>Founder takeaways</h2><ol><li><strong>1. Agentic coding is now a price/performance war, not a novelty.</strong> Supporting detail.</li></ol></div></main></body></html>',
      "ai",
    );

    expect(result).toContain("header .date, header .sub { color: #67e8f9 !important; }");
    expect(result).toContain(".hermes-playable-card.takeaways h2 { color: #67e8f9 !important; text-transform: uppercase !important;");
    expect(result).toContain(".hermes-playable-card.takeaways li { font-size: 1.2em !important;");
    expect(result).toContain(".hermes-playable-card.takeaways li > strong:first-child { display: block !important; color: #67e8f9 !important; font-size: 1.35em !important;");
    expect(result).toContain(".hermes-playable-card.takeaways li::marker { color: #67e8f9 !important;");
  });

  it("exports a self-contained full-page dashboard clone with archive context and player", () => {
    const result = briefDashboardHtml(
      '<html><head><title>AI Morning Brief</title></head><body><main><div class="takeaways"><h2>Founder takeaways</h2></div><section><h2>Topic one</h2></section></main></body></html>',
      "ai",
      "2026-07-16",
      ["2026-07-16", "2026-07-15"],
    );
    expect(result).toContain('id="hermes-brief-export-shell"');
    expect(result).toContain("BRIEFS-AI");
    expect(result).toContain('aria-current="date">2026-07-16');
    expect(result).toContain(">2026-07-15<");
    expect(result).toContain('id="hermes-brief-player-controller"');
    expect(result.match(/id="hermes-brief-player-controller"/g)).toHaveLength(1);
    expect(result).toContain("script-src 'unsafe-inline'");
  });

  it("exports a semantic Markdown snapshot from the same transformed archive", () => {
    const previousDomParser = globalThis.DOMParser;
    globalThis.DOMParser = new JSDOM("").window.DOMParser as typeof DOMParser;
    try {
      const markdown = briefDashboardMarkdown(
        '<html><body><header><h1>AI Morning Brief — 2026-07-15</h1></header><main><div class="takeaways"><h2>Founder takeaways</h2><ol><li><strong>1. Keypoint headline</strong> Supporting detail.</li></ol></div><section class="card"><h2>Topic one</h2><p>Topic detail.</p></section></main></body></html>',
        "ai",
      );
      expect(markdown).toContain("# AI Morning Brief");
      expect(markdown).not.toContain("# AI Morning Brief — 2026-07-15");
      expect(markdown).toContain("## FOUNDER TAKEAWAYS");
      expect(markdown).toContain("### 1. Keypoint headline");
      expect(markdown).toContain("Supporting detail.");
      expect(markdown).toContain("## Topic one");
      expect(markdown).toContain("Topic detail.");
    } finally {
      globalThis.DOMParser = previousDomParser;
    }
  });

  it("injects a dashboard-owned player for card-only AI archives", () => {
    const result = prepareBriefPreviewHtml(
      "<!doctype html><html><body><section><h2>Founder takeaways</h2><p>Summary</p></section><section><h2>First topic</h2><p>Detail</p></section></body></html>",
      "ai",
    );

    expect(result).toContain('player.id = "hermes-brief-player"');
    expect(result).toContain('id="tts-volume"');
    expect(result).toContain("ensureHermesPlayer");
    expect(result).toContain("main article, main section, article, section");
  });

  it("starts ArrowUp playback at founder takeaways, keeps topic headlines yellow, and removes tactical agendas", () => {
    const result = prepareBriefPreviewHtml(
      `<!doctype html><html><body><main><div class="takeaways"><h2>Founder takeaways</h2><ol><li>Start here.</li></ol></div><section><h2>First topic</h2><p>Detail</p></section><section class="agenda"><h2>Today’s tactical agenda</h2><p>Remove this.</p></section></main></body></html>`,
      "ai",
    );

    expect(result).toContain('founderTakeaways = document.querySelector(".takeaways")');
    expect(result).toContain('if (card.classList.contains("takeaways")) return clone.textContent.trim();');
    expect(result).toContain('playFounderTakeaways()');
    expect(result).toContain('.hermes-playable-card h2, .hermes-playable-card h3 { color: var(--hot, #ffd166) !important; }');
    expect(result).not.toContain("Today’s tactical agenda");
    expect(result).not.toContain("Remove this.");
  });

  it("counts all seven numbered sibling topics instead of counting their shared section as one card", () => {
    const topics = Array.from({ length: 7 }, (_, index) =>
      `<h3>${index + 1}) Topic ${index + 1}</h3><p>Detail ${index + 1}</p>`,
    ).join("");
    const result = prepareBriefPreviewHtml(
      `<!doctype html><html><body><main><div class="takeaways"><h2>Founder takeaways</h2></div><section><h2>What changed</h2>${topics}</section></main></body></html>`,
      "ai",
    );

    expect(result).toContain('function isNumberedTopicHeading(element)');
    expect(result).toContain('function wrapSiblingTopic(heading)');
    expect(result).toContain('document.querySelectorAll("main h2, main h3, body > h2, body > h3")');
    expect(result).toContain('statusElement.textContent = "Topic " + (index + 1) + " of " + cards.length + state');
  });

  it("does not add portfolio comparisons to AI briefs", () => {
    const result = prepareBriefPreviewHtml(
      "<!doctype html><html><body><h2>AAPL — Apple $312.59</h2></body></html>",
      "ai",
    );

    expect(result).not.toContain('id="hermes-portfolio-comparison"');
  });

  it("recognizes only the requested global player shortcuts", () => {
    expect(isBriefPlayerShortcut(" ")).toBe(true);
    expect(isBriefPlayerShortcut("Spacebar")).toBe(true);
    expect(isBriefPlayerShortcut("ArrowLeft")).toBe(true);
    expect(isBriefPlayerShortcut("ArrowRight")).toBe(true);
    expect(isBriefPlayerShortcut("ArrowUp")).toBe(true);
    expect(isBriefPlayerShortcut("ArrowDown")).toBe(false);
    expect(isBriefPlayerShortcut("Enter")).toBe(false);
  });

  it("starts first previous or next navigation on topic one before advancing", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><article class="card"><h2>1) One</h2></article><article class="card"><h2>2) Two</h2></article></main></body></html>',
      "ai",
    );

    expect(result).toContain("let navigationStarted = false");
    expect(result).toContain("navigationStarted = true");
    expect(result).toContain('if (!navigationStarted) selectAndPlay(index);\n      else selectAndPlay(index - 1);');
    expect(result).toContain('if (!navigationStarted) selectAndPlay(index);\n      else selectAndPlay(index + 1);');
  });

  it("captures reserved player shortcuts from initially focused buttons but not text editors", () => {
    const dom = new JSDOM('<button id="selected-date">2026-07-16</button><a id="download">HTML</a><input id="filter"><textarea id="notes"></textarea><div id="editor" contenteditable="true"></div>');
    const document = dom.window.document;

    expect(isBriefPlayerTextEditingTarget(document.getElementById("selected-date"))).toBe(false);
    expect(isBriefPlayerTextEditingTarget(document.getElementById("download"))).toBe(false);
    expect(isBriefPlayerTextEditingTarget(document.getElementById("filter"))).toBe(true);
    expect(isBriefPlayerTextEditingTarget(document.getElementById("notes"))).toBe(true);
    expect(isBriefPlayerTextEditingTarget(document.getElementById("editor"))).toBe(true);
  });

  it("gives every active playable topic an explicit visual highlight", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><div class="takeaways"><h2>Founder takeaways</h2></div><section><h2>Topic 1</h2></section><section><h2>Topic 5</h2></section></main></body></html>',
      "ai",
    );
    expect(result).toContain(".hermes-playable-card.active");
    expect(result).toContain('card.classList.toggle("active", active)');
  });

  it("uses a compact Apple-like AI hierarchy without labels or header summary", () => {
    const result = prepareBriefPreviewHtml(`<!doctype html><html><head><style>
      body { font: 16px/1.55 system-ui; max-width: 1000px; background: #f5f7fb; color: #182033; }
      header, .takeaways, .card { background: white; }
    </style></head><body>
      <header class="hero"><span class="pill">AI Morning Brief</span><div class="tag">Legacy label</div><h1>AI Morning Brief — 2026-07-16</h1><p class="date">July 16, 2026 · America/Los_Angeles</p><p class="meta">For founders and operators · Regulation, implementation, model economics, open weights, infrastructure, monetization, and safety.</p></header>
      <section class="takeaways"><h2>Founder takeaways</h2><ol><li>Readable title.</li></ol></section>
      <section class="topics"><article class="card"><h2>1) Topic</h2><p>Body copy.</p></article></section>
    </body></html>`, "ai");

    expect(result).toContain('id="hermes-ai-restored-style"');
    expect(result).not.toContain('<div class="tag">AI Morning Brief</div>');
    expect(result).toContain('<span class="pill">July 16, 2026</span>');
    expect(result).toContain('data-hermes-date-normalized="true"');
    expect(result).not.toContain('<div class="tag">Legacy label</div>');
    expect(result).toContain("<h1>AI Morning Brief</h1>");
    expect(result).not.toContain("<h1>AI Morning Brief — 2026-07-16</h1>");
    expect(result).toContain('<p class="date">America/Los_Angeles</p>');
    expect(result).not.toContain("For founders and operators");
    expect(result).toContain("background: #0b1020 !important");
    expect(result).toContain("--card: #121a33");
    expect(result).toContain("linear-gradient(135deg, #182345, #10182f)");
    expect(result).toContain("border: 1px solid #263456 !important");
    expect(result).toContain("border-radius: 22px !important");
    expect(result).toContain("letter-spacing: .015em !important");
    expect(result).toContain("content: none !important");
    expect(result).toContain("html body .hero .tag");
    expect(result).toContain("color: #eef3ff !important");
    expect(result).toContain("padding: 22px 26px !important");
    expect(result).toContain("padding: 24px !important");
    expect(result).toContain("font-size: 38px !important");
    expect(result).toContain("color: #ffd166 !important");
    expect(result).toContain("font-size: 34px !important");
    expect(result).toContain("font-size: 27px !important");
    expect(result).toContain("line-height: 1.34 !important");
    expect(result).toContain("margin: 0 0 10px !important");
    expect(result).toContain("padding-left: 1.5em !important");
    expect(result).toContain(".hermes-playable-card:not(.takeaways)");
    expect(result).toContain("function normalizeAiVisualStructure()");
    expect(result).toContain('document.querySelectorAll(".tag").forEach((label) => label.remove())');
    expect(result).toContain('document.querySelector(".hero, body > header, body > main > header, .wrap > header, header")');
    expect(result).toContain('const dateParagraph = header.querySelector(".date")');
    expect(result).toContain('const dateLine = dateParagraph?.textContent?.trim()');
    expect(result).toContain('const alreadyNormalized = header.dataset.hermesDateNormalized === "true"');
    expect(result).toContain('if (dateLine && !alreadyNormalized)');
    expect(result).toContain('const [pillDate, ...metadataParts] = dateLine.split("·").map((part) => part.trim())');
    expect(result).toContain('if (pillDate && pill) pill.textContent = pillDate');
    expect(result).not.toContain('header.querySelectorAll("p").forEach((paragraph) => paragraph.remove())');
    const runtimeStart = result.indexOf("function normalizeAiVisualStructure()");
    const runtimeEnd = result.indexOf("function isNumberedTopicHeading", runtimeStart);
    const runtimeNormalizer = result.slice(runtimeStart, runtimeEnd);
    const runtimeDom = new JSDOM(result, { runScripts: "outside-only" });
    runtimeDom.window.eval(`${runtimeNormalizer}; normalizeAiVisualStructure(); ensureDateNavigator();`);
    const runtimeHero = runtimeDom.window.document.querySelector(".hero");
    expect(runtimeHero?.querySelector(".pill")?.textContent).toBe("July 16, 2026");
    expect(runtimeHero?.querySelector(".pill + .hermes-date-nav")).not.toBeNull();
    expect(runtimeHero?.querySelector("#hermes-date-newer")?.getAttribute("aria-label")).toBe("Load newer cron date");
    expect(runtimeHero?.querySelector("#hermes-date-older")?.getAttribute("aria-label")).toBe("Load older cron date");
    expect(runtimeHero?.querySelector(".date")?.textContent).toBe("America/Los_Angeles");
    expect(runtimeHero?.querySelector(".meta")).toBeNull();
    expect(result).toContain("max-width: none !important");
    expect(result).toContain("margin: 0 0 18px 22px !important");
    expect(result).toContain("top: 10px !important");
    expect(result).toContain("border: 1px solid #67e8f9 !important");
    expect(result).toContain("color: #67e8f9 !important");
    expect(result).toContain("<strong>Readable title.</strong>");
    expect(result).toContain(".takeaways li > strong:first-child");
  });

  it("selects a natural English female voice and rejects macOS novelty voices", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><article class="card"><h2>1) Voice test</h2><p>Natural speech.</p></article></main></body></html>',
      "ai",
    );

    expect(result).toContain("preferredVoiceNames");
    expect(result).toContain("blockedVoiceNames");
    expect(result).toContain("utterance.voice = selectedVoice");
    expect(result).toContain("utterance.pitch = 1");
    expect(result).toContain("utterance.rate = 1");
    expect(result).toContain("return Boolean(selectedVoice)");
    expect(result).toContain("function speakWhenNaturalVoiceReady(utterance, attempt = 0)");
    expect(result).toContain("if (configureNaturalVoice(utterance))");
    expect(result).toContain('statusElement.textContent = "Natural voice unavailable"');
    expect(result).toContain("window.setTimeout(() => speakWhenNaturalVoiceReady(utterance, attempt + 1), 100)");
    expect(result).toContain("synth.cancel();\n    synth.getVoices();");
    expect(result).not.toContain("configureNaturalVoice(utterance);\n    utterance.onend");
    expect(result).not.toContain("utterance.rate = 1.15");
  });

  it("uses only script permission for the opaque iframe origin", () => {
    expect(BRIEF_PREVIEW_SANDBOX).toBe("allow-scripts");
    expect(BRIEF_PREVIEW_SANDBOX).not.toContain("allow-same-origin");
  });

  it("focuses the iframe and its window after the preview loads", () => {
    let iframeFocused = false;
    let windowFocused = false;
    const iframe = {
      focus: () => {
        iframeFocused = true;
      },
      contentWindow: {
        focus: () => {
          windowFocused = true;
        },
      },
    } as unknown as HTMLIFrameElement;

    focusBriefPreview(iframe);

    expect(iframeFocused).toBe(true);
    expect(windowFocused).toBe(true);
  });
});
