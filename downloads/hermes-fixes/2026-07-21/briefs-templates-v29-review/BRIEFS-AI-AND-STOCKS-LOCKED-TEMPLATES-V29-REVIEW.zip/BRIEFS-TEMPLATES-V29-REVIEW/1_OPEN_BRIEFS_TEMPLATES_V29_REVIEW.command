#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PORT="${BRIEFS_TEMPLATES_REVIEW_PORT:-9123}"
LOG="$ROOT/review-server.log"
PID="$ROOT/review-server.pid"
if lsof -tiTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; then
  echo "Port $PORT is already in use; nothing was stopped or replaced." >&2
  exit 1
fi
PYTHON="/usr/bin/python3"
[[ -x "$PYTHON" ]] || PYTHON="$(command -v python3)"
nohup env BRIEFS_TEMPLATES_REVIEW_PORT="$PORT" "$PYTHON" "$ROOT/server.py" >"$LOG" 2>&1 &
echo $! >"$PID"
for _ in $(seq 1 50); do
  curl -fsS "http://127.0.0.1:$PORT/api/status" >/dev/null && break
  sleep .1
done
curl -fsS "http://127.0.0.1:$PORT/api/status" >/dev/null
open -a "Brave Browser" \
  "http://127.0.0.1:$PORT/briefs-ai?profile=local-ai-assist1" \
  "http://127.0.0.1:$PORT/briefs-stocks?profile=local-ai-assist1"
echo "BRIEFS_TEMPLATES_V29_REVIEW=OPEN"
