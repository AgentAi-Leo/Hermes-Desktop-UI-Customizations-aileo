# Briefs V27 — Founder focus, archive-nav emphasis, and Stock width fill

**Apply this package only after V26.** It modifies the isolated Briefs preview only; it never touches production port `9119`.

## What changes

- Makes `FOUNDER TAKEAWAYS` uppercase and cyan.
- Promotes each Founder takeaway to a clear keypoint: cyan standalone headline at 35% larger size, with 20% larger supporting text and improved spacing.
- Reverses archive pagination emphasis: the disabled/current boundary direction stays outlined; the available opposite direction is filled.
- Makes the Stock Portfolio Position Comparison table use available desktop width, eliminating the large blank right-side area while retaining responsive overflow at narrower widths.

## Apply

```bash
bash /absolute/path/to/v27-founder-focus-and-stock-fill/scripts/apply-v27.sh \
  "$HOME/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW"
```

The installer snapshots the three managed Brief files before validating and applying the patch. It supports both a Git checkout and the existing non-Git source export.
