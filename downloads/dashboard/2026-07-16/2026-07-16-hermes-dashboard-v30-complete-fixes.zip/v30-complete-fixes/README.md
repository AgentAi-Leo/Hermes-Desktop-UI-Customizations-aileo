# V30 — Briefs player/export and Git Comments complete fixes

## Included

- Briefs AI keyboard shortcuts work before iframe interaction and while shell buttons/links have focus.
- Every active topic, including the final topic, gets an explicit cyan highlight.
- HTML export is a self-contained full-page dashboard export with archive context, inline CSS, and inline AI player JavaScript.
- Markdown export remains semantic; Stock CSV generation is unchanged.
- Git Comments uses a deterministic atomic checker and profile-local data file.
- Git Comments shows `WATCHING (…) · COMMENTED (…)`, puts the GitHub link beside the issue number, detects non-owner comments, and green-outlines issues with received comments.

## Apply

```bash
unzip -q ~/Downloads/2026-07-16-hermes-dashboard-v30-complete-fixes.zip -d /tmp/hermes-dashboard-v30 && bash /tmp/hermes-dashboard-v30/v30-complete-fixes/scripts/apply-v30.sh
```

The installer snapshots every replaced file, fetches and validates live GitHub comment data, runs the focused Briefs tests, and builds the production frontend. It does not restart any dashboard process.

Afterward restart only the isolated preview on port 9120. Do not restart production port 9119 during acceptance.
