#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -x "$HOME/.hermes/hermes-agent/venv/bin/python" ]; then PY="$HOME/.hermes/hermes-agent/venv/bin/python"; else PY="$(command -v python3)"; fi
"$PY" - "$ROOT" <<'PY'
from pathlib import Path
import hashlib, json, sys, zipfile
root=Path(sys.argv[1])
errors=[]
for line in (root/'CHECKSUMS.sha256').read_text().splitlines():
    expected, rel=line.split('  ',1)
    p=root/rel
    actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else 'MISSING'
    if actual!=expected: errors.append(f'{rel}: expected {expected}, got {actual}')
manifest=json.loads((root/'RESTORE_MANIFEST.json').read_text())
if manifest.get('accepted_identity')!='v52-export-manifest-parity': errors.append('manifest identity mismatch')
html=(root/'REFERENCES/BRIEFS-AI-ACCEPTED-LAYOUT-REFERENCE.html').read_text()
md=(root/'REFERENCES/BRIEFS-AI-ACCEPTED-SEMANTIC-REFERENCE.md').read_text()
for marker in ('v52-export-manifest-parity','FOUNDER TAKEAWAYS'):
    if marker not in html: errors.append(f'HTML missing {marker}')
if html.count('<article class="topic">')!=7: errors.append('HTML topic count is not 7')
if html.count('target="_blank" rel="noopener noreferrer"')!=13: errors.append('HTML external link count is not 13')
if len([x for x in md.splitlines() if x.startswith('## ') and len(x)>3 and x[3].isdigit()])!=7: errors.append('Markdown topic count is not 7')
nested=root/'PACKAGES/PRIMARY-BRIEFS-AI-V52-RESTORE.zip'
with zipfile.ZipFile(nested) as z:
    bad=z.testzip()
    if bad: errors.append(f'nested ZIP CRC failure: {bad}')
if errors:
    print('\n'.join('FAIL '+x for x in errors)); raise SystemExit(1)
print('OUTER_CHECKSUMS=PASS')
print('LIVE_REFERENCES=PASS')
print('NESTED_ZIP=PASS')
print('LAYOUT_FINAL_BRIEFS_AI_V1_JB_VERIFY=PASS')
PY
