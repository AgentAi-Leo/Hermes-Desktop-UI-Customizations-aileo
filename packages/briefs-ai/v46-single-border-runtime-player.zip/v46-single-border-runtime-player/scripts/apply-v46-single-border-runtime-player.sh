#!/usr/bin/env bash
set -euo pipefail

PREVIEW_ROOT="${1:-/Users/jb3/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date +%Y-%m-%d-%H%M%S)"
BACKUP="$PREVIEW_ROOT/.hermes-ui-customization-backups/v46-$STAMP-single-border-runtime-player"
BRIEFS="$PREVIEW_ROOT/web/src/lib/briefs.ts"
HOST_TEST="$PREVIEW_ROOT/web/src/lib/briefs.test.ts"
CANDIDATE_TEST="$PACKAGE_ROOT/files/briefs.v46.test.ts"
DIST="$PREVIEW_ROOT/hermes_cli/web_dist"
REJECTED_V45_SHA="19d4b7916f0816d38a6a181d220a88a7fc41e12697c1dbd69df5ce925caa6f8c"
V46_SHA="5c350bd792522f22d1b275ec84559e640cdc6bd1c9a601dbf8cafd9064929374"
V46_TEST_SHA="2b2a3cc40e760d7dffd51c02e1bc364a915bd9608098545d8aaec8dc7ee262e4"
SUCCESS=0

sha256_file() { shasum -a 256 "$1" | cut -d ' ' -f 1; }
restore_on_error() {
  status=$?
  if [ "$SUCCESS" -eq 0 ] && [ -d "$BACKUP" ]; then
    printf '\nV46 validation failed; restoring rejected-V45 preview snapshot.\n' >&2
    cp "$BACKUP/briefs.ts" "$BRIEFS"
    cp "$BACKUP/briefs.test.ts" "$HOST_TEST"
    rm -rf "$DIST"
    if [ -d "$BACKUP/web_dist" ]; then cp -R "$BACKUP/web_dist" "$DIST"; fi
  fi
  exit "$status"
}
trap restore_on_error ERR INT TERM

for path in "$BRIEFS" "$HOST_TEST" "$PACKAGE_ROOT/files/briefs.ts" "$CANDIDATE_TEST"; do
  [ -f "$path" ] || { echo "Missing required file: $path" >&2; exit 1; }
done

current_sha="$(sha256_file "$BRIEFS")"
case "$current_sha" in
  "$REJECTED_V45_SHA"|"$V46_SHA") ;;
  *) echo "Preview source is neither rejected V45 nor V46; refusing overwrite: $current_sha" >&2; exit 1 ;;
esac
[ "$(sha256_file "$PACKAGE_ROOT/files/briefs.ts")" = "$V46_SHA" ] || { echo "Packaged V46 source checksum mismatch" >&2; exit 1; }
[ "$(sha256_file "$CANDIDATE_TEST")" = "$V46_TEST_SHA" ] || { echo "Packaged V46 test checksum mismatch" >&2; exit 1; }

mkdir -p "$BACKUP"
cp "$BRIEFS" "$BACKUP/briefs.ts"
cp "$HOST_TEST" "$BACKUP/briefs.test.ts"
if [ -d "$DIST" ]; then cp -R "$DIST" "$BACKUP/web_dist"; fi

cp "$PACKAGE_ROOT/files/briefs.ts" "$BRIEFS"
cp "$CANDIDATE_TEST" "$HOST_TEST"
[ "$(sha256_file "$BRIEFS")" = "$V46_SHA" ]

grep -Fq 'hermes-topic-container' "$BRIEFS"
grep -Fq 'takeawaySpeechSegments' "$BRIEFS"
grep -Fq 'speakTakeawayQueue' "$BRIEFS"
grep -Fq 'segment.pauseAfter' "$BRIEFS"
grep -Fq 'border-color: #ffd166' "$BRIEFS"
if grep -Fq 'border-inline: 1px solid #67e8f9' "$BRIEFS"; then echo "Unexpected page-level cyan border remains" >&2; false; fi
if grep -Fq 'rgba(255, 209, 102, .38)' "$BRIEFS"; then echo "Unexpected active glow remains" >&2; false; fi

TEST_LOG="$BACKUP/tests.log"
(
  cd "$PREVIEW_ROOT/web"
  npm test -- --run src/lib/briefs.test.ts 2>&1 | tee "$TEST_LOG"
)
# Preserve the Mac's accepted host test file; the V46 regression file is temporary only.
cp "$BACKUP/briefs.test.ts" "$HOST_TEST"
[ "$(sha256_file "$HOST_TEST")" = "$(sha256_file "$BACKUP/briefs.test.ts")" ]

BUILD_LOG="$BACKUP/build.log"
(
  cd "$PREVIEW_ROOT/web"
  npm run build 2>&1 | tee "$BUILD_LOG"
)

INDEX="$DIST/index.html"
[ -f "$INDEX" ] || { echo "Build did not produce $INDEX" >&2; false; }
ASSET_REL="$(grep -Eo 'assets/index-[A-Za-z0-9_-]+\.js' "$INDEX" | head -1)"
[ -n "$ASSET_REL" ] || { echo "Could not resolve V46 JavaScript asset" >&2; false; }
ASSET="$DIST/$ASSET_REL"
[ -f "$ASSET" ] || { echo "Missing built asset: $ASSET" >&2; false; }
for token in 'Takeaway ' '#ffd166' 'nearest' 'hermes-topic-container' 'pauseAfter'; do grep -Fq "$token" "$ASSET"; done

SUCCESS=1
trap - ERR INT TERM
printf '\nV46_APPLY=PASS tests=36/36 host_test=preserved asset=%s\nRollback snapshot: %s\n' "$(basename "$ASSET")" "$BACKUP"
