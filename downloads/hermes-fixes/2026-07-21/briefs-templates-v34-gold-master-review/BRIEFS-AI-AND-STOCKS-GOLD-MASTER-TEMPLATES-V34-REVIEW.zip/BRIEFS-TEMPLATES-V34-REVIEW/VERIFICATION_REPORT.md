# V34 verification report

## Scope

V34 upgrades the direct Briefs-AI and Briefs-Stocks exports into self-documenting gold masters without intentionally changing accepted presentation or behavior.

## Source gates

- Frontend: 152/152 tests passed.
- The new test first failed on missing restoration/documentation headers, then passed after implementation.
- Production build completed successfully.

## Export gates

- 10/10 self-contained HTML exports.
- 45/45 inline CSS blocks begin with purpose and restoration comments.
- 25/25 inline JavaScript controllers begin with purpose, state, inputs, outputs, dependencies, and restoration comments.
- 10/10 Markdown companions are semantic-only and reference the HTML gold master.
- 5/5 Position Comparison CSVs are data-only and retain `Agent=HERMES`.
- Static export audit: 25/25.

## Browser gates

- Dashboard and standalone behavior: 40/40.
- Real Export-button byte parity: 25/25.
- Speech synthesis was mocked; no native audible test was performed.
- Dashboard and standalone AI/Stocks screenshots were captured in `QA/`.
- Final visual review: PASS; no regression identified (`QA/VISUAL_REVIEW.md`).

## Retained behavior

- AI no-preference volume default: 45%.
- Explicit saved zero: valid mute.
- Volume changes affect the active utterance volume without restart/navigation.
- AI volume persists across dates, frames, reload/reopen, and dashboard routes.
- Date navigation remains cyclic.
- Stocks presentation, Position Comparison, freshness/fail-closed data boundaries, and CSV contracts remain locked.

## Safety

- V32 and V33 remain immutable rollback packages.
- Production port `9119` was untouched.
- V34 review uses isolated port `9128`.
