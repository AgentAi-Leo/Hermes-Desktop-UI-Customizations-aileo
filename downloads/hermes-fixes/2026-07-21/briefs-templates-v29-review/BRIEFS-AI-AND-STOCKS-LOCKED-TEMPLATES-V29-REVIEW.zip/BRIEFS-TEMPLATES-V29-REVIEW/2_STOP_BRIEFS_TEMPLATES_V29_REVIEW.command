#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PID="$ROOT/review-server.pid"
if [[ -f "$PID" ]]; then
  VALUE="$(cat "$PID")"
  kill "$VALUE" 2>/dev/null || true
  rm -f "$PID"
fi
echo "BRIEFS_TEMPLATES_V29_REVIEW=STOPPED"
