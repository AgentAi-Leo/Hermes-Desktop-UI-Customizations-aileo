#!/usr/bin/env bash
set -euo pipefail
PROFILE_ROOT="${1:-/Users/jb3/.hermes/profiles/local-ai-assist1}"
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TARGET="$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js"
SOURCE="$PACKAGE_ROOT/files/index.js"
STAMP="$(date +%Y-%m-%d-%H%M%S)"
BACKUP="$PROFILE_ROOT/backups/git-comments-v31-$STAMP"
[[ -f "$TARGET" ]] || { echo "Missing target: $TARGET" >&2; exit 1; }
[[ -f "$SOURCE" ]] || { echo "Missing replacement: $SOURCE" >&2; exit 1; }
mkdir -p "$BACKUP"
cp "$TARGET" "$BACKUP/index.js"
cp "$SOURCE" "$TARGET"
node --check "$TARGET"
grep -q '__HERMES_PLUGINS__\.register("git-comments", GitCommentsPage)' "$TARGET"
grep -q '__HERMES_PLUGIN_SDK__' "$TARGET"
printf 'V31 Git Comments runtime hotfix applied.\nRollback: %s\n' "$BACKUP"
