# Stock July 17 Contract Fix — v14

This checksum-gated repair updates the accepted AI V61 + Stock V74 preview so the July 17 Stock producer contract renders consistently with earlier Stock briefs.

It fixes only the renderer normalization boundary:

- prioritizes explicit quote-card prices over portfolio purchase-price cells;
- removes the producer `.portfolio` block before rebuilding the accepted top comparison;
- recognizes human-readable dates such as `Friday, July 17, 2026`;
- enforces the accepted dark, full-width Stock canvas independent of producer light-mode CSS;
- installs permanent regression coverage for this contract.

The launcher backs up `briefs.ts`, `briefs.test.ts`, and `web_dist`, runs 55 focused tests, typecheck, and build, restarts only isolated port 9120, verifies the live v14 marker, and automatically rolls back on failure.

Production port 9119 and Gateway are not modified.
