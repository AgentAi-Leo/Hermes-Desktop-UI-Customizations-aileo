# V33 verification report

## Automated source and build gates

- Frontend/Vitest: **151/151 passed**.
- TypeScript/Vite production build: **passed**.
- Materializer/renderer/collector: **21/21 passed**.
- Offline package verifier: **passed**.

## AI volume gates

- Fresh dashboard first load with no stored preference initializes at **45%**: **passed**.
- Explicit saved levels, including zero, remain valid: **passed**.
- Active utterance volume changes without a second `speak()` call: **passed**.
- Volume changes without an additional `cancel()` call: **passed**.
- Active card remains unchanged: **passed**.
- Dashboard volume persists across date iframe replacement: **passed**.
- Dashboard volume persists through Briefs-AI → Briefs-Stocks → Crons → Briefs-AI: **passed**.
- Fresh standalone HTML first load initializes at **45%**: **passed**.
- Standalone volume persists through two offline date changes: **passed**.
- Audible playback was not used; Chromium speech synthesis was mocked.

## Stock data gates

- Direct Yahoo Chart acquisition completed for all seven tickers: **passed**.
- July 17 and July 20 quote snapshots differ: **passed**.
- AAPL example: July 17 `$333.74` / `+$0.48`; July 20 `$326.59` / `-$7.15`.
- Cross-ticker session-date agreement: **passed**.
- Stale-session and mismatched-session fail-closed tests: **passed**.
- Saturday carries Friday data while retaining Friday movement: **passed**.

## CSV gates

- Quote CSV files with trailing `Agent=HERMES`: **5/5**.
- Position Comparison CSV files with trailing `Agent=HERMES`: **5/5**.
- Position Comparison UTF-8 BOM/CRLF contract: **5/5**.

## Export/browser gates

- Self-contained HTML exports: **10/10**.
- Semantic Markdown exports: **10/10**.
- Dashboard Position Comparison CSV exports: **5/5**.
- Chromium dashboard/standalone assertions: **40/40**.
- Browser toolbar download byte parity: **25/25**.
- Visual evidence reviewed after resetting Position Comparison to default horizontal scroll: **passed**.
- Final Position Comparison columns reachable through internal horizontal scroll: **passed**.

## Safety

- V32 and older packages: **unchanged**.
- Production dashboard port `9119`: **untouched**.
- Isolated V33 review port: `9127`.
- Active Stocks cron remains on the compatible `stock-brief-data-v1` paired-marker contract and is scheduled for 2:00 PM PT.
