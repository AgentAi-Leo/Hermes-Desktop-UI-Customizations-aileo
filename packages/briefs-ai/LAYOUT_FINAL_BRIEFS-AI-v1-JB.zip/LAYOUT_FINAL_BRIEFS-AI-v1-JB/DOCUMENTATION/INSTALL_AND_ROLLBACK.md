# Install and rollback

1. Keep the extracted archive intact.
2. Double-click `VERIFY_AND_RESTORE_CURRENT_LAYOUT.command`.
3. Review checksum results.
4. Type `RESTORE` only when you intend to apply the package.
5. The installer snapshots current source and built assets before mutation.
6. On any test, typecheck, build, marker, or restart failure, the trap restores the snapshot automatically.
7. Successful backups remain under `~/.hermes/briefs-preservation-backups/`.

The installer targets only the isolated preview root unless `HERMES_PREVIEW_ROOT` is explicitly overridden. It does not modify Gateway configuration or production dashboard files.
