# LAYOUT_FINAL_BRIEFS-AI-v1-JB

Durable restoration and reference bundle for the accepted BRIEFS-AI V52 layout (`v52-export-manifest-parity`).

## What is included

- `PACKAGES/PRIMARY-BRIEFS-AI-V52-RESTORE.zip` — tested, fail-closed isolated-preview installer package.
- `REFERENCES/` — exact HTML and Markdown produced by the live V52 Download buttons.
- `SOURCE_SNAPSHOT/` — accepted source, 40-test suite, and page wiring snapshot.
- `BUILD_SNAPSHOT/web_dist/` — freshly built frontend fallback/reference.
- `RESTORE_MANIFEST.json` and `CHECKSUMS.sha256` — identity, safety, and integrity records.

## Verify first

Double-click `VERIFY_PACKAGE.command`, or run:

```bash
bash VERIFY_PACKAGE.command
```

Expected final line: `LAYOUT_FINAL_BRIEFS_AI_V1_JB_VERIFY=PASS`.

## Restoration safety

AI and Stocks share `web/src/lib/briefs.ts`. The primary installer accepts only the exact known V51 predecessor or already-installed V52 source and refuses any unexpected hash. This prevents an older AI restoration from silently overwriting future Stocks changes.

The installer defaults to the isolated preview at port 9120. It does not target production port 9119.

After `LAYOUT_FINAL_BRIEFS-STOCKS-v1-JB` is created, recover the final combined state in this order: AI package first, Stocks package second.

`LAYOUTS_FINAL_JB` must remain available until the Stocks package is complete and verified.
