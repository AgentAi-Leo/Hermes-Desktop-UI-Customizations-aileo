# Locked Brief templates V28 — AI + Stocks review

This read-only package contains the tested cumulative dashboard bundle and real bundled archive references for both locked Brief types.

## Interaction contract

- **Space:** play/pause the active AI card.
- **Left / Right:** previous/next numbered AI card, with wraparound in both directions.
- **Up:** Founder Takeaways.
- **Enter:** fullscreen. **Escape:** browser fullscreen exit.
- **Date navigation:** click-only arrows around the visible `Month Day, Year` pill.
- **Playback speed:** `1x → 1.2x → 1.5x → 1.75x`; default `1.2x`.
- **Voice:** approved female/natural names only; no generic browser/default voice fallback.

## Deterministic architecture

```text
strict JSON → schema validation → locked renderer → output validation → atomic publication
```

The model supplies changing data only. It cannot supply template HTML, CSS, JavaScript, controls, layout, or CSV design. Invalid data preserves the last valid Brief.

## Review

Double-click:

```text
1_OPEN_BRIEFS_TEMPLATES_V28_REVIEW.command
```

It opens both templates in Brave on isolated port `9122`. Opening is silent; pressing Play or Space can produce AI narration.

When finished, double-click:

```text
2_STOP_BRIEFS_TEMPLATES_V28_REVIEW.command
```

## Safety

No Hermes files, cron jobs, production port `9119`, or `_BRIEFS-DASHBOARD-V3-PREVIEW` files are modified.
