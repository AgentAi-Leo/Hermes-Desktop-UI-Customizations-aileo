#!/usr/bin/env python3
"""Fail-closed static verifier for the sealed V31 review package.

This intentionally uses only Python's standard library so the downloaded package
can validate its inline exports without Node, network access, or a browser install.
Executable browser evidence is separately recorded in QA/BROWSER_AUDIT.json.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATES = ["2026-07-20", "2026-07-18", "2026-07-17", "2026-07-16", "2026-07-15"]
CSV_SHA256 = "23e6c90eccf7d30b72b6f970b8b584e467e1fb2ae303aa5779382de717bb4bec"


def require(condition: bool, message: str) -> None:
    """Stop immediately rather than allowing a partially valid package to pass."""
    if not condition:
        raise SystemExit(f"V31_VERIFY_FAIL: {message}")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized_scripts(document: str) -> list[str]:
    """Remove only the selected-date payload; all controller code must stay equal."""
    scripts = re.findall(r"<script\b[^>]*>([\s\S]*?)</script>", document, re.I)
    return [re.sub(r"const state = \{.*?\};", "const state = <DATE_PAYLOAD>;", script, count=1) for script in scripts]


# Compile source text in memory so syntax is checked without creating __pycache__.
python_sources = [ROOT / "server.py", ROOT / "verify_v31.py"]
python_sources.extend(sorted((ROOT / "TEMPLATE-SOURCE" / "materializer").glob("*.py")))
for source_path in python_sources:
    compile(source_path.read_text(), str(source_path), "exec")


for kind, label, stream in (("ai", "BRIEFS-AI", "AI"), ("stock", "BRIEFS-STOCKS", "STOCK")):
    style_baseline = None
    script_baseline = None
    for date in DATES:
        html_path = ROOT / "EXPORTS" / stream / f"{label} - {date}.html"
        markdown_path = html_path.with_suffix(".md")
        require(html_path.is_file() and markdown_path.is_file(), f"missing {kind} export for {date}")
        html = html_path.read_text()
        markdown = markdown_path.read_text()
        require("V31 SELF-CONTAINED EXPORT GUIDE" in html, f"missing HTML guide: {html_path.name}")
        require("V31 INLINE CONTROLLER" in html, f"missing controller explanation: {html_path.name}")
        require('"export_schema":"briefs-v31-inline-cyclic"' in html, f"wrong manifest: {html_path.name}")
        require("(current + offset + state.archiveDates.length) % state.archiveDates.length" in html, f"missing cyclic controller: {html_path.name}")
        require("state.archiveDates[current + offset]" not in html, f"boundary-stopping controller remains: {html_path.name}")
        require(not re.search(r"<script\b[^>]*\bsrc\s*=", html, re.I), f"external script: {html_path.name}")
        require(not re.search(r"<link\b[^>]*\brel=[\"']?stylesheet", html, re.I), f"external stylesheet: {html_path.name}")
        require("V31 SEMANTIC EXPORT" in markdown, f"missing Markdown explanation: {markdown_path.name}")
        styles = re.findall(r"<style\b[^>]*>([\s\S]*?)</style>", html, re.I)
        scripts = normalized_scripts(html)
        if style_baseline is None:
            style_baseline, script_baseline = styles, scripts
        require(styles == style_baseline, f"style drift: {html_path.name}")
        require(scripts == script_baseline, f"controller drift: {html_path.name}")

csv_files = sorted((ROOT / "REFERENCES" / "STOCK").glob("*.csv"))
require(len(csv_files) == 5, "expected five protected Stocks CSV files")
for csv_path in csv_files:
    require(sha256(csv_path) == CSV_SHA256, f"protected CSV changed: {csv_path.name}")

friday = json.loads((ROOT / "REFERENCES" / "STOCK-DATA" / "2026-07-17.json").read_text())
saturday = json.loads((ROOT / "REFERENCES" / "STOCK-DATA" / "2026-07-18.json").read_text())
require(friday["quotes"] == saturday["quotes"], "Friday/Saturday quote snapshots differ")

export_audit = json.loads((ROOT / "EXPORT_AUDIT.json").read_text())
browser_audit = json.loads((ROOT / "QA" / "BROWSER_AUDIT.json").read_text())
download_audit = json.loads((ROOT / "QA" / "DOWNLOAD_PARITY_AUDIT.json").read_text())
require(export_audit.get("status") == "PASS" and not export_audit.get("errors"), "export audit is not clean")
require(browser_audit.get("status") == "PASS" and browser_audit.get("checks") == 31, "browser audit is not 31/31")
require(download_audit.get("status") == "PASS" and download_audit.get("files") == 25, "browser download parity is not 25/25")
portfolio_csvs = sorted((ROOT / "EXPORTS" / "STOCK").glob("Stock Portfolio - *.csv"))
require(len(portfolio_csvs) == 5, "expected five dashboard Position Comparison CSV exports")
for csv_path in portfolio_csvs:
    data = csv_path.read_bytes()
    require(data.startswith(b"\xef\xbb\xbf") and b"\r\n" in data, f"dashboard CSV encoding drift: {csv_path.name}")
require(not list(ROOT.rglob("*.pyc")) and not list(ROOT.rglob("__pycache__")), "transient Python cache found")

print("V31_STATIC_EXPORT_VERIFY=PASS")
print("HTML_EXPORTS=10 MARKDOWN_EXPORTS=10")
print("INLINE_CSS_JS_COMMENTS=PASS")
print("CYCLIC_DASHBOARD_PARITY=PASS")
print("CSV_UNCHANGED=5/5")
print("PORTFOLIO_CSV_EXPORTS=5/5")
print("BROWSER_EVIDENCE=31/31")
print("BROWSER_DOWNLOAD_PARITY=25/25")
