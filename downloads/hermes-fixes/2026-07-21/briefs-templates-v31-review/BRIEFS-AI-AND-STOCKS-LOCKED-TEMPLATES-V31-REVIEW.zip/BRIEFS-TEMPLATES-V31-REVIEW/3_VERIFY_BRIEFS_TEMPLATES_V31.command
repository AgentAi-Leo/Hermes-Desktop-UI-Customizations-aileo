#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
PYTHON="/usr/bin/python3"
[[ -x "$PYTHON" ]] || PYTHON="$(command -v python3)"
shasum -a 256 -c CHECKSUMS.sha256
PYTHONDONTWRITEBYTECODE=1 "$PYTHON" verify_v31.py
(
  cd TEMPLATE-SOURCE/materializer
  PYTHONDONTWRITEBYTECODE=1 "$PYTHON" -m unittest -v
)
echo "BRIEFS_TEMPLATES_V31_VERIFY=PASS"
