/* BRIEFS AI V62 preloader.
   Injects a controller into the sandboxed generated brief before Blob creation;
   the sandbox remains opaque and shares only per-date card indices via postMessage. */
(() => {
  'use strict';

  const CHANNEL = 'hermes-briefs-ai-v62';
  const REVISION = 'briefs-ai-v62-takeaways-focus-date-memory';
  const stateByDate = new Map();
  const NativeBlob = window.Blob;

  window.__HERMES_BRIEFS_AI_V62_REVISION__ = REVISION;
  window.__HERMES_BRIEFS_AI_V62_INJECTIONS__ = 0;

  window.addEventListener('message', event => {
    const data = event.data;
    if (!data || data.channel !== CHANNEL || typeof data.date !== 'string') return;
    if (data.type === 'ready') {
      const index = stateByDate.has(data.date) ? stateByDate.get(data.date) : 0;
      event.source?.postMessage({ channel: CHANNEL, type: 'restore', date: data.date, index }, '*');
    } else if (data.type === 'active' && Number.isInteger(data.index)) {
      stateByDate.set(data.date, data.index);
    }
  });

  function innerController() {
    'use strict';
    const CHANNEL = 'hermes-briefs-ai-v62';
    const DEFAULT_RATE = 1.2;

    const monthNumbers = {
      january: '01', february: '02', march: '03', april: '04', may: '05', june: '06',
      july: '07', august: '08', september: '09', october: '10', november: '11', december: '12'
    };
    const configure = () => {
      const titleMatch = document.title.match(/([A-Za-z]+)\s+(\d{1,2}),\s+(\d{4})/);
    const date = titleMatch
      ? `${titleMatch[3]}-${monthNumbers[titleMatch[1].toLowerCase()]}-${String(titleMatch[2]).padStart(2, '0')}`
      : '';
    const takeaways = document.querySelector('.takeaways');
    const topics = [...document.querySelectorAll('article.card')];
    const cards = [takeaways, ...topics].filter(Boolean);
    const shell = document.querySelector('.hermes-player-shell');
    const toggle = document.querySelector('#tts-toggle');
    const volume = document.querySelector('#tts-volume');
    const label = document.querySelector('.hermes-date-nav-label');
    if (!date || !takeaways || !cards.length || !shell || !toggle || !volume || !label) return;

    document.documentElement.dataset.hermesV62 = 'ready';
    const style = document.createElement('style');
    style.dataset.hermesV62 = 'controls';
    style.textContent = `
      .takeaways.hermes-playable-card.active,
      article.card.hermes-playable-card.active {
        outline: 3px solid rgba(82, 222, 255, .9);
        outline-offset: 4px;
      }
      .hermes-date-nav-label {
        white-space: nowrap;
        font-size: clamp(1rem, 3.2vw, 2.6rem) !important;
        letter-spacing: .055em !important;
        min-width: 10ch;
        text-align: center;
      }
      .hermes-player-rate {
        color: #56def8;
        font-weight: 800;
        font-size: .92rem;
        letter-spacing: .04em;
        white-space: nowrap;
      }
    `;
    document.head.appendChild(style);

    takeaways.classList.add('hermes-playable-card');
    cards.forEach((card, index) => {
      card.dataset.hermesCardIndex = String(index);
      card.setAttribute('tabindex', '-1');
    });

    label.textContent = date;
    label.setAttribute('aria-label', `Active cron date ${date}`);
    label.setAttribute('role', 'status');
    volume.title = 'Volume — changing it restarts the active card';
    volume.setAttribute('aria-description', 'Changing volume restarts narration from the beginning of the active card.');

    const rateBadge = document.createElement('span');
    rateBadge.className = 'hermes-player-rate';
    rateBadge.textContent = '1.2×';
    rateBadge.setAttribute('aria-label', 'Narration speed 1.2 times');
    volume.closest('label')?.insertAdjacentElement('afterend', rateBadge);

    let activeIndex = 0;
    let playing = false;
    let volumeRestartTimer = 0;

    const setToggleState = isPlaying => {
      playing = isPlaying;
      toggle.textContent = isPlaying ? '❚❚' : '▶';
      toggle.setAttribute('aria-pressed', String(isPlaying));
      toggle.setAttribute('aria-label', isPlaying ? 'Stop reading' : 'Play reading');
      toggle.title = isPlaying ? 'Stop reading' : 'Play reading';
    };
    const alignActive = () => {
      const card = cards[activeIndex];
      const targetTop = shell.getBoundingClientRect().bottom + 16;
      const delta = card.getBoundingClientRect().top - targetTop;
      scrollTo({ top: Math.max(0, scrollY + delta), left: 0, behavior: 'auto' });
    };
    const reportActive = () => parent.postMessage({ channel: CHANNEL, type: 'active', date, index: activeIndex }, '*');

    const setActive = (index, options = {}) => {
      const { align = true, focus = true, report = true } = options;
      activeIndex = Math.max(0, Math.min(cards.length - 1, Number(index) || 0));
      cards.forEach((card, i) => card.classList.toggle('active', i === activeIndex));
      if (align) alignActive();
      if (focus) {
        try { cards[activeIndex].focus({ preventScroll: true }); }
        catch { cards[activeIndex].focus(); }
      }
      if (report) reportActive();
    };

    const narrationText = () => cards[activeIndex].textContent.replace(/\s+/g, ' ').trim();
    const stop = () => {
      try { speechSynthesis.cancel(); } catch {}
      setToggleState(false);
    };
    const playFromStart = () => {
      const text = narrationText();
      if (!text || typeof SpeechSynthesisUtterance !== 'function' || !window.speechSynthesis) return;
      try { speechSynthesis.cancel(); } catch {}
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = DEFAULT_RATE;
      utterance.volume = Number(volume.value || 1);
      utterance.onend = () => setToggleState(false);
      utterance.onerror = () => setToggleState(false);
      speechSynthesis.speak(utterance);
      setToggleState(true);
    };
    const togglePlayback = () => playing ? stop() : playFromStart();
    const move = delta => {
      stop();
      setActive(activeIndex + delta);
    };

    addEventListener('keydown', event => {
      const editable = event.target?.closest?.('input, textarea, select, [contenteditable="true"]');
      if (editable) return;
      if (event.code === 'Space' || event.key === ' ') {
        event.preventDefault();
        event.stopImmediatePropagation();
        togglePlayback();
      } else if (event.key === 'ArrowLeft') {
        event.preventDefault();
        event.stopImmediatePropagation();
        move(-1);
      } else if (event.key === 'ArrowRight') {
        event.preventDefault();
        event.stopImmediatePropagation();
        move(1);
      }
    }, true);

    addEventListener('click', event => {
      const button = event.target.closest?.('#tts-prev, #tts-toggle, #tts-next');
      const card = event.target.closest?.('.takeaways, article.card');
      if (button) {
        event.preventDefault();
        event.stopImmediatePropagation();
        if (button.id === 'tts-prev') move(-1);
        else if (button.id === 'tts-next') move(1);
        else togglePlayback();
      } else if (card && cards.includes(card)) {
        event.stopImmediatePropagation();
        stop();
        setActive(cards.indexOf(card));
      }
    }, true);

    addEventListener('input', event => {
      if (event.target !== volume) return;
      event.stopImmediatePropagation();
      clearTimeout(volumeRestartTimer);
      volumeRestartTimer = setTimeout(playFromStart, 90);
    }, true);
    addEventListener('change', event => {
      if (event.target !== volume) return;
      event.stopImmediatePropagation();
      clearTimeout(volumeRestartTimer);
      playFromStart();
    }, true);

    addEventListener('message', event => {
      const data = event.data;
      if (!data || data.channel !== CHANNEL || data.type !== 'restore' || data.date !== date) return;
      setActive(data.index, { align: false, focus: false, report: false });
      const settle = () => {
        alignActive();
        cards[activeIndex].focus({ preventScroll: true });
      };
      requestAnimationFrame(() => requestAnimationFrame(settle));
      setTimeout(settle, 120);
    });

    setToggleState(false);
    setActive(0, { align: false, focus: false, report: false });
    parent.postMessage({ channel: CHANNEL, type: 'ready', date }, '*');
    const initialSettle = () => {
      alignActive();
      cards[activeIndex].focus({ preventScroll: true });
    };
    requestAnimationFrame(() => requestAnimationFrame(initialSettle));
    setTimeout(initialSettle, 120);
      window.__HERMES_BRIEFS_AI_V62__ = { date, get activeIndex() { return activeIndex; }, setActive, playFromStart, stop };
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', configure, { once: true });
    else configure();
  }

  const injectedScript = `<script>(${innerController.toString()})()<\/script>`;

  class HermesBriefBlob extends NativeBlob {
    constructor(parts = [], options = {}) {
      let nextParts = parts;
      const type = String(options?.type || '').toLowerCase();
      if (type.includes('text/html') && parts.every(part => typeof part === 'string')) {
        const html = parts.join('');
        if (html.includes('hermes-player-shell') && html.includes('hermes-date-nav-label') && !html.includes('hermes-briefs-ai-v62')) {
          const patched = /<\/body>/i.test(html)
            ? html.replace(/<\/body>/i, `${injectedScript}</body>`)
            : `${html}${injectedScript}`;
          nextParts = [patched];
          window.__HERMES_BRIEFS_AI_V62_INJECTIONS__ += 1;
        }
      }
      super(nextParts, options);
    }
  }

  Object.setPrototypeOf(HermesBriefBlob, NativeBlob);
  window.Blob = HermesBriefBlob;
})();
