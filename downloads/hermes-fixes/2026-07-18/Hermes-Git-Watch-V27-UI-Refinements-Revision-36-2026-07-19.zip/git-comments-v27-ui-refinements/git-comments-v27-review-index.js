(() => {
  const sdk = window.__HERMES_PLUGIN_SDK__;
  const { React, fetchJSON } = sdk;
  const { useEffect, useMemo, useState } = sdk.hooks;
  const e = React.createElement;
  const API = "/api/plugins/git-comments-v27-review";

  const styles = `
.git-comments-page{padding:0 24px 32px;color:#f0f6fc}.git-comments-health,.git-comments-panel{border:1px solid #334155;background:#0c1624;margin-top:20px}.git-comments-health{padding:22px 28px;text-align:left}.git-comments-health-title,.git-comments-toolbar,.git-comments-add-form,.git-comments-panel-heading{display:flex;align-items:center;gap:14px}.git-comments-health-top{display:flex;align-items:flex-start;justify-content:space-between;gap:24px}.git-comments-health-title{justify-content:flex-start}.git-comments-health-dot{width:15px;height:15px;flex:0 0 15px;border-radius:50%;background:#64748b;box-shadow:0 0 0 4px rgba(100,116,139,.15)}.git-comments-health-dot.healthy{background:#4ade80;box-shadow:0 0 0 4px rgba(74,222,128,.17),0 0 14px rgba(74,222,128,.48)}.git-comments-health-dot.broken{background:#ef4444;box-shadow:0 0 0 4px rgba(239,68,68,.17),0 0 14px rgba(239,68,68,.48)}.git-comments-kicker{font-size:18px;letter-spacing:.16em;text-transform:uppercase}.git-comments-muted{color:#9ca9bd}.git-comments-repo-line{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.git-comments-repo-primary{font-size:20.8px;color:#fff;font-weight:900}.git-comments-watch-state{font-size:18.75px;line-height:1.1;font-weight:800;letter-spacing:.12em;text-transform:uppercase}.git-comments-watch-state.open{color:#4ade80}.git-comments-watch-state.closed{color:#ef4444}.git-comments-watch-state.merged{color:#a78bfa}.git-comments-number-link{font-size:25px;color:#f0f6fc;font-weight:800;text-decoration:none}.git-comments-issue-author{color:#9ca9bd;font-size:16px;font-weight:650;white-space:nowrap}.git-comments-issue-avatar{width:40px;height:40px;flex:0 0 40px;border-radius:50%;object-fit:cover;border:1px solid #475569;background:#0c1624}.git-comments-number-link:hover{text-decoration:underline;text-underline-offset:3px}.git-comments-summary{margin-top:10px;font-size:16px;font-weight:400;letter-spacing:.08em}.git-comments-toolbar{justify-content:space-between;margin-top:16px;flex-wrap:wrap}.git-comments-button{min-height:38px;padding:8px 14px;border:1px solid #5db3ff;border-radius:9px;background:#102541;color:#8dccff;font-weight:800;letter-spacing:.04em;cursor:pointer}.git-comments-button:hover{background:#17365d}.git-comments-button:disabled{opacity:.5;cursor:wait}.git-comments-button.export-html{display:inline-flex;align-items:center;justify-content:center;gap:12px;min-height:54px;padding:0 24px;border:1px solid #FFE6CB;border-radius:0;background:#0b1324;color:#FFE6CB;font-size:18px;letter-spacing:.08em}.git-comments-button.add-toggle{border-color:#FFE6CB;background:#35291f;color:#FFE6CB}.git-comments-button.submit-add{border-color:#4ade80;background:#123c2b;color:#b7f7cc}.git-comments-button.cancel-add{border-color:#ef4444;background:#4a151b;color:#fecaca}.git-comments-button.archive{margin-left:auto;border-color:#22d3ee;background:#083344;color:#cffafe}.git-comments-button.delete{border-color:#ef4444;background:#4a151b;color:#fecaca}.git-comments-button.delete:hover{background:#651d24}.git-comments-button.view-archived{min-height:32px;padding:5px 11px;border-color:#facc15;background:#332b0b;color:#fef08a;font-size:12px}.git-comments-button.restore,.git-comments-button.unarchive{margin-left:auto;border-color:#94a3b8;background:#172033;color:#dbe5f4}.git-comments-add-form{width:100%;margin-top:12px;flex-wrap:wrap}.git-comments-panel-heading{justify-content:space-between;flex-wrap:wrap;border-bottom:1px solid #334155}.git-comments-panel-heading .git-comments-panel-title{flex:1 1 auto;border-bottom:0}.git-comments-panel-heading .add-toggle{flex:0 0 auto;margin-right:28px}.git-comments-panel-add{padding:0 28px 18px}.git-comments-input{flex:1 1 500px;min-height:42px;padding:9px 12px;border:1px solid #475569;border-radius:9px;background:#09111e;color:#f0f6fc;font:inherit}.git-comments-error{width:100%;color:#fca5a5}.git-comments-success{margin:0 28px 18px;padding:10px 14px;border:1px solid #4ade80;border-radius:9px;background:#123c2b;color:#b7f7cc;font-weight:800;opacity:1;transition:opacity .5s ease}.git-comments-success.fading{opacity:0}.git-comments-panel-title{padding:22px 28px;border-bottom:1px solid #334155;font-size:22px;font-weight:750}.git-comments-issue{margin:18px 28px;border:1px solid #334155;border-radius:16px;overflow:hidden;background:#101b30}.git-comments-issue.received{border-color:#4ade80;box-shadow:0 0 0 2px rgba(74,222,128,.24)}.git-comments-issue-head{display:flex;align-items:flex-start;gap:12px;padding:15px 18px;border-bottom:1px solid #334155;flex-wrap:wrap}.git-comments-issue-content{display:flex;align-items:flex-start;gap:12px;flex:1 1 720px;min-width:0}.git-comments-card-icon{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;flex:0 0 32px;line-height:1;font-size:22px}.git-comments-issue-identity{display:grid;gap:10px;flex:1 1 auto;min-width:0}.git-comments-issue-main,.git-comments-issue-meta,.git-comments-issue-context-meta{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.git-comments-issue-title{display:block;color:#FFE6CB;font-size:24px;font-weight:850;line-height:1.35;text-decoration:none}.git-comments-issue-title:hover{text-decoration:underline;text-underline-offset:3px}.git-comments-issue-context-meta{display:flex;align-items:center;gap:12px;flex-wrap:nowrap;overflow-x:auto;color:#9ca9bd;font-size:14.95px}.git-comments-status-cluster{display:flex;align-items:center;gap:12px;flex:0 0 auto;white-space:nowrap}.git-comments-status-text{display:flex;align-items:center;min-height:44px;gap:12px;flex-wrap:nowrap;white-space:nowrap}.git-comments-current-state,.git-comments-comment-label{display:inline-flex;align-items:center;justify-content:center;min-width:200px;width:auto;min-height:44px;box-sizing:border-box;padding:6.25px 16px;border-radius:999px;white-space:nowrap;flex:0 0 auto;font-size:15px;font-weight:850;letter-spacing:.08em}.git-comments-current-state,.git-comments-comment-label{border:1px solid #64748b}.git-comments-comment-label.open{border-color:#4ade80;color:#fff;background:#166534}.git-comments-comment-label.closed{border-color:#ef4444;color:#fff;background:#7f1d1d}.git-comments-comment-label.merged{border-color:#a78bfa;color:#fff;background:#5b21b6}.git-comments-current-state.open{border-color:#4ade80;color:#d1fae5;background:rgba(22,101,52,.25)}.git-comments-current-state.closed{border-color:#ef4444;color:#fecaca;background:rgba(127,29,29,.25)}.git-comments-current-state.merged{border-color:#a78bfa;color:#e9d5ff;background:rgba(91,33,182,.25)}.git-comments-issue-description{padding:16px 18px;border-bottom:1px solid #334155;background:#0d1728;color:#c4cce0;line-height:1.55;white-space:pre-wrap;overflow-wrap:anywhere;max-height:260px;overflow:auto}.git-comments-status{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#9ca9bd}.git-comments-status.received{color:#4ade80;font-weight:800}.git-comments-comments{display:grid;gap:12px;padding:14px}.git-comments-comment-label{text-decoration:none}.git-comments-comment{padding:16px;border:1px solid rgba(255,255,255,.09);border-radius:13px;background:#17213b}.git-comments-comment.maintainer{border-color:rgba(74,222,128,.55)}.git-comments-author{display:flex;gap:10px;align-items:center;font-weight:750}.git-comments-avatar{width:32px;height:32px;border-radius:50%}.git-comments-time{font-weight:400;color:#9ca9bd;font-size:13px}.git-comments-association{margin-left:auto;padding:3px 9px;border:1px solid #64748b;border-radius:999px;color:#cbd5e1;font-size:11px;font-weight:750}.git-comments-body{white-space:pre-wrap;overflow-wrap:anywhere;margin-top:12px;color:#c4cce0;line-height:1.55}.git-comments-empty{padding:18px;color:#9ca9bd}.git-comments-events{display:grid;gap:10px;padding:4px 14px 16px}.git-comments-event{display:flex;align-items:center;gap:10px;padding:10px 12px;border-left:3px solid #64748b;background:#0c1624;color:#c4cce0;flex-wrap:wrap}.git-comments-event-avatar{width:24px;height:24px;border-radius:50%}.git-comments-event strong{color:#f0f6fc}.git-comments-event-label{display:inline-flex;align-items:center;padding:4px 10px;border:1px solid currentColor;border-radius:999px;background:#2b250d;color:#facc15;font-weight:800}.git-comments-archived{display:grid;gap:10px;padding:16px 28px}.git-comments-archived-row{display:flex;align-items:center;gap:12px;padding:12px 14px;border:1px solid #334155;background:#0b1422;flex-wrap:wrap}.git-comments-archived-content{display:grid;gap:0;flex:1 1 560px;min-width:0}.git-comments-archived-primary{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.git-comments-archived-summary{margin-top:7px;color:#22d3ee;font-size:15.6px;line-height:1.35;font-weight:650}.git-comments-archived-row .restore{margin-left:auto}.git-comments-archive-backdrop{position:fixed;inset:0;z-index:1000;display:flex;align-items:center;justify-content:center;padding:32px;background:rgba(2,6,23,.82)}.git-comments-archive-modal{width:min(960px,calc(100vw - 64px));max-height:calc(100vh - 64px);overflow:auto;border:1px solid #64748b;background:#0c1624;box-shadow:0 24px 80px rgba(0,0,0,.62);color:#f0f6fc}.git-comments-archive-modal-head{position:sticky;top:0;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:20px;padding:18px 22px;border-bottom:1px solid #334155;background:#0c1624}.git-comments-archive-modal-title{font-size:22px;font-weight:850;color:#FFE6CB}.git-comments-button.close-archive-view{border-color:#ef4444;background:#4a151b;color:#fecaca}.git-comments-archive-modal-body{display:grid;gap:16px;padding:22px}.git-comments-archive-readonly{color:#facc15;font-size:12px;font-weight:800;letter-spacing:.12em}.git-comments-archive-description{white-space:pre-wrap;overflow-wrap:anywhere;color:#cbd5e1;line-height:1.6}.git-comments-archive-labels{display:flex;gap:8px;flex-wrap:wrap}.git-comments-archive-label{padding:4px 9px;border:1px solid currentColor;border-radius:999px;font-size:12px;font-weight:750}.git-comments-archive-comment{padding:14px;border:1px solid #334155;background:#111d31}.git-comments-archive-comment-body{margin-top:8px;white-space:pre-wrap;overflow-wrap:anywhere;color:#cbd5e1;line-height:1.55}
`;

  function fmt(value) { if (!value) return "Never"; const d = new Date(value); return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString(); }
  function authorName(comment) { return comment.author?.login || comment.user?.login || comment.user || comment.author || "unknown"; }
  function avatar(comment) { return comment.author?.avatar_url || comment.user?.avatar_url || comment.avatar_url || ""; }
  function associationLabel(comment) { const value = String(comment.author_association || "").replaceAll("_", " ").trim(); return !value || value === "NONE" ? "" : value.toLowerCase().replace(/\b\w/g, (letter) => letter.toUpperCase()); }
  function archivedSummary(entry, hydratedIssue) {
    const issue = hydratedIssue || entry?.snapshot || {};
    const title = String(issue.title || "");
    const body = String(issue.body || "");
    const summarySection = body.match(/(?:^|\n)#{1,6}\s+Summary\s*\n([\s\S]*?)(?=\n#{1,6}\s+|$)/i);
    const clean = (value) => String(value || "")
      .replace(/```[\s\S]*?```/g, " ")
      .replace(/`([^`]+)`/g, "$1")
      .replace(/!\[[^\]]*\]\([^)]+\)/g, " ")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .replace(/^\s{0,3}#{1,6}\s+/gm, " ")
      .replace(/^\s*[-*+]\s+/gm, " ")
      .replace(/[>*_|~]/g, " ")
      .replace(/\s+/g, " ").trim();
    const sourceWords = clean(summarySection?.[1] || body || title).split(" ").filter(Boolean).slice(0, 100);
    if (!sourceWords.length) return "";
    const context = sourceWords.join(" ");
    const sentences = context.match(/[^.!?]+[.!?]?/g) || [context];
    const titleKeywords = new Set(clean(title).toLowerCase().split(" ").filter((word) => word.length > 3));
    let selected = sentences[0] || context;
    let selectedScore = -Infinity;
    sentences.forEach((sentence, index) => {
      const terms = clean(sentence).toLowerCase().split(" ");
      const score = terms.reduce((total, term) => total + (titleKeywords.has(term) ? 10 : 0), 0) - index;
      if (score > selectedScore) { selected = sentence; selectedScore = score; }
    });
    const candidateWords = clean(selected).split(" ").filter(Boolean).slice(0, 40);
    const displayed = [];
    for (const word of candidateWords.slice(0, 11)) {
      const candidate = displayed.length ? `${displayed.join(" ")} ${word}` : word;
      if (candidate.length > 65) break;
      displayed.push(word);
    }
    return displayed.join(" ");
  }
  function archivedViewLabel(entry, hydratedIssue) {
    const kind = String(entry?.kind || hydratedIssue?.kind || "").toLowerCase();
    const isPull = kind === "pull" || /\/pull\/\d+/i.test(String(entry?.url || "")) || Boolean(hydratedIssue?.pull_request);
    return isPull ? "VIEW PR" : "VIEW ISSUE";
  }
  function eventActor(item) { return item.actor?.login || "unknown"; }
  function eventText(item) { if (item.event === "opened") return "opened this"; if (item.event === "closed") return `closed this as ${String(item.state_reason || "completed").replaceAll("_", " ")}`; if (item.event === "reopened") return "reopened this"; if (item.event === "labeled") return "added"; if (item.event === "unlabeled") return "removed"; return item.event || "updated this"; }
  function githubColor(value, fallback = "64748b") { const color = String(value || fallback).replace(/[^0-9a-f]/gi, "").slice(0, 6); return color.length === 6 ? `#${color}` : `#${fallback}`; }
  function labelColor(item) { return githubColor(item.label?.color, "facc15"); }
  function watchIdFromUrl(value) { try { const parsed = new URL(String(value || "").trim()); const parts = parsed.pathname.split("/").filter(Boolean); if (parsed.hostname.toLowerCase() !== "github.com" || parts.length !== 4 || !["issues", "pull"].includes(parts[2]) || !/^\d+$/.test(parts[3])) return ""; return `${parts[0]}/${parts[1]}/${parts[2]}/${Number(parts[3])}`.toLowerCase(); } catch (_) { return ""; } }
  function duplicateWatchId(value, active, archived) { const id = watchIdFromUrl(value); return Boolean(id && [...active, ...archived].some((entry) => String(entry.id || "").toLowerCase() === id)); }
  function issueStatus(issue) { if (issue?.merged === true || issue?.merged_at) return "merged"; return String(issue?.state || "open").toLowerCase() === "closed" ? "closed" : "open"; }
  function DownloadIcon() { return e("svg", { viewBox: "0 0 24 24", width: 24, height: 24, fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true" }, e("path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }), e("path", { d: "m7 10 5 5 5-5" }), e("path", { d: "M12 15V3" })); }
  function exportStandaloneHtml() {
    const currentPage = window.document.querySelector(".git-comments-page");
    if (!currentPage) return;
    const snapshot = currentPage.cloneNode(true);
    snapshot.querySelectorAll("button,.git-comments-panel-add,.git-comments-success,.git-comments-error").forEach((node) => node.remove());
    const exportedAt = new Date();
    const inlineScript = 'document.querySelectorAll("a").forEach(function(link){link.setAttribute("rel","noreferrer noopener");});document.documentElement.dataset.gitCommentsExport="ready";';
    const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GIT WATCH Export</title><style>html{background:#07101d}body{margin:0;background:#07101d;color:#f0f6fc;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}.git-comments-export-note{margin:20px 24px 0;padding:12px 16px;border:1px solid #475569;border-radius:10px;background:#0c1624;color:#cbd5e1;font-size:14px}${styles}</style></head><body><div class="git-comments-export-note"><strong>GIT WATCH Export</strong> · Snapshot exported ${exportedAt.toISOString()}</div>${snapshot.outerHTML}<script>${inlineScript}<\/script></body></html>`;
    const blob = new window.Blob([html], { type: "text/html;charset=utf-8" });
    const href = window.URL.createObjectURL(blob);
    const link = window.document.createElement("a");
    link.href = href;
    link.download = `git-watch-${exportedAt.toISOString().slice(0, 10)}.html`;
    link.click();
    window.URL.revokeObjectURL(href);
  }

  function Issue({ issue, owner, onArchive, onDelete, busy }) {
    const comments = Array.isArray(issue.comments) ? issue.comments : [];
    const statusEvents = Array.isArray(issue.status_events) ? issue.status_events : [];
    const importantEventTypes = new Set(["opened", "closed", "reopened", "labeled", "unlabeled"]);
    const visibleStatusEvents = statusEvents.filter((item) => importantEventTypes.has(item.event));
    const received = comments.filter((comment) => authorName(comment).toLowerCase() !== owner.toLowerCase());
    const hasReceived = received.length > 0 || Number(issue.new_received_count || 0) > 0;
    const number = issue.number || issue.issue_number;
    const url = issue.html_url || issue.url;
    const sourceComment = received[received.length - 1];
    const sourceCommentUrl = sourceComment?.html_url || sourceComment?.url || url;
    const issueAuthor = issue.author?.login || "unknown";
    const status = issueStatus(issue);
    const currentState = status.toUpperCase();
    return e("section", { className: `git-comments-issue${hasReceived ? " received" : ""}` },
      e("div", { className: "git-comments-issue-head" },
        e("div", { className: "git-comments-issue-content" }, e("span", { className: "git-comments-card-icon", "aria-hidden": "true" }, "💬"), e("div", { className: "git-comments-issue-identity" },
          e("div", { className: "git-comments-issue-main" }, e("a", { className: "git-comments-number-link", href: url, target: "_blank", rel: "noreferrer", "aria-label": `Open ${issue.repo || "GitHub"} #${number} on GitHub` }, `#${number}`), e("span", { className: "git-comments-issue-author" }, `by ${issueAuthor}`), issue.author?.avatar_url ? e("img", { className: "git-comments-issue-avatar", src: issue.author.avatar_url, alt: `${issueAuthor} profile picture` }) : null),
          e("div", { className: "git-comments-repo-line" }, e("strong", { className: "git-comments-repo-primary" }, issue.repo || "GitHub"), e("span", { className: `git-comments-watch-state ${status}` }, "WATCHING")),
          issue.title ? e("a", { className: "git-comments-issue-title", href: url, target: "_blank", rel: "noreferrer" }, issue.title) : null,
          e("div", { className: "git-comments-issue-context-meta" }, sourceCommentUrl ? e("a", { className: `git-comments-comment-label ${status}`, href: sourceCommentUrl, target: "_blank", rel: "noreferrer" }, `COMMENTS (${received.length})`) : null, e("div", { className: "git-comments-status-cluster" }, e("span", { className: `git-comments-current-state ${status}` }, `STATUS: ${currentState}`), e("div", { className: "git-comments-status-text" }, e("span", null, `Opened by ${issueAuthor}`), e("span", null, `Created ${fmt(issue.created_at)}`), e("span", null, `Updated ${fmt(issue.updated_at)}`))))
        )),
        e("button", { className: "git-comments-button archive", type: "button", disabled: busy, title: "Archive and stop watching this URL", "aria-label": `Archive ${issue.repo || "GitHub"} #${number}`, onClick: () => onArchive(issue) }, "ARCHIVE"),
        e("button", { className: "git-comments-button delete", type: "button", disabled: busy, title: "Permanently delete and stop watching this URL", "aria-label": `Delete ${issue.repo || "GitHub"} #${number}`, onClick: () => onDelete(issue.watch_id) }, "DELETE")
      ),
      issue.body ? e("div", { className: "git-comments-issue-description" }, issue.body) : null,
      comments.length ? e("div", { className: "git-comments-comments" }, comments.map((comment) => {
        const fromMaintainer = authorName(comment).toLowerCase() !== owner.toLowerCase(); const association = associationLabel(comment);
        return e("article", { key: comment.id || `${authorName(comment)}-${comment.created_at}`, className: `git-comments-comment${fromMaintainer ? " maintainer" : ""}` },
          e("div", { className: "git-comments-author" }, avatar(comment) ? e("img", { className: "git-comments-avatar", src: avatar(comment), alt: "" }) : null, e("span", null, authorName(comment)), e("span", { className: "git-comments-time" }, fmt(comment.created_at)), association ? e("span", { className: "git-comments-association" }, association) : null),
          e("div", { className: "git-comments-body" }, comment.body || "")
        );
      })) : e("div", { className: "git-comments-empty" }, issue.pending ? "Waiting for the first successful GitHub check." : "No comments yet."),
      visibleStatusEvents.length ? e("div", { className: "git-comments-events", "aria-label": "Important GitHub status timeline" }, visibleStatusEvents.map((item) => e("div", { key: item.id || `${item.event}-${item.created_at}`, className: "git-comments-event" }, item.actor?.avatar_url ? e("img", { className: "git-comments-event-avatar", src: item.actor.avatar_url, alt: "" }) : null, e("span", null, e("strong", null, eventActor(item)), ` ${eventText(item)}`), item.label?.name ? e("span", { className: "git-comments-event-label", style: { color: labelColor(item) } }, item.label.name) : null, e("span", { className: "git-comments-time" }, fmt(item.created_at))))) : null
    );
  }

  function ArchivedViewModal({ view, onClose }) {
    const issue = view?.issue;
    const comments = Array.isArray(issue?.comments) ? issue.comments : [];
    const labels = Array.isArray(issue?.labels) ? issue.labels : [];
    const status = issue ? issueStatus(issue).toUpperCase() : "";
    return e("div", { className: "git-comments-archive-backdrop", onMouseDown: (event) => { if (event.target === event.currentTarget) onClose(); } },
      e("section", { className: "git-comments-archive-modal", role: "dialog", "aria-modal": "true", "aria-labelledby": "git-comments-archive-modal-title", tabIndex: -1 },
        e("div", { className: "git-comments-archive-modal-head" }, e("div", { id: "git-comments-archive-modal-title", className: "git-comments-archive-modal-title" }, view?.entry ? `${view.entry.repo} #${view.entry.number}` : "Archived GitHub item"), e("button", { className: "git-comments-button close-archive-view", type: "button", onClick: onClose }, "CLOSE")),
        e("div", { className: "git-comments-archive-modal-body" },
          e("div", { className: "git-comments-archive-readonly" }, "READ ONLY ARCHIVED ITEM"),
          view?.loading ? e("div", { className: "git-comments-muted" }, "Loading archived item…") : null,
          view?.error ? e("div", { className: "git-comments-error", role: "alert" }, view.error) : null,
          issue ? e(React.Fragment, null,
            e("a", { className: "git-comments-archive-modal-title", href: issue.html_url, target: "_blank", rel: "noreferrer" }, issue.title || `${issue.repo} #${issue.number}`),
            e("div", { className: "git-comments-muted" }, `STATUS: ${status} · Opened by ${issue.author?.login || "unknown"} · Created ${fmt(issue.created_at)} · Updated ${fmt(issue.updated_at)}`),
            labels.length ? e("div", { className: "git-comments-archive-labels" }, labels.map((label) => e("span", { key: label.name, className: "git-comments-archive-label", style: { color: githubColor(label.color, "facc15") } }, label.name))) : null,
            e("div", { className: "git-comments-archive-description" }, issue.body || "No description provided."),
            e("div", { className: "git-comments-kicker" }, `COMMENTS (${comments.length})`),
            comments.length ? comments.map((comment) => e("article", { key: comment.id || `${authorName(comment)}-${comment.created_at}`, className: "git-comments-archive-comment" }, e("div", { className: "git-comments-author" }, avatar(comment) ? e("img", { className: "git-comments-avatar", src: avatar(comment), alt: "" }) : null, e("span", null, authorName(comment)), e("span", { className: "git-comments-time" }, fmt(comment.created_at))), e("div", { className: "git-comments-archive-comment-body" }, comment.body || ""))) : e("div", { className: "git-comments-muted" }, "No comments.")
          ) : null
        )
      )
    );
  }

  function GitCommentsPage() {
    const [state, setState] = useState({ loading: true, data: null, error: null });
    const [addOpen, setAddOpen] = useState(false); const [url, setUrl] = useState(""); const [busy, setBusy] = useState(false); const [actionError, setActionError] = useState(""); const [actionSuccess, setActionSuccess] = useState(""); const [successDuration, setSuccessDuration] = useState(0); const [successFading, setSuccessFading] = useState(false); const [successVersion, setSuccessVersion] = useState(0); const [archiveView, setArchiveView] = useState(null); const [archiveViewReturnFocus, setArchiveViewReturnFocus] = useState(null); const [archiveHydration, setArchiveHydration] = useState({});
    const load = () => fetchJSON(`${API}/data`).then((data) => setState({ loading: false, data, error: null })).catch((error) => setState({ loading: false, data: null, error: String(error) }));
    useEffect(() => { let alive = true; fetchJSON(`${API}/data`).then((data) => alive && setState({ loading: false, data, error: null })).catch((error) => alive && setState({ loading: false, data: null, error: String(error) })); return () => { alive = false; }; }, []);
    const mutate = async (path, payload) => { setBusy(true); setActionError(""); try { const data = await fetchJSON(`${API}${path}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }); setState({ loading: false, data, error: null }); return true; } catch (error) { setActionError(String(error)); await load(); return false; } finally { setBusy(false); } };
    const data = state.data || {}; const issues = Array.isArray(data.issues) ? data.issues : []; const watchlist = data.watchlist || { active: [], archived: [] }; const active = Array.isArray(watchlist.active) ? watchlist.active : []; const archived = Array.isArray(watchlist.archived) ? watchlist.archived : []; const owner = data.comment_owner || watchlist.comment_owner || ""; const health = data.watcher_health || {}; const watcherHealthy = health.ok === true && health.stale !== true && health.status === "healthy";
    const archiveHydrationKey = archived.map((entry) => `${entry.id}:${entry.snapshot ? "snapshot" : "legacy"}`).join("|");
    useEffect(() => {
      const pending = archived.filter((entry) => !entry.snapshot && !Object.prototype.hasOwnProperty.call(archiveHydration, entry.id));
      if (!pending.length) return undefined;
      let alive = true;
      Promise.all(pending.map(async (entry) => {
        try {
          const viewed = await fetchJSON(`${API}/watchlist/view-archived`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: entry.id }) });
          return [entry.id, viewed?.issue || null];
        } catch (_error) { return [entry.id, null]; }
      })).then((entries) => {
        if (!alive) return;
        setArchiveHydration((current) => ({ ...current, ...Object.fromEntries(entries) }));
      });
      return () => { alive = false; };
    }, [archiveHydrationKey, archiveHydration]);
    const displayedIssues = useMemo(() => { const byId = new Map(issues.map((issue) => [issue.watch_id, issue])); return active.map((entry) => byId.get(entry.id) || { ...entry, watch_id: entry.id, pending: true, comments: [], status_events: [] }); }, [issues, active]);
    const commented = useMemo(() => displayedIssues.filter((issue) => (issue.comments || []).some((comment) => authorName(comment).toLowerCase() !== owner.toLowerCase())).length, [displayedIssues, owner]);
    const closeAddForm = () => { setUrl(""); setActionError(""); setAddOpen(false); };
    const showSuccess = (message, duration) => { setSuccessFading(false); setSuccessDuration(duration); setActionSuccess(message); setSuccessVersion((version) => version + 1); };
    useEffect(() => { if (!actionSuccess || !successDuration) return undefined; const fadeTimer = window.setTimeout(() => setSuccessFading(true), successDuration); const removeTimer = window.setTimeout(() => setActionSuccess(""), successDuration + 500); return () => { window.clearTimeout(fadeTimer); window.clearTimeout(removeTimer); }; }, [actionSuccess, successDuration, successVersion]);
    const addUrl = async (event) => { event.preventDefault(); setActionSuccess(""); if (duplicateWatchId(url, active, archived)) { setActionError("This GitHub URL is already in the active or archived watchlist."); return; } if (await mutate("/watchlist/add", { url })) { closeAddForm(); showSuccess("URL ADDED SUCCESSFULLY!", 5000); } };
    const addFormKeyDown = (event) => { if (event.key === "Escape") { event.preventDefault(); closeAddForm(); return; } if (event.key === "Enter" && String(event.target?.tagName || "").toUpperCase() === "INPUT") { event.preventDefault(); event.currentTarget.requestSubmit(); } };
    useEffect(() => { const launchAddOnEnter = (event) => { if (event.key !== "Enter" || addOpen || busy || state.loading || archiveView || event.defaultPrevented || event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return; const target = event.target; if (target && typeof target.closest === "function" && target.closest("a,button,input,textarea,select,[contenteditable=true]")) return; event.preventDefault(); setActionSuccess(""); setActionError(""); setAddOpen(true); }; window.addEventListener("keydown", launchAddOnEnter); return () => window.removeEventListener("keydown", launchAddOnEnter); }, [addOpen, busy, state.loading, archiveView]);
    const closeArchiveView = () => { setArchiveView(null); const returnFocus = archiveViewReturnFocus; Promise.resolve().then(() => { if (returnFocus && typeof returnFocus.focus === "function") returnFocus.focus(); }); };
    const openArchiveView = async (entry, event) => { setArchiveViewReturnFocus(event?.currentTarget || null); setArchiveView({ loading: true, entry }); try { const viewed = await fetchJSON(`${API}/watchlist/view-archived`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: entry.id }) }); setArchiveHydration((current) => ({ ...current, [entry.id]: viewed?.issue || null })); setArchiveView({ ...viewed, loading: false, entry }); } catch (error) { setArchiveView({ loading: false, error: String(error), entry }); } };
    useEffect(() => { if (!archiveView) return undefined; const closeArchiveViewOnEscape = (event) => { if (event.key !== "Escape") return; event.preventDefault(); event.stopImmediatePropagation(); closeArchiveView(); }; window.addEventListener("keydown", closeArchiveViewOnEscape, true); const closeButton = window.document.querySelector(".git-comments-button.close-archive-view"); if (closeButton && typeof closeButton.focus === "function") closeButton.focus(); return () => window.removeEventListener("keydown", closeArchiveViewOnEscape, true); }, [archiveView, archiveViewReturnFocus]);
    const archive = async (issue) => { if (window.confirm("Archive this URL and stop watching it?") && await mutate("/watchlist/archive", { id: issue.watch_id, snapshot: issue })) showSuccess("URL SUCCESSFULLY ARCHIVED!", 3000); };
    const deleteWatch = async (id) => { if (window.confirm("Permanently delete this watched URL? This cannot be undone.")) await mutate("/watchlist/delete", { id }); };
    const unarchive = async (id) => { await mutate("/watchlist/restore", { id }); };
    const deleteArchived = async (id) => { if (window.confirm("Permanently delete this archived URL? This cannot be undone.")) await mutate("/watchlist/delete", { id }); };
    if (state.loading) return e("div", { className: "git-comments-page" }, "Loading GIT WATCH…"); if (state.error) return e("div", { className: "git-comments-page" }, `GIT WATCH failed: ${state.error}`);
    return e(React.Fragment, null, e("style", null, styles), e("div", { className: "git-comments-page" },
      e("section", { className: "git-comments-health" }, e("div", { className: "git-comments-health-top" }, e("div", { className: "git-comments-health-title" }, e("div", { className: "git-comments-kicker", style: { fontSize: "22.5px" } }, watcherHealthy ? "WATCHER HEALTHY" : "BROKEN"), e("span", { className: `git-comments-health-dot ${watcherHealthy ? "healthy" : "broken"}`, role: "img", "aria-label": watcherHealthy ? "Watcher status healthy" : "Watcher status broken", title: watcherHealthy ? "Watcher status healthy" : health.error || `Watcher status ${health.status || "unknown"}` })), e("button", { className: "git-comments-button export-html", type: "button", onClick: exportStandaloneHtml, "aria-label": "Download HTML" }, e(DownloadIcon), "HTML")), e("div", { className: "git-comments-muted" }, `Last successful check: ${fmt(health.checked_at || data.checked_at || data.updated)}`), e("div", { className: "git-comments-toolbar" }, e("div", { className: "git-comments-summary", style: { fontWeight: 400 } }, e("span", { className: "git-comments-summary-watching" }, `WATCHING (${active.length})`), " · ", e("span", { className: "git-comments-summary-commented", style: { color: "#4ade80" } }, `COMMENTED (${commented})`), " · ", e("span", { className: "git-comments-summary-archived", style: { color: "#22d3ee" } }, `ARCHIVED (${archived.length})`)))),
      e("section", { className: "git-comments-panel" }, e("div", { className: "git-comments-panel-heading" }, e("div", { className: "git-comments-panel-title", style: { fontSize: "26.4px", color: "#FFE6CB" } }, "*** WATCHED GITHUB ISSUES & PULL REQUESTS ***"), e("button", { className: "git-comments-button add-toggle", type: "button", disabled: busy, onClick: () => { if (addOpen) closeAddForm(); else { setActionSuccess(""); setAddOpen(true); } } }, "+ ADD URL TO WATCH")), addOpen ? e("div", { className: "git-comments-panel-add" }, e("form", { className: "git-comments-add-form", onSubmit: addUrl, onKeyDown: addFormKeyDown }, e("input", { className: "git-comments-input", type: "url", required: true, autoFocus: true, value: url, placeholder: "https://github.com/owner/repository/issues/123", onChange: (event) => setUrl(event.target.value), "aria-label": "GitHub issue or pull-request URL" }), e("button", { className: "git-comments-button submit-add", type: "submit", disabled: busy }, busy ? "CHECKING…" : "ADD URL"), e("button", { className: "git-comments-button cancel-add", type: "button", disabled: busy, onClick: closeAddForm }, "CANCEL")), actionError ? e("div", { className: "git-comments-error", role: "alert" }, actionError) : null) : null, actionSuccess ? e("div", { className: `git-comments-success${successFading ? " fading" : ""}`, role: "status", "aria-live": "polite" }, actionSuccess) : null, displayedIssues.length ? displayedIssues.map((issue) => e(Issue, { key: issue.watch_id, issue, owner, busy, onArchive: archive, onDelete: deleteWatch })) : e("div", { className: "git-comments-empty" }, "No active URLs. Add a GitHub issue or pull request to begin watching.")),
      e("section", { className: "git-comments-panel" }, e("div", { className: "git-comments-panel-title", style: { color: "#22d3ee" } }, `ARCHIVED (${archived.length})`), archived.length ? e("div", { className: "git-comments-archived" }, archived.map((entry) => { const hydratedIssue = entry.snapshot || archiveHydration[entry.id] || null; const summary = archivedSummary(entry, hydratedIssue); const summaryPending = !entry.snapshot && !Object.prototype.hasOwnProperty.call(archiveHydration, entry.id); const viewLabel = archivedViewLabel(entry, hydratedIssue); return e("div", { className: "git-comments-archived-row", key: entry.id }, e("button", { className: "git-comments-button view-archived", type: "button", disabled: busy, onClick: (event) => openArchiveView(entry, event), "aria-haspopup": "dialog" }, viewLabel), e("div", { className: "git-comments-archived-content" }, e("div", { className: "git-comments-archived-primary" }, e("strong", { className: "git-comments-repo-primary" }, entry.repo), e("a", { className: "git-comments-number-link", href: entry.url, target: "_blank", rel: "noreferrer", "aria-label": `Open ${entry.repo} #${entry.number} on GitHub` }, `#${entry.number}`), e("span", { className: "git-comments-time" }, `Archived ${fmt(entry.archived_at)}`)), summary ? e("div", { className: "git-comments-archived-summary" }, summary) : summaryPending ? e("div", { className: "git-comments-archived-summary" }, "Loading summary…") : null), e("button", { className: "git-comments-button unarchive", type: "button", disabled: busy, onClick: () => unarchive(entry.id) }, "UNARCHIVE"), e("button", { className: "git-comments-button delete", type: "button", disabled: busy, onClick: () => deleteArchived(entry.id) }, "DELETE")); })) : e("div", { className: "git-comments-empty" }, "No archived URLs.")),
      archiveView ? e(ArchivedViewModal, { view: archiveView, onClose: closeArchiveView }) : null
    ));
  }

  window.__HERMES_PLUGINS__.register("git-comments-v27-review", GitCommentsPage);
})();
