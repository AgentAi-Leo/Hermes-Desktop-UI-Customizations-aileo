# Install and rollback

1. Verify the outer package with `bash VERIFY_PACKAGE.command`.
2. Extract `PACKAGES/PRIMARY-BRIEFS-AI-V52-RESTORE.zip`.
3. Inspect `MANIFEST.json` and `README.md` inside it.
4. Run the installer only against the isolated preview root.
5. The installer creates a timestamped backup under `.hermes-ui-customization-backups/` before any write.
6. Any source hash other than the exact known V51 or V52 hash is refused.
7. On build or marker failure, source and `web_dist` are automatically restored.

Do not use `--force`, do not redirect the preview path to the production repository, and do not delete the backup until live acceptance is complete.
