# Locked Brief templates V31 — AI + Stocks review

This cumulative, read-only package contains the deterministic AI/Stocks templates, canonical data payloads, full-dashboard HTML/Markdown exports, frozen Stocks CSV files, compiled dashboard, and verification evidence.

## What V31 adds

- Date navigation is cyclic in both directions: crossing the newest/oldest boundary continues at the opposite end.
- `[` activates the visible left/newer date control; `]` activates the visible right/older date control.
- The same cyclic contract is implemented in the live dashboard and every standalone AI/Stocks HTML export.
- July 15 preserves its five real AI topics and five matching Founder Takeaways; no filler topics were invented.
- AI dates remain in the header/navigation only; topic-card and Sources date pills are removed.
- Stocks navigator arrows/date chip remain cyan (`#67e8f9`).
- Every Stocks content date uses `Month Day, Year - Day.`.
- Stocks presentation passes supplied quote values through without inferring market state or rewriting Friday/Saturday values.
- Friday and Saturday bundled quote snapshots are identical.
- All five AI and five Stocks HTML/Markdown exports were rebuilt from the deterministic render/export functions.
- Five dashboard Position Comparison CSV exports exactly mirror the live toolbar download.
- Standalone HTML exports include all required CSS and JavaScript inline, plus descriptive source comments and a machine-readable `briefs-v31-inline-cyclic` manifest.
- Markdown exports preserve the same semantic content/hierarchy and explicitly point to companion HTML for styling and interaction.
- The five protected seven-quote source CSV files remain separate and byte-for-byte unchanged.

## Existing AI interaction contract

- `S`: one speed step faster.
- `Shift+S`: one speed step slower.
- Speeds: `1x → 1.25x → 1.5x → 1.75x`; default `1.25x`.
- Space: play/pause active AI card.
- Left/Right: previous/next AI topic.
- Up: Founder Takeaways.
- Enter: fullscreen.

## Review

Double-click:

```text
1_OPEN_BRIEFS_TEMPLATES_V31_REVIEW.command
```

It opens AI and Stocks in Brave on isolated port `9125`. Opening is silent; Play or Space may produce narration.

Stop with:

```text
2_STOP_BRIEFS_TEMPLATES_V31_REVIEW.command
```

Verify package checksums, export contracts, and materializer tests with:

```text
3_VERIFY_BRIEFS_TEMPLATES_V31.command
```

## Evidence

- `EXPORT_AUDIT.json`: per-file hashes and static parity assertions.
- `QA/BROWSER_AUDIT.json`: 31 executable Chromium checks across dashboard and standalone contexts.
- `QA/DOWNLOAD_PARITY_AUDIT.json`: all 25 live browser downloads byte-identical to bundled exports.
- `QA/*.png`: full-page visual evidence for AI/Stocks dashboard and standalone HTML.
- `VERIFICATION_REPORT.md`: consolidated gate results and safety scope.

## Safety

This is a read-only review candidate. It does not modify production port `9119`, active cron definitions, V30 or older packages, or `_BRIEFS-DASHBOARD-V3-PREVIEW`.
