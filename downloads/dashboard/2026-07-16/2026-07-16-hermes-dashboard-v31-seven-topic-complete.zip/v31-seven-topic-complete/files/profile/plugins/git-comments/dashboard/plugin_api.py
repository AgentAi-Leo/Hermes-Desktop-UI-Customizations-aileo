"""Git Comments dashboard plugin API.

Reads only the atomically-written profile-local snapshot produced by the
profile checker. Mounted by Hermes at /api/plugins/git-comments/.
"""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, HTTPException

router = APIRouter()
_DATA_PATH = Path(__file__).resolve().parent / "data" / "git-comments.json"


@router.get("/data")
def get_data() -> dict:
    try:
        payload = json.loads(_DATA_PATH.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Git Comments snapshot not generated yet") from exc
    except (OSError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=500, detail=f"Git Comments snapshot is unreadable: {exc}") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("issues"), list):
        raise HTTPException(status_code=500, detail="Git Comments snapshot has an invalid schema")
    return payload
