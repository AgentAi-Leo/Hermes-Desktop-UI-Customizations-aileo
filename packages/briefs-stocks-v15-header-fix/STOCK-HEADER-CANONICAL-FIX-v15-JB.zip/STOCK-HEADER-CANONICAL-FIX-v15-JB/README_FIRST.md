# Stock Header Canonical Fix — v15

This checksum-gated follow-up applies only to the exact v14 July 17 Stock contract repair.

It makes every Stock header display the accepted canonical subtitle exactly once:

`Yahoo Finance snapshot generated at end-of-day after U.S. close · $USD`

The July 17 producer's duplicate human date, session/generation line, and quote-methodology paragraph are removed only from the rendered dashboard. Raw archived HTML remains unchanged.

The launcher backs up `briefs.ts`, `briefs.test.ts`, and `web_dist`; runs 55 focused tests, typecheck, and build; restarts only isolated port 9120; verifies the live v15 marker; and automatically rolls back on failure.

Production port 9119 and Gateway are not modified.
