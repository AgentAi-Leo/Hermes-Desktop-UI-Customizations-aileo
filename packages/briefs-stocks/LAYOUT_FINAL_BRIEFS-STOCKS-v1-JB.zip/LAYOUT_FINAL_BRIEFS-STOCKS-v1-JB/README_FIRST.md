# LAYOUT FINAL — BRIEFS-STOCKS V74

Accepted Stock identity: `v74-ticker-above-company`  
Accepted AI identity preserved by the same shared source: `v61-date-load-keyboard-focus`

This archive is independently restorable. Its primary package contains the complete accepted shared `briefs.ts`, `BriefsPage.tsx`, temporary focused regression suite, and fail-closed cumulative installer. Restoring this Stock archive does not downgrade the accepted AI layout.

## Verify or restore on macOS

Double-click:

`VERIFY_AND_RESTORE_CURRENT_LAYOUT.command`

The launcher verifies this archive's complete SHA-256 ledger and the nested ZIP before offering restoration. The installer accepts only four exact source/page/test tuples: the audited Mac preview, the known V74 predecessor, the final V61/V74 candidate, or the exact post-audit candidate state. It snapshots source and built assets, runs 54 focused tests, preserves the permanent host test file, typechecks, builds, validates AI and Stock markers, and automatically rolls back on failure.

## Offline references

`REFERENCES/` contains the five accepted Stock HTML exports plus the latest Markdown and CSV references, including the complete Portfolio Position Comparison.

## Safety

- No Gateway changes.
- No production dashboard target.
- No restore without an explicit `RESTORE` response.
- No success claim before checksum, tests, typecheck, build, and marker validation pass.
