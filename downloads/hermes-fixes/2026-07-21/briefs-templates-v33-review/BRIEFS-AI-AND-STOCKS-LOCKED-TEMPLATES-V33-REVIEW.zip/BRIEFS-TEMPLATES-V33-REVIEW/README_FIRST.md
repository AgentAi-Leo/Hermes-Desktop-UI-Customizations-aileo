# Locked Brief templates V33 — AI + Stocks review

This cumulative, read-only review package contains the deterministic AI/Stocks templates, five canonical data payloads per stream, full-dashboard exports, compiled dashboard, and executable verification evidence.

## What V33 changes

### Briefs-AI

- A first visit with no saved preference now initializes at **45%**, not zero.
- An explicit saved value—including `0` for mute—remains authoritative.
- Volume is one persistent player-level preference across all archive dates.
- The same saved level survives dashboard route changes such as Briefs-AI → Briefs-Stocks → Crons → Briefs-AI.
- Moving the volume slider updates the active utterance’s volume only.
- Volume changes never cancel, requeue, restart, scroll, or change the active card.
- Dashboard sandbox frames receive the level from the stable parent.
- Standalone HTML exports use the same volume relay across offline date changes.
- Playback speed, Founder Takeaways, cyclic date navigation, fullscreen, and existing keyboard behavior remain locked.

### Briefs-Stocks

- The accepted V32 Stock presentation, dynamic quote references, freshness gates, and CSV contracts are unchanged.

### Exports

- 10 self-contained HTML exports and 10 semantic Markdown exports were rebuilt.
- Five Position Comparison CSV exports and five quote CSV references include `Agent=HERMES`.
- HTML uses the `briefs-v33-inline-cyclic` manifest and contains all CSS/JavaScript inline.

## Review

Double-click:

```text
1_OPEN_BRIEFS_TEMPLATES_V33_REVIEW.command
```

It opens AI and Stocks in Brave on isolated port `9127`. Opening is silent; Play or Space may produce narration.

Stop with:

```text
2_STOP_BRIEFS_TEMPLATES_V33_REVIEW.command
```

Verify checksums and every offline package contract with:

```text
3_VERIFY_BRIEFS_TEMPLATES_V33.command
```

## Evidence

- `EXPORT_AUDIT.json`: hashes and static assertions for all 25 dashboard exports.
- `QA/BROWSER_AUDIT.json`: 40 Chromium checks across dashboard and standalone contexts, including fresh 45% defaults and AI → Stocks → Crons → AI persistence.
- `QA/DOWNLOAD_PARITY_AUDIT.json`: all 25 live browser downloads byte-identical to bundled exports.
- `QA/*.png`: AI/Stocks dashboard and standalone visual evidence.
- `VERIFICATION_REPORT.md`: consolidated results and safety scope.

## Safety and live state

- This package does not modify production dashboard port `9119`, production UI files, V32, or older packages.
- The installed host materializer and active cron jobs are unchanged by V33.
