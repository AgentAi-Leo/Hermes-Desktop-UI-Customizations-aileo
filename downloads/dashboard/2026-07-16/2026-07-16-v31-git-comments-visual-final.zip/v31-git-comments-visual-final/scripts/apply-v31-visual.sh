#!/usr/bin/env bash
set -euo pipefail
PREVIEW_ROOT="${1:-/Users/jb3/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
PROFILE_ROOT="${2:-/Users/jb3/.hermes/profiles/local-ai-assist1}"
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date +%Y-%m-%d-%H%M%S)"
BACKUP="$PREVIEW_ROOT/.hermes-ui-customization-backups/v31-$STAMP-git-comments-visual-final"
PAGE="$PREVIEW_ROOT/web/src/pages/GitCommentsDashboardPage.tsx"
PLUGIN="$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js"
[[ -f "$PAGE" ]] || { echo "Missing $PAGE" >&2; exit 1; }
[[ -f "$PLUGIN" ]] || { echo "Missing $PLUGIN" >&2; exit 1; }
mkdir -p "$BACKUP/preview" "$BACKUP/profile"
cp "$PAGE" "$BACKUP/preview/GitCommentsDashboardPage.tsx"
cp "$PLUGIN" "$BACKUP/profile/index.js"
cp "$PACKAGE_ROOT/files/GitCommentsDashboardPage.tsx" "$PAGE"
cp "$PACKAGE_ROOT/files/index.js" "$PLUGIN"
node --check "$PLUGIN"
(
  cd "$PREVIEW_ROOT/web"
  npm run build
)
printf '\nV31 Git Comments visual final applied and built.\nRollback snapshot: %s\n' "$BACKUP"
printf 'Restart only isolated port 9120; production 9119 was not touched.\n'
