#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROFILE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
PLUGIN_DIR="$PROFILE_DIR/plugins/git-comments/dashboard"
DATA_DIR="$PLUGIN_DIR/data"
DATA_FILE="$DATA_DIR/git-comments.json"
mkdir -p "$DATA_DIR"
export GIT_COMMENTS_DATA_FILE="$DATA_FILE"

python3 - <<'PY'
from __future__ import annotations
import json, os, tempfile, urllib.request
from datetime import datetime, timezone
from pathlib import Path

repo = "NousResearch/hermes-agent"
watched = [58130, 58510]
owner = "AgentAi-Leo"
data_path = Path(os.environ["GIT_COMMENTS_DATA_FILE"])
old = {}
try:
    old = json.loads(data_path.read_text(encoding="utf-8"))
except (FileNotFoundError, OSError, json.JSONDecodeError):
    pass
old_issues = {int(i.get("number") or i.get("issue_number")): i for i in old.get("issues", []) if i.get("number") or i.get("issue_number")}

def github(path: str):
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "Hermes-Git-Comments-Watcher"}
    token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(f"https://api.github.com{path}", headers=headers)
    with urllib.request.urlopen(req, timeout=30) as response:
        return json.load(response)

issues = []
for number in watched:
    issue = github(f"/repos/{repo}/issues/{number}")
    comments = github(f"/repos/{repo}/issues/{number}/comments?per_page=100")
    normalized = [{
        "id": c.get("id"),
        "body": c.get("body") or "",
        "created_at": c.get("created_at"),
        "updated_at": c.get("updated_at"),
        "html_url": c.get("html_url"),
        "author": {
            "login": (c.get("user") or {}).get("login") or "unknown",
            "avatar_url": (c.get("user") or {}).get("avatar_url") or "",
        },
    } for c in comments]
    received = [c for c in normalized if c["author"]["login"].lower() != owner.lower()]
    old_issue = old_issues.get(number, {})
    old_received_ids = {
        c.get("id") for c in old_issue.get("comments", [])
        if ((c.get("author") or {}).get("login") or (c.get("user") or {}).get("login") or c.get("user") or "").lower() != owner.lower()
    }
    new_count = sum(1 for c in received if c.get("id") not in old_received_ids)
    # Latch the indicator until a future UI acknowledgement mechanism clears it.
    new_count = max(new_count, int(old_issue.get("new_received_count") or 0))
    issues.append({
        "number": number,
        "title": issue.get("title") or "",
        "html_url": issue.get("html_url"),
        "state": issue.get("state"),
        "comments": normalized,
        "received_count": len(received),
        "new_received_count": new_count,
    })

now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
payload = {"schema_version": 2, "repo": repo, "owner": owner, "checked_at": now, "updated": now, "issues": issues}
fd, tmp_name = tempfile.mkstemp(prefix=".git-comments-", suffix=".json", dir=data_path.parent)
try:
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp_name, data_path)
finally:
    try:
        os.unlink(tmp_name)
    except FileNotFoundError:
        pass
PY
# Deliberately silent on success: no-agent cron delivery should not produce routine messages.
