#!/usr/bin/env bash
set -euo pipefail
PREVIEW_ROOT="${1:-/Users/jb3/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
PROFILE_ROOT="${2:-/Users/jb3/.hermes/profiles/local-ai-assist1}"
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date +%Y-%m-%d-%H%M%S)"
BACKUP="$PREVIEW_ROOT/.hermes-ui-customization-backups/v31-$STAMP-tight-yellow-takeaways"
for path in \
  "$PREVIEW_ROOT/web/src/lib/briefs.ts" \
  "$PREVIEW_ROOT/web/src/lib/briefs.test.ts" \
  "$PREVIEW_ROOT/web/src/pages/GitCommentsDashboardPage.tsx" \
  "$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js"; do
  [[ -f "$path" ]] || { echo "Missing $path" >&2; exit 1; }
done
mkdir -p "$BACKUP/preview/web/src/lib" "$BACKUP/preview/web/src/pages" "$BACKUP/profile/plugins/git-comments/dashboard/dist"
cp "$PREVIEW_ROOT/web/src/lib/briefs.ts" "$BACKUP/preview/web/src/lib/briefs.ts"
cp "$PREVIEW_ROOT/web/src/lib/briefs.test.ts" "$BACKUP/preview/web/src/lib/briefs.test.ts"
cp "$PREVIEW_ROOT/web/src/pages/GitCommentsDashboardPage.tsx" "$BACKUP/preview/web/src/pages/GitCommentsDashboardPage.tsx"
cp "$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js" "$BACKUP/profile/plugins/git-comments/dashboard/dist/index.js"
cp "$PACKAGE_ROOT/files/briefs.ts" "$PREVIEW_ROOT/web/src/lib/briefs.ts"
cp "$PACKAGE_ROOT/files/briefs.test.ts" "$PREVIEW_ROOT/web/src/lib/briefs.test.ts"
cp "$PACKAGE_ROOT/files/GitCommentsDashboardPage.tsx" "$PREVIEW_ROOT/web/src/pages/GitCommentsDashboardPage.tsx"
cp "$PACKAGE_ROOT/files/index.js" "$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js"
node --check "$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js"
(
  cd "$PREVIEW_ROOT/web"
  npm test -- --run src/lib/briefs.test.ts
  npm run build
)
printf '\nV31 nested-label removal and tight yellow Takeaways layout applied and validated.\nRollback snapshot: %s\n' "$BACKUP"
printf 'Restart only isolated port 9120; production 9119 was not touched.\n'
