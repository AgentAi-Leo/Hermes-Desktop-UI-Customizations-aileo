import { readFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { JSDOM } from "jsdom";
import {
  briefDashboardHtml,
  briefDashboardMarkdown,
  stockPortfolioCsv,
  stockPortfolioCsvName,
} from "../src/lib/briefs";

// This script lives under TEMPLATE-SOURCE/dashboard/scripts, so three parent
// levels resolve the downloaded V31 package without hard-coded machine paths.
const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), "../../..");
const sourceRoot = join(packageRoot, "REFERENCES");
const targetRoot = join(packageRoot, "EXPORTS");
const dates = ["2026-07-20", "2026-07-18", "2026-07-17", "2026-07-16", "2026-07-15"];

// Dashboard Markdown conversion uses DOMParser. JSDOM supplies the same DOM API
// during deterministic command-line regeneration without opening a browser.
const dom = new JSDOM("<!doctype html><html><body></body></html>");
Object.assign(globalThis, {
  DOMParser: dom.window.DOMParser,
  Node: dom.window.Node,
  Element: dom.window.Element,
  HTMLElement: dom.window.HTMLElement,
});

for (const kind of ["ai", "stock"] as const) {
  const stream = kind === "ai" ? "AI" : "STOCK";
  const label = kind === "ai" ? "BRIEFS-AI" : "BRIEFS-STOCKS";
  for (const date of dates) {
    const basename = `${label} - ${date}`;
    const sourceHtml = readFileSync(join(sourceRoot, stream, `${basename}.html`), "utf8");
    const generatedAt = Math.floor(Date.parse(`${date}T${kind === "ai" ? "08" : "14"}:00:00-07:00`) / 1000);

    // HTML and Markdown receive the identical canonical timestamp used by the
    // live dashboard. This keeps their visible 8am/2pm metadata byte-identical.
    writeFileSync(
      join(targetRoot, stream, `${basename}.html`),
      briefDashboardHtml(sourceHtml, kind, date, dates, generatedAt),
    );
    writeFileSync(
      join(targetRoot, stream, `${basename}.md`),
      briefDashboardMarkdown(sourceHtml, kind, generatedAt),
    );

    if (kind === "stock") {
      // Mirror the dashboard toolbar exactly: UTF-8 BOM + CRLF portfolio CSV.
      // Protected seven-quote source CSVs remain read-only in REFERENCES/STOCK.
      writeFileSync(
        join(targetRoot, stream, stockPortfolioCsvName(date)),
        `\uFEFF${stockPortfolioCsv(sourceHtml, date)}`,
      );
    }
  }
}

console.log("V31_EXPORTS_REBUILT=10_HTML+10_MD+5_PORTFOLIO_CSV");
