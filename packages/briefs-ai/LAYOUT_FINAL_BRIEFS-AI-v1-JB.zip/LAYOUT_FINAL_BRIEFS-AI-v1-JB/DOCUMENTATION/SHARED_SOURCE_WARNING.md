# Shared source warning

BRIEFS-AI and BRIEFS-STOCKS use the same `src/lib/briefs.ts` and `src/pages/BriefsPage.tsx`. A feature-specific archive must therefore carry the complete final combined accepted state. This V61 AI archive includes and verifies V74 Stock behavior; it must never restore an older AI-only source snapshot.
