# Briefs AI V62 — complete dashboard review

This is the complete Briefs AI review surface recovered from the verified `LAYOUT_FINAL_BRIEFS-AI-v1-JB` backup, populated with the validated current host cron archive, and enhanced with the approved V62 playback/focus/date-navigation behavior.

## What it includes

- the complete Hermes dashboard shell;
- the full upper cron-output/date section;
- the accepted five-date rail, newest first:
  - `2026-07-20`
  - `2026-07-18`
  - `2026-07-17`
  - `2026-07-16`
  - `2026-07-15`
- HTML and MD availability badges;
- date filtering and selection;
- the embedded accepted V61 AI presentation, unchanged in content and styling;
- the real HTML and Markdown export controls;
- the verified V61 compiled application build with an isolated V62 behavior overlay.

The four July 16–20 dates come from the validated normal Mac host directory `~/.hermes/zDownloads/__AI-DAILY-BRIEFS`. July 15 is the newest preserved historical fallback. July 19 is not present and is not fabricated.

## V62 approved tweak set

- Page load begins with **Founder Takeaways** active and aligned directly below the sticky player.
- The first Space press narrates Founder Takeaways rather than skipping to topic one.
- Narration speed defaults to **1.2×**, shown beside the Volume slider.
- Committing a Volume-slider change cancels and restarts narration from the beginning of the active card using the selected volume.
- Every date remembers its exact active card during the review session. Returning to a date restores that card at its exact boundary, never an arbitrary mid-card scroll position.
- The center previous/next navigation label displays the active ISO cron date and updates on all date changes.
- Reloading the whole page intentionally starts again at Founder Takeaways.

## Open

Double-click:

`1_OPEN_FULL_BRIEFS_AI_REVIEW.command`

It starts a read-only local server on `127.0.0.1:9120` and opens Brave. If macOS asks for confirmation, choose **Open**.

Opening the page is silent. Pressing Space or the page's Play control can produce Briefs-AI narration. Changing the Volume slider while reviewing restarts narration for the active card.

## Stop

When finished, double-click:

`2_STOP_BRIEFS_AI_REVIEW.command`

## Safety

- No Hermes files are installed or modified.
- Production port 9119 is not used.
- Port 9120 is never killed or replaced if another process owns it.
- The preview API is read-only and serves only the five bundled pairs.
- The sandbox boundary remains enabled; V62 uses `postMessage` only for date/card index state.
- Other dashboard sidebar pages are outside this review package's scope.
- Finder metadata and all symbolic links are excluded.
