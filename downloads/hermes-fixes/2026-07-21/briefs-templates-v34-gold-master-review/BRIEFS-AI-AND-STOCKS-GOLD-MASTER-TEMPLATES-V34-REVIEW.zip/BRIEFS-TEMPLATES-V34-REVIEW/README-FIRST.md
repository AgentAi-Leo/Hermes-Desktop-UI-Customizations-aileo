# Start here

Read `README_FIRST.md`.

To review the isolated V34 gold masters in Brave, double-click:

```text
1_OPEN_BRIEFS_TEMPLATES_V34_REVIEW.command
```

To verify every checksum and offline contract, double-click:

```text
3_VERIFY_BRIEFS_TEMPLATES_V34.command
```
