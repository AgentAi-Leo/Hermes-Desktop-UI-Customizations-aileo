# Stock Brief

**Brief Date:** July 16, 2026

7:13pm - America/Los_Angeles

## Portfolio Position Comparison
Daily prices compared with your purchase lots. Precise basis uses shares × purchased price.

| Position | Shares | Purchased price | Current price | +/- | Cost basis | Current value | Gain / loss | Return |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| APPLE-1 · AAPL (5/29/24) | 146 | $191.00 | $333.26 | +$142.26 | $27,886.00 | $48,655.96 | +$20,769.96 | +74.48% |
| DISNEY · DIS (8/05/66) | 268 | $25.00 | $99.71 | +$74.71 | $6,700.00 | $26,722.28 | +$20,022.28 | +298.84% |
| NVIDIA · NVDA (5/29/24) | 204 | $123.00 | $207.40 | +$84.40 | $25,092.00 | $42,309.60 | +$17,217.60 | +68.62% |
| AMAZON-1 · AMZN (5/29/24) | 138 | $181.00 | $249.89 | +$68.89 | $24,978.00 | $34,484.82 | +$9,506.82 | +38.06% |
| APPLE-2 · AAPL (4/28/26) | 57 | $266.00 | $333.26 | +$67.26 | $15,162.00 | $18,995.82 | +$3,833.82 | +25.29% |
| ALPHABET-1 · GOOGL (4/21/26) | 101 | $336.00 | $354.46 | +$18.46 | $33,936.00 | $35,800.46 | +$1,864.46 | +5.49% |
| ALPHABET-2 · GOOGL (4/28/26) | 106 | $349.00 | $354.46 | +$5.46 | $36,994.00 | $37,572.76 | +$578.76 | +1.56% |
| AMAZON-2 · AMZN (4/29/26) | 65 | $268.00 | $249.89 | -$18.11 | $17,420.00 | $16,242.85 | -$1,177.15 | -6.76% |
| MICROSOFT · MSFT (4/21/26) | 83 | $419.00 | $401.10 | -$17.90 | $34,777.00 | $33,291.30 | -$1,485.70 | -4.27% |
| SNAP · SNAP (2/3/26) | 1,786 | $6.18 | $4.69 | -$1.49 | $11,037.48 | $8,376.34 | -$2,661.14 | -24.11% |
| Available-position total |  |  |  |  | $233,982.48 | $302,452.19 | +$68,469.71 | +29.26% |

## DIS
### THE WALT DISNEY CO.
Date · July 16, 2026
Performance · ▲ +$2.56 (+2.64%)
Price · $99.71
Day High · $99.84 · Day Low · $97.47 · 52-week High · $123.40 · 52-week Low · $92.19 · Volume · 7,324,020

## AAPL
### APPLE INC.
Date · July 16, 2026
Performance · ▲ +$5.76 (+1.76%)
Price · $333.26
Day High · $334.68 · Day Low · $326.79 · 52-week High · $334.68 · 52-week Low · $201.50 · Volume · 62,673,782

## MSFT
### MICROSOFT CORP.
Date · July 16, 2026
Performance · ▲ +$5.47 (+1.38%)
Price · $401.10
Day High · $405.99 · Day Low · $392.05 · 52-week High · $555.45 · 52-week Low · $349.20 · Volume · 34,338,326

## SNAP
### SNAP INC.
Date · July 16, 2026
Performance · ▼ -$0.07 (-1.47%)
Price · $4.69
Day High · $4.81 · Day Low · $4.53 · 52-week High · $10.41 · 52-week Low · $3.81 · Volume · 37,051,592

## AMZN
### AMAZON.COM, INC.
Date · July 16, 2026
Performance · ▼ -$5.07 (-1.99%)
Price · $249.89
Day High · $258.08 · Day Low · $248.00 · 52-week High · $278.56 · 52-week Low · $196.00 · Volume · 44,640,934

## NVDA
### NVIDIA CORP.
Date · July 16, 2026
Performance · ▼ -$5.10 (-2.40%)
Price · $207.40
Day High · $211.08 · Day Low · $205.85 · 52-week High · $236.54 · 52-week Low · $164.07 · Volume · 116,253,420

## GOOGL
### ALPHABET INC.
Date · July 16, 2026
Performance · ▼ -$16.46 (-4.44%)
Price · $354.46
Day High · $375.27 · Day Low · $352.32 · 52-week High · $408.61 · 52-week Low · $180.48 · Volume · 40,951,931

<!-- HERMES_BRIEFS_EXPORT_MANIFEST {"accepted_ui":"v74-ticker-above-company","format":"markdown","kind":"stock","html_self_contained":false,"inline_css":false,"inline_javascript":false,"companion_html_pattern":"BRIEFS-STOCKS - YYYY-MM-DD.html","purpose":"Semantic content export; use the companion HTML export for the accepted visual and interactive recreation."} -->
