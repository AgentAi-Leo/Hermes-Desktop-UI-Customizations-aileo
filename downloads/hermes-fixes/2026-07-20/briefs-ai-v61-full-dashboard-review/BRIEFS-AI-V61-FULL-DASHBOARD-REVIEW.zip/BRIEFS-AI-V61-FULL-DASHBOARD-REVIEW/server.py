#!/usr/bin/env python3
"""Read-only preview server for the preserved V61/V74 Hermes dashboard build."""
from __future__ import annotations

import json
import mimetypes
import os
from datetime import datetime
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, unquote
from zoneinfo import ZoneInfo

HOST = "127.0.0.1"
PORT = int(os.environ.get("BRIEFS_AI_PREVIEW_PORT", "9120"))
ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web_dist"
REFS = ROOT / "REFERENCES"
DATES = ["2026-07-20", "2026-07-18", "2026-07-17", "2026-07-16", "2026-07-15"]
GENERATED_LOCAL = {
    "2026-07-20": "08:11:40",
    "2026-07-18": "10:07:08",
    "2026-07-17": "20:01:18",
    "2026-07-16": "20:09:04",
    # The preserved July 15 reference does not record a precise run time.
    "2026-07-15": "08:00:00",
}


def generated_at(date: str) -> int:
    local_time = GENERATED_LOCAL[date]
    return int(datetime.fromisoformat(f"{date}T{local_time}").replace(tzinfo=ZoneInfo("America/Los_Angeles")).timestamp())


def listing() -> dict:
    return {
        "kind": "ai",
        "label": "BRIEFS-AI",
        "root": "~/.hermes/zDownloads/__AI-DAILY-BRIEFS",
        "count": len(DATES),
        "briefs": [
            {
                "date": date,
                "generated_at": generated_at(date),
                "html_exists": True,
                "markdown_exists": True,
                "html_route": f"/preview-api/briefs-ai/{date}.html",
                "markdown_route": f"/preview-api/briefs-ai/{date}.md",
            }
            for date in DATES
        ],
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "HermesBriefsAcceptedPreview/1"

    def log_message(self, fmt: str, *args) -> None:
        print(f"{self.command} {self.path} :: {fmt % args}", flush=True)

    def send_bytes(self, data: bytes, content_type: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, value: object, status: int = 200) -> None:
        self.send_bytes(json.dumps(value).encode(), "application/json; charset=utf-8", status)

    def do_GET(self) -> None:
        path = unquote(urlparse(self.path).path)
        if path == "/api/briefs/ai":
            return self.send_json(listing())
        if path == "/api/profiles":
            return self.send_json({"profiles": [{"name": "local-ai-assist1", "description": "Read-only accepted-layout review"}]})
        if path == "/api/profiles/active":
            return self.send_json({"active": "local-ai-assist1", "current": "local-ai-assist1"})
        if path == "/api/status":
            return self.send_json({"status": "ok", "gateway": "preview", "version": "accepted-v61-v74"})
        if path == "/api/auth/me":
            return self.send_json({"user_id": "local-preview", "display_name": "Accepted layout review", "provider": "local", "authenticated": True, "required": False})
        if path == "/api/config":
            return self.send_json({"dashboard": {"show_token_analytics": False}})
        if path == "/api/dashboard/plugins":
            return self.send_json([])
        if path == "/api/dashboard/themes":
            return self.send_json({"active": "default", "themes": []})
        if path == "/api/dashboard/font":
            return self.send_json({"font": "theme"})
        if path.startswith("/preview-api/briefs-ai/"):
            name = Path(path).name
            candidate = REFS / f"BRIEFS-AI - {name}"
            if candidate.is_file() and candidate.parent == REFS:
                content_type = "text/html; charset=utf-8" if candidate.suffix == ".html" else "text/markdown; charset=utf-8"
                return self.send_bytes(candidate.read_bytes(), content_type)
            return self.send_json({"error": "not found"}, 404)
        if path.startswith("/api/"):
            # The Briefs page does not depend on unrelated dashboard APIs.
            return self.send_json({"error": "disabled in read-only Briefs review", "path": path}, 404)

        rel = "index.html" if path in ("/", "/briefs-ai") else path.lstrip("/")
        target = (WEB / rel).resolve()
        if not str(target).startswith(str(WEB.resolve())) or not target.is_file():
            # SPA fallback for client routes.
            target = WEB / "index.html"
        mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        return self.send_bytes(target.read_bytes(), f"{mime}; charset=utf-8" if mime.startswith("text/") else mime)


if __name__ == "__main__":
    print(f"READ_ONLY_ACCEPTED_BRIEFS_PREVIEW=http://{HOST}:{PORT}/briefs-ai", flush=True)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
