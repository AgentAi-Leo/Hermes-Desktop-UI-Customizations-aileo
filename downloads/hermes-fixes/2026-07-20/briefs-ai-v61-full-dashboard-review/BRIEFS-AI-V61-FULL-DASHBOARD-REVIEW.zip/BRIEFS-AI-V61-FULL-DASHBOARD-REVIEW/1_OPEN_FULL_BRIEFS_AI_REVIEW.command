#!/bin/bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
URL="http://127.0.0.1:9120/briefs-ai"
PID_FILE="${TMPDIR:-/tmp}/hermes-briefs-ai-v61-full-review.pid"
LOG_FILE="${TMPDIR:-/tmp}/hermes-briefs-ai-v61-full-review.log"
SERVER="$DIR/server.py"

show_error() {
  /usr/bin/osascript -e "display alert \"Briefs AI review could not open\" message \"$1\" as critical" >/dev/null 2>&1 || true
  printf '\n%s\n\nLog: %s\n' "$1" "$LOG_FILE"
  read -r -p "Press Return to close..." _
  exit 1
}

PY="$HOME/.hermes/hermes-agent/venv/bin/python"
if [[ ! -x "$PY" ]]; then
  PY="$(command -v python3 || true)"
fi
[[ -n "$PY" && -x "$PY" ]] || show_error "Python 3 was not found. No files were changed."

if [[ -f "$PID_FILE" ]]; then
  OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [[ "$OLD_PID" =~ ^[0-9]+$ ]] && kill -0 "$OLD_PID" 2>/dev/null; then
    OLD_COMMAND="$(ps -p "$OLD_PID" -o command= 2>/dev/null || true)"
    if [[ "$OLD_COMMAND" == *"$SERVER"* ]]; then
      /usr/bin/open -a "Brave Browser" "$URL"
      exit 0
    fi
  fi
  rm -f "$PID_FILE"
fi

if /usr/sbin/lsof -nP -iTCP:9120 -sTCP:LISTEN >/dev/null 2>&1; then
  show_error "Port 9120 is already in use by another process. Nothing was stopped or changed."
fi

nohup "$PY" "$SERVER" >"$LOG_FILE" 2>&1 &
PID=$!
printf '%s\n' "$PID" > "$PID_FILE"

READY=0
for _ in {1..50}; do
  if /usr/bin/curl -fsS "$URL" >/dev/null 2>&1; then
    READY=1
    break
  fi
  if ! kill -0 "$PID" 2>/dev/null; then break; fi
  sleep 0.1
done

if [[ "$READY" != "1" ]]; then
  kill "$PID" 2>/dev/null || true
  rm -f "$PID_FILE"
  show_error "The read-only preview server did not become ready. No Hermes files were changed."
fi

/usr/bin/open -a "Brave Browser" "$URL"
printf '\nOpened the complete Briefs AI V61 dashboard review in Brave.\n'
printf 'This is read-only and does not modify Hermes or production port 9119.\n'
printf 'Use 2_STOP_BRIEFS_AI_REVIEW.command when you finish.\n\n'
