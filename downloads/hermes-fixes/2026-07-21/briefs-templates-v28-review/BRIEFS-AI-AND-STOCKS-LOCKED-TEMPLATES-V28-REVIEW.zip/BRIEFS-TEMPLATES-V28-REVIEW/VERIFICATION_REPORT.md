# V28 verification report

## Scope

Read-only cumulative review of locked BRIEFS-AI and BRIEFS-STOCKS templates. Production port `9119`, live Hermes files, live cron definitions, and the user-managed legacy preview folder were not modified.

## Architecture

```text
model cron emits strict JSON
  → schema validation
  → no-agent deterministic materializer
  → locked renderer owns HTML/CSS/JS/Markdown/CSV
  → output validation
  → atomic publication
  → last valid Brief retained on any failure
```

## Source and build gates

- Focused Brief tests: `74/74` passed.
- Complete frontend tests: `146/146` passed.
- TypeScript typecheck: passed.
- Production Vite build: passed.
- Renderer/materializer tests: `16/16` passed.
- Compiled dashboard assets: `index-DXX00A1U.js` and `index-CAF841U8.css`.

## Muted browser-engine probe

The browser probe ran in a fresh local Chromium context with a fake speech engine; it produced no sound.

### BRIEFS-AI

- Initial active card: Founder Takeaways.
- Initial centered date: `July 20, 2026`.
- Initial speed: `1.2x`.
- Numbered topics: seven.
- Right navigation: Topic 1 → 2 → 3 → 4 → 5 → 6 → 7 → 1.
- Left wrap: Topic 1 → Topic 7.
- Speed cycle: `1.2x → 1.5x → 1.75x → 1x → 1.2x`.
- Voice fixture contained Daniel and Samantha; Samantha was selected and Daniel was rejected.
- July 20 stored Topic 3, July 18 independently stored Topic 5, and July 20 restored Topic 3.

### BRIEFS-STOCKS

- Centered toolbar date: `July 20, 2026`; no `DATE` placeholder.
- Portfolio Position Comparison: present.
- Canonical quote rows: seven.
- Metrics per quote row: five.
- External archive scripts after canonicalization: zero.
- Inner daily-date pills: exactly one.

## Visual evidence

- `EVIDENCE_AI_V28.png`: full Hermes dashboard, readable controls, centered date/speed, no visible toolbar overlap.
- `EVIDENCE_STOCKS_V28.png`: full Hermes dashboard, human toolbar date, Stock title/summary and Position Comparison visible without overlap.

## Limitations and approval gates

- The mocked browser voice test proves female-voice selection logic, not the installed macOS voice or audible quality. Warn before a real audible host test.
- This is a review package, not a production installer. Production cutover, cron prompt/path cutover, rollback verification, and deletion of the legacy preview remain deferred until explicit approval.
