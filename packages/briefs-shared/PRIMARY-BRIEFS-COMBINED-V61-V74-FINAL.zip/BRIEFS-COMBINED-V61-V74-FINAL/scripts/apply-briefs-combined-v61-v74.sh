#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PREVIEW="${HERMES_PREVIEW_ROOT:-$HOME/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
AGENT_ROOT="${HERMES_AGENT_ROOT:-/Users/jb3/.hermes/hermes-agent}"
PYTHON="${HERMES_PYTHON:-$AGENT_ROOT/venv/bin/python}"
WEB="$PREVIEW/web"
DIST="$PREVIEW/hermes_cli/web_dist"
SOURCE="$WEB/src/lib/briefs.ts"
PAGE="$WEB/src/pages/BriefsPage.tsx"
HOST_TEST="$WEB/src/lib/briefs.test.ts"
TEMP_TEST="$WEB/src/lib/briefs.candidate-v61-v74.test.ts"
PROFILE="local-ai-assist1"
PORT="${HERMES_PREVIEW_PORT:-9120}"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/.hermes/backups/briefs-combined-v61-v74-$STAMP"
LOG="$HOME/.hermes/logs/briefs-combined-v61-v74-${PORT}.log"
PREDECESSOR_SOURCE_SHA="932363f1663e5c1487eb7ddcf72216868c9694da46472016420b461aea8286a9"
PREDECESSOR_PAGE_SHA="c2ed9653b71c0136abc14414058bbd241b80b47cda69e54f8a23c48643a8b245"
PREDECESSOR_TEST_SHA="8cac13b5f0aaf46afa7fb65f88f459605129b45d1dd94a3df869777617c9c97b"
AUDITED_MAC_SOURCE_SHA="a88824f783c415071f7f1a02137e8f66e7138fbaf44a26291067880b52689b2e"
AUDITED_MAC_PAGE_SHA="c2ed9653b71c0136abc14414058bbd241b80b47cda69e54f8a23c48643a8b245"
AUDITED_MAC_TEST_SHA="17c741c1b48d8149ac95677315e4cdf764e74ebe3c59906c1070ba37dd7db4fd"
CANDIDATE_SOURCE_SHA="63d8b99c4dcc988dae3d22e173415322ebbb12120d34dfd2e0e65d3f6dc8a088"
CANDIDATE_PAGE_SHA="8e4473ac81ca9104c8fb55b999a2fb476f3ff601ca7c5c086b7aa26ccbf9116d"
CANDIDATE_TEST_SHA="8cac13b5f0aaf46afa7fb65f88f459605129b45d1dd94a3df869777617c9c97b"
BACKUP_READY=0
SERVER_TOUCHED=0
HOST_TEST_BEFORE=""

sha256_file() { shasum -a 256 "$1" | cut -d ' ' -f 1; }
stop_preview() {
  local pids i
  pids="$(lsof -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true)"
  if [[ -n "$pids" ]]; then
    kill $pids 2>/dev/null || true
    for i in $(seq 1 50); do
      [[ -z "$(lsof -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true)" ]] && return 0
      sleep 0.1
    done
    pids="$(lsof -tiTCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true)"
    [[ -z "$pids" ]] || kill -9 $pids 2>/dev/null || true
  fi
}
start_preview() {
  mkdir -p "$(dirname "$LOG")"
  (cd "$PREVIEW" && nohup env PYTHONPATH="$PREVIEW" HERMES_WEB_DIST="$DIST" "$PYTHON" -m hermes_cli.main --profile "$PROFILE" dashboard --isolated --port "$PORT" --no-open >"$LOG" 2>&1 &)
}
wait_preview() {
  local i
  for i in $(seq 1 60); do
    curl -fsS "http://127.0.0.1:$PORT/" >/dev/null 2>&1 && return 0
    sleep 1
  done
  return 1
}
restore_after_failure() {
  rm -f "$TEMP_TEST"
  if [[ "$BACKUP_READY" == "1" ]]; then
    cp "$BACKUP/web/src/lib/briefs.ts" "$SOURCE"
    cp "$BACKUP/web/src/pages/BriefsPage.tsx" "$PAGE"
    rm -rf "$DIST"
    cp -R "$BACKUP/hermes_cli/web_dist" "$DIST"
    if [[ "$SERVER_TOUCHED" == "1" ]]; then
      stop_preview || true
      start_preview || true
      wait_preview || true
    fi
    echo "RESTORED_AFTER_FAILURE=$BACKUP" >&2
  fi
}
trap 'r=$?; if [[ $r -ne 0 ]]; then restore_after_failure; else rm -f "$TEMP_TEST"; fi; exit $r' EXIT

for required in "$ROOT/CHECKSUMS.sha256" "$ROOT/SOURCE/briefs.ts" "$ROOT/SOURCE/BriefsPage.tsx" "$ROOT/SOURCE/briefs.candidate-v61-v74.test.ts" "$PYTHON" "$SOURCE" "$PAGE" "$HOST_TEST" "$WEB/package.json" "$DIST/index.html"; do
  [[ -e "$required" ]] || { echo "Missing required path: $required" >&2; exit 1; }
done
[[ -x "$PYTHON" ]] || { echo "Hermes Python is not executable: $PYTHON" >&2; exit 1; }
(cd "$ROOT" && shasum -a 256 -c CHECKSUMS.sha256)
[[ "$(sha256_file "$ROOT/SOURCE/briefs.ts")" == "$CANDIDATE_SOURCE_SHA" ]] || { echo "Packaged briefs.ts checksum mismatch" >&2; exit 1; }
[[ "$(sha256_file "$ROOT/SOURCE/BriefsPage.tsx")" == "$CANDIDATE_PAGE_SHA" ]] || { echo "Packaged BriefsPage.tsx checksum mismatch" >&2; exit 1; }
[[ "$(sha256_file "$ROOT/SOURCE/briefs.candidate-v61-v74.test.ts")" == "$CANDIDATE_TEST_SHA" ]] || { echo "Packaged test checksum mismatch" >&2; exit 1; }

SOURCE_BEFORE="$(sha256_file "$SOURCE")"
PAGE_BEFORE="$(sha256_file "$PAGE")"
HOST_TEST_BEFORE="$(sha256_file "$HOST_TEST")"
if [[ "$SOURCE_BEFORE" == "$CANDIDATE_SOURCE_SHA" && "$PAGE_BEFORE" == "$CANDIDATE_PAGE_SHA" && "$HOST_TEST_BEFORE" == "$CANDIDATE_TEST_SHA" ]]; then
  SOURCE_STATE_BEFORE="candidate"
elif [[ "$SOURCE_BEFORE" == "$CANDIDATE_SOURCE_SHA" && "$PAGE_BEFORE" == "$CANDIDATE_PAGE_SHA" && "$HOST_TEST_BEFORE" == "$AUDITED_MAC_TEST_SHA" ]]; then
  SOURCE_STATE_BEFORE="candidate-from-audited-mac"
elif [[ "$SOURCE_BEFORE" == "$PREDECESSOR_SOURCE_SHA" && "$PAGE_BEFORE" == "$PREDECESSOR_PAGE_SHA" && "$HOST_TEST_BEFORE" == "$PREDECESSOR_TEST_SHA" ]]; then
  SOURCE_STATE_BEFORE="v74-final-predecessor"
elif [[ "$SOURCE_BEFORE" == "$AUDITED_MAC_SOURCE_SHA" && "$PAGE_BEFORE" == "$AUDITED_MAC_PAGE_SHA" && "$HOST_TEST_BEFORE" == "$AUDITED_MAC_TEST_SHA" ]]; then
  SOURCE_STATE_BEFORE="audited-mac-preview-2026-07-17"
else
  echo "FAIL_CLOSED_INCOMPATIBLE_SOURCE" >&2
  echo "Accepted tuples: exact audited Mac preview, exact V74-final predecessor, exact V61/V74 candidate, or exact post-audited-bridge candidate." >&2
  echo "briefs.ts=$SOURCE_BEFORE" >&2
  echo "BriefsPage.tsx=$PAGE_BEFORE" >&2
  echo "briefs.test.ts=$HOST_TEST_BEFORE" >&2
  exit 1
fi

mkdir -p "$BACKUP/web/src/lib" "$BACKUP/web/src/pages" "$BACKUP/hermes_cli"
cp "$SOURCE" "$BACKUP/web/src/lib/briefs.ts"
cp "$PAGE" "$BACKUP/web/src/pages/BriefsPage.tsx"
cp -R "$DIST" "$BACKUP/hermes_cli/web_dist"
BACKUP_READY=1

cp "$ROOT/SOURCE/briefs.ts" "$SOURCE"
cp "$ROOT/SOURCE/BriefsPage.tsx" "$PAGE"
cp "$ROOT/SOURCE/briefs.candidate-v61-v74.test.ts" "$TEMP_TEST"
[[ "$(sha256_file "$SOURCE")" == "$CANDIDATE_SOURCE_SHA" ]]
[[ "$(sha256_file "$PAGE")" == "$CANDIDATE_PAGE_SHA" ]]
[[ "$(sha256_file "$TEMP_TEST")" == "$CANDIDATE_TEST_SHA" ]]

cd "$WEB"
npm test -- --run src/lib/briefs.candidate-v61-v74.test.ts
rm -f "$TEMP_TEST"
npx tsc --noEmit
npm run build

"$PYTHON" - "$DIST" <<'PY'
import re, sys
from pathlib import Path
dist = Path(sys.argv[1])
index = (dist / "index.html").read_text()
match = re.search(r'src="([^"]*index-[^"]+\.js)"', index)
if not match:
    raise SystemExit("Built JavaScript asset missing from index.html")
asset = dist / match.group(1).lstrip("./").lstrip("/")
data = asset.read_bytes()
markers = (
    b"v61-date-load-keyboard-focus",
    b"v74-ticker-above-company",
    b"hermes-ai-stable-date-frame",
    b"hermes-ai-stop-audio",
    b"hermes-ai-viewport-restore",
    b"activeCardByDate",
    b"focusActiveFrame",
    b"preventScroll",
    b"Spacebar",
    b"hermes-stock-viewport-state",
    b"hermes-stock-viewport-restore",
    b"#hermes-stock-viewport=",
    b"hermes-stock-fullscreen-toggle",
    b"hermes-stock-row-date",
    b"hermes-portfolio-comparison",
    b"#ffe08a",
)
for marker in markers:
    if marker not in data:
        raise SystemExit(f"Built asset missing marker: {marker.decode()}")
print(f"BUILT_ASSET={asset.name}")
PY

if [[ "${HERMES_TEST_FORCE_POST_BUILD_FAILURE:-0}" == "1" ]]; then
  echo "FORCED_POST_BUILD_FAILURE" >&2
  exit 97
fi

if [[ "${SKIP_RESTART:-0}" != "1" ]]; then
  SERVER_TOUCHED=1
  stop_preview
  start_preview
  wait_preview || { echo "Preview did not become ready; see $LOG" >&2; exit 1; }
  LIVE_INDEX_FILE="$BACKUP/live-index.html"
  LIVE_JS_FILE="$BACKUP/live-asset.js"
  LIVE_ASSET_PATH_FILE="$BACKUP/live-asset-path.txt"
  curl -fsS "http://127.0.0.1:$PORT/" -o "$LIVE_INDEX_FILE"
  "$PYTHON" -c 'import re,sys; from pathlib import Path; html=Path(sys.argv[1]).read_text(); m=re.search(r"src=.(?P<asset>[^ >]*index-[^ >]+[.]js).", html); print(m.group("asset") if m else "")' "$LIVE_INDEX_FILE" > "$LIVE_ASSET_PATH_FILE"
  IFS= read -r LIVE_ASSET_PATH < "$LIVE_ASSET_PATH_FILE" || true
  [[ -n "$LIVE_ASSET_PATH" ]] || { echo "Live asset path missing" >&2; exit 1; }
  curl -fsS "http://127.0.0.1:$PORT/${LIVE_ASSET_PATH#/}" -o "$LIVE_JS_FILE"
  "$PYTHON" - "$LIVE_JS_FILE" <<'PY'
import sys
from pathlib import Path
data = Path(sys.argv[1]).read_bytes()
for marker in (b"v61-date-load-keyboard-focus", b"v74-ticker-above-company", b"focusActiveFrame", b"hermes-stock-row-date"):
    if marker not in data:
        raise SystemExit(f"Live asset missing marker: {marker.decode()}")
print(f"LIVE_ASSET={Path(sys.argv[1]).name}")
PY
fi

[[ "$(sha256_file "$SOURCE")" == "$CANDIDATE_SOURCE_SHA" ]]
[[ "$(sha256_file "$PAGE")" == "$CANDIDATE_PAGE_SHA" ]]
[[ "$(sha256_file "$HOST_TEST")" == "$HOST_TEST_BEFORE" ]] || { echo "Permanent host test changed" >&2; exit 1; }
[[ ! -e "$TEMP_TEST" ]] || { echo "Temporary test was not removed" >&2; exit 1; }

trap - EXIT
BACKUP_READY=0
if [[ "${SKIP_OPEN:-0}" != "1" && "${SKIP_RESTART:-0}" != "1" ]]; then
  open "http://127.0.0.1:$PORT/briefs-ai?profile=$PROFILE&candidate=v61-v74-$(date +%s)"
fi
echo "BRIEFS_COMBINED_V61_V74_INSTALL=PASS"
echo "SOURCE_STATE_BEFORE=$SOURCE_STATE_BEFORE"
echo "SOURCE_SHA=$CANDIDATE_SOURCE_SHA"
echo "PAGE_SHA=$CANDIDATE_PAGE_SHA"
echo "PERMANENT_TEST_UNCHANGED=PASS"
echo "FOCUSED_TESTS=54/54"
echo "TYPECHECK=PASS"
echo "BUILD=PASS"
echo "BACKUP=$BACKUP"
echo "PRODUCTION_9119=UNTOUCHED"
