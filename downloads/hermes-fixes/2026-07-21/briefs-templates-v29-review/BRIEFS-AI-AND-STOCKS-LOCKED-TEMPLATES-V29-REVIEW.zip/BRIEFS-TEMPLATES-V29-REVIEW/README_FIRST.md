# Locked Brief templates V29 — AI + Stocks review

This read-only cumulative review package contains the deterministic AI and Stocks templates, bundled references, compiled dashboard, and verification source.

## V29 corrections

- The centered navigator is the sole AI date pill; the duplicate date beside Founder Takeaways is removed.
- AI and Stocks date-navigation arrows and centered date use cyan.
- AI speed choices are `1x → 1.25x → 1.5x → 1.75x`; default `1.25x`.
- `S` moves one speed step faster and wraps; `Shift+S` moves one step slower and wraps.

## Existing interaction contract

- **Space:** play/pause the active AI card.
- **Left / Right:** previous/next numbered AI card, with wraparound in both directions.
- **Up:** Founder Takeaways.
- **S / Shift+S:** faster/slower playback-speed step.
- **Enter:** fullscreen. **Escape:** browser fullscreen exit.
- **Voice:** approved female/natural names only; no generic browser/default voice fallback.

## Deterministic architecture

```text
strict JSON → schema validation → locked renderer → output validation → atomic publication
```

The model supplies changing data only. It cannot supply template HTML, CSS, JavaScript, controls, layout, or CSV design. Invalid data preserves the last valid Brief.

## Review

Double-click:

```text
1_OPEN_BRIEFS_TEMPLATES_V29_REVIEW.command
```

It opens both templates in Brave on isolated port `9123`. Opening is silent; pressing Play or Space can produce AI narration.

When finished, double-click:

```text
2_STOP_BRIEFS_TEMPLATES_V29_REVIEW.command
```

## Safety

No Hermes files, cron jobs, production port `9119`, V28 package files, or `_BRIEFS-DASHBOARD-V3-PREVIEW` files are modified.
