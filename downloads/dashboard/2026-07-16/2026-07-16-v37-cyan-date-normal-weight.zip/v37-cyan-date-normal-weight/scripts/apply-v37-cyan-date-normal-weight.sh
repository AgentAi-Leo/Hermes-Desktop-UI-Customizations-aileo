#!/usr/bin/env bash
set -euo pipefail
PREVIEW_ROOT="${1:-/Users/jb3/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
PROFILE_ROOT="${2:-/Users/jb3/.hermes/profiles/local-ai-assist1}"
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date +%Y-%m-%d-%H%M%S)"
BACKUP="$PREVIEW_ROOT/.hermes-ui-customization-backups/v37-$STAMP-cyan-date-normal-weight"
if [ -n "${HERMES_PYTHON:-}" ] && [ -x "$HERMES_PYTHON" ]; then
  PYTHON_BIN="$HERMES_PYTHON"
elif [ -x "/Users/jb3/.hermes/hermes-agent/venv/bin/python" ]; then
  PYTHON_BIN="/Users/jb3/.hermes/hermes-agent/venv/bin/python"
elif command -v python3 >/dev/null 2>&1; then
  PYTHON_BIN="$(command -v python3)"
elif command -v python >/dev/null 2>&1; then
  PYTHON_BIN="$(command -v python)"
else
  echo "No usable Python interpreter found" >&2
  exit 1
fi
for path in \
  "$PREVIEW_ROOT/hermes_cli/web_server.py" \
  "$PREVIEW_ROOT/tests/hermes_cli/test_web_server_briefs.py" \
  "$PREVIEW_ROOT/web/src/lib/api.ts" \
  "$PREVIEW_ROOT/web/src/lib/briefs.ts" \
  "$PREVIEW_ROOT/web/src/lib/briefs.test.ts" \
  "$PREVIEW_ROOT/web/src/pages/BriefsPage.tsx" \
  "$PREVIEW_ROOT/web/src/pages/GitCommentsDashboardPage.tsx" \
  "$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js"; do
  [[ -f "$path" ]] || { echo "Missing $path" >&2; exit 1; }
done
mkdir -p "$BACKUP/preview/hermes_cli" "$BACKUP/preview/tests/hermes_cli" "$BACKUP/preview/web/src/lib" "$BACKUP/preview/web/src/pages" "$BACKUP/profile/plugins/git-comments/dashboard/dist"
cp "$PREVIEW_ROOT/hermes_cli/web_server.py" "$BACKUP/preview/hermes_cli/web_server.py"
cp "$PREVIEW_ROOT/tests/hermes_cli/test_web_server_briefs.py" "$BACKUP/preview/tests/hermes_cli/test_web_server_briefs.py"
cp "$PREVIEW_ROOT/web/src/lib/api.ts" "$BACKUP/preview/web/src/lib/api.ts"
cp "$PREVIEW_ROOT/web/src/lib/briefs.ts" "$BACKUP/preview/web/src/lib/briefs.ts"
cp "$PREVIEW_ROOT/web/src/lib/briefs.test.ts" "$BACKUP/preview/web/src/lib/briefs.test.ts"
cp "$PREVIEW_ROOT/web/src/pages/BriefsPage.tsx" "$BACKUP/preview/web/src/pages/BriefsPage.tsx"
cp "$PREVIEW_ROOT/web/src/pages/GitCommentsDashboardPage.tsx" "$BACKUP/preview/web/src/pages/GitCommentsDashboardPage.tsx"
cp "$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js" "$BACKUP/profile/plugins/git-comments/dashboard/dist/index.js"
cp "$PACKAGE_ROOT/files/hermes_cli/web_server.py" "$PREVIEW_ROOT/hermes_cli/web_server.py"
cp "$PACKAGE_ROOT/files/tests/hermes_cli/test_web_server_briefs.py" "$PREVIEW_ROOT/tests/hermes_cli/test_web_server_briefs.py"
cp "$PACKAGE_ROOT/files/web/src/lib/api.ts" "$PREVIEW_ROOT/web/src/lib/api.ts"
cp "$PACKAGE_ROOT/files/briefs.ts" "$PREVIEW_ROOT/web/src/lib/briefs.ts"
cp "$PACKAGE_ROOT/files/briefs.test.ts" "$PREVIEW_ROOT/web/src/lib/briefs.test.ts"
cp "$PACKAGE_ROOT/files/BriefsPage.tsx" "$PREVIEW_ROOT/web/src/pages/BriefsPage.tsx"
cp "$PACKAGE_ROOT/files/GitCommentsDashboardPage.tsx" "$PREVIEW_ROOT/web/src/pages/GitCommentsDashboardPage.tsx"
cp "$PACKAGE_ROOT/files/index.js" "$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js"
node --check "$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js"
"$PYTHON_BIN" -m py_compile \
  "$PREVIEW_ROOT/hermes_cli/web_server.py" \
  "$PREVIEW_ROOT/tests/hermes_cli/test_web_server_briefs.py"
(
  cd "$PREVIEW_ROOT/web"
  npm test -- --run src/lib/briefs.test.ts
  npm run build
)
printf '\nV37 cyan AI date arrows and normal-weight full-height DATE text, plus all cumulative V36 Brief behavior, applied and validated.\nRollback snapshot: %s\n' "$BACKUP"
printf 'Restart only isolated port 9120; production 9119 was not touched.\n'
