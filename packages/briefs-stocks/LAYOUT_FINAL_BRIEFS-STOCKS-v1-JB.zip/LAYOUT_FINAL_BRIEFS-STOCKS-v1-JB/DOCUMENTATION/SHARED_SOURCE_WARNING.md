# Shared source warning

BRIEFS-AI and BRIEFS-STOCKS use the same `src/lib/briefs.ts` and `src/pages/BriefsPage.tsx`. A feature-specific archive must therefore carry the complete final combined accepted state. This V74 Stock archive includes and verifies V61 AI behavior; it must never restore an older Stock-only source snapshot.
