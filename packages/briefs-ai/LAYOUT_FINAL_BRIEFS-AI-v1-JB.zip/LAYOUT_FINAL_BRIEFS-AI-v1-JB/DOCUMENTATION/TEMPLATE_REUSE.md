# Offline template reuse

The five dated V61 HTML files are self-contained visual and interaction references. Keep them together so relative cross-date navigation continues to work. Markdown companions are semantic content exports and intentionally contain no executable JavaScript.
