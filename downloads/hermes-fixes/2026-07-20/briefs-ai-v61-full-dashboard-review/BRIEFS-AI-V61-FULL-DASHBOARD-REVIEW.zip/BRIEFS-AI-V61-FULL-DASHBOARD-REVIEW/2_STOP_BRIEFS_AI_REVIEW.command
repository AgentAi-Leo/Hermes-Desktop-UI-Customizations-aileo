#!/bin/bash
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="${TMPDIR:-/tmp}/hermes-briefs-ai-v61-full-review.pid"
SERVER="$DIR/server.py"

if [[ ! -f "$PID_FILE" ]]; then
  printf '\nThe Briefs AI review server is not running.\n\n'
  exit 0
fi

PID="$(cat "$PID_FILE" 2>/dev/null || true)"
if [[ ! "$PID" =~ ^[0-9]+$ ]] || ! kill -0 "$PID" 2>/dev/null; then
  rm -f "$PID_FILE"
  printf '\nThe Briefs AI review server was already stopped.\n\n'
  exit 0
fi

COMMAND="$(ps -p "$PID" -o command= 2>/dev/null || true)"
if [[ "$COMMAND" != *"$SERVER"* ]]; then
  printf '\nSafety stop: the saved PID belongs to a different process. Nothing was stopped.\n\n'
  exit 1
fi

kill "$PID"
rm -f "$PID_FILE"
printf '\nStopped the read-only Briefs AI review server. Hermes was not changed.\n\n'
