# Shared-source warning

`BRIEFS-AI` and `BRIEFS-STOCKS` currently share `web/src/lib/briefs.ts`.

This AI V1 package records the accepted AI state plus the Stock state that existed at AI acceptance. Once Stocks is updated, this package alone must not overwrite the newer shared file. Its installer therefore fails closed on unknown hashes.

After the Stocks V1 package exists, restore AI first and Stocks second. The later Stocks package will carry the final shared-source state while preserving accepted AI behavior.
