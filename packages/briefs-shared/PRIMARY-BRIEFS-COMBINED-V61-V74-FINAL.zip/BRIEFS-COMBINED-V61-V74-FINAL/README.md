# BRIEFS Combined V61/V74 Final Restore

This cumulative package independently restores the accepted shared Briefs source state:

- BRIEFS-AI: `v61-date-load-keyboard-focus`
- BRIEFS-STOCKS: `v74-ticker-above-company`

The installer is fail-closed. It accepts only one of four exact source/page/test hash tuples: the Mac preview audited on 2026-07-17, the recovered V74-final predecessor, the final V61/V74 candidate, or the exact post-audited-bridge candidate whose permanent host test remains unchanged. It snapshots `briefs.ts`, `BriefsPage.tsx`, and the built distribution before writing; runs the packaged 54-test candidate suite as a temporary test file; leaves the host's permanent `briefs.test.ts` unchanged; runs TypeScript and the production build; verifies AI and Stock markers in the generated asset; and restores source/build automatically on failure.

Default target:

```text
~/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW
```

Default preview port: `9120`. Production port `9119`, Gateway, host Hermes source, cron, and iCloud are outside this installer.

Run from the extracted package root:

```bash
./scripts/apply-briefs-combined-v61-v74.sh
```

For isolated rehearsal without restarting a listener:

```bash
SKIP_RESTART=1 SKIP_OPEN=1 ./scripts/apply-briefs-combined-v61-v74.sh
```
