# Briefs gold-master templates V34 — AI + Stocks

This read-only package supersedes V33 for sharing and restoration. V33 remains unchanged as rollback.

## What V34 adds

V34 keeps the accepted Briefs-AI and Briefs-Stocks appearance and behavior, but makes every direct HTML export self-documenting:

- all HTML structure, CSS, and JavaScript required for offline use remains inline;
- every `<style>` block begins with a `GOLD MASTER STYLE` header describing its purpose and restoration responsibility;
- every `<script>` block begins with a `GOLD MASTER CONTROLLER` header describing purpose, state, inputs, outputs, dependencies, and restoration responsibility;
- canonical HTML sections are marked with `GOLD MASTER HTML` ownership comments;
- the top `V34 SELF-CONTAINED GOLD MASTER GUIDE` maps HTML/CSS/JavaScript ownership, security boundaries, companion formats, and restore order;
- the manifest schema is `briefs-v34-gold-master` with explicit documentation-contract fields.

No visual or behavioral change was intended. AI volume still defaults to 45% only when no valid preference exists; saved zero remains mute. Stocks presentation, Position Comparison, dynamic-data contracts, and CSV schemas remain unchanged.

## Direct-export format boundaries

- **HTML (10 files):** complete offline visual and interactive gold masters with inline CSS/JavaScript and descriptive comments.
- **Markdown (10 files):** semantic content/hierarchy companions. They intentionally contain no CSS or JavaScript and point to the companion HTML gold master.
- **Position Comparison CSV (5 files):** data-only interchange files. They intentionally contain no executable code or comments and retain trailing `Agent=HERMES`.
- **Stock quote CSV references (5 files):** canonical data inputs with trailing `Agent=HERMES`.

## Review

Double-click:

```text
1_OPEN_BRIEFS_TEMPLATES_V34_REVIEW.command
```

This opens the isolated V34 review in Brave on port `9128`. Opening is silent. Clicking Play or pressing Space in Briefs-AI may produce narration.

Stop with:

```text
2_STOP_BRIEFS_TEMPLATES_V34_REVIEW.command
```

Verify the sealed package with:

```text
3_VERIFY_BRIEFS_TEMPLATES_V34.command
```

## Evidence

- `EXPORT_AUDIT.json`: 25/25 static export checks.
- `QA/GOLD_MASTER_EXPORT_AUDIT.json`: 10 HTML, 10 Markdown, five CSV; 45/45 CSS blocks and 25/25 JavaScript controllers documented.
- `QA/BROWSER_AUDIT.json`: 40/40 Chromium behavior checks.
- `QA/DOWNLOAD_PARITY_AUDIT.json`: 25/25 real browser downloads byte-identical to bundled files.
- `QA/*.png`: dashboard and standalone visual evidence.
- `VERIFICATION_REPORT.md`: consolidated verification scope.

## Safety

- Production port `9119` is untouched.
- V32 and V33 are untouched.
- The installed host materializer and active cron jobs are untouched.
- The review server is local-only and read-only.
