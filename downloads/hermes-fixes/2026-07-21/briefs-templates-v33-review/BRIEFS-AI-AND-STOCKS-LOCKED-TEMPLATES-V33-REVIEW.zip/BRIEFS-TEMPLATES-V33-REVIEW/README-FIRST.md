# Start here

Read `README_FIRST.md`, then double-click `1_OPEN_BRIEFS_TEMPLATES_V33_REVIEW.command` to open the isolated V33 review in Brave.
