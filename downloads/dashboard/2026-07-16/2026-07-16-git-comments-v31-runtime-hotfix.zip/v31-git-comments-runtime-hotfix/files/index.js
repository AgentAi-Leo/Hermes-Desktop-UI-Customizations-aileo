(() => {
  const sdk = window.__HERMES_PLUGIN_SDK__;
  const { React, fetchJSON } = sdk;
  const { useEffect, useMemo, useState } = sdk.hooks;
  const e = React.createElement;
  const MessageCircle = null;

  const styles = `
.git-comments-page{padding:0 24px 32px;color:var(--foreground)}
.git-comments-health,.git-comments-panel{border:1px solid var(--border);background:var(--card);margin-top:20px}
.git-comments-health{padding:22px 28px;display:flex;align-items:center;justify-content:space-between;gap:24px;flex-wrap:wrap}
.git-comments-kicker{font-size:18px;letter-spacing:.16em;text-transform:uppercase}.git-comments-muted{color:var(--muted-foreground)}
.git-comments-summary{font-size:16px;letter-spacing:.08em}.git-comments-panel-title{padding:22px 28px;border-bottom:1px solid var(--border);font-size:22px;font-weight:750}
.git-comments-issue{margin:18px 28px;border:1px solid var(--border);border-radius:16px;overflow:hidden;background:rgba(18,26,51,.45)}
.git-comments-issue.received{border-color:#4ade80;box-shadow:0 0 0 2px rgba(74,222,128,.24)}
.git-comments-issue-head{display:flex;align-items:center;gap:12px;padding:15px 18px;border-bottom:1px solid var(--border)}
.git-comments-number{font-size:20px;font-weight:800}.git-comments-link{color:#5db3ff;text-decoration:none}.git-comments-status{margin-left:auto;font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted-foreground)}
.git-comments-status.received{color:#4ade80;font-weight:800}.git-comments-comments{display:grid;gap:12px;padding:14px}
.git-comments-comment{padding:16px;border:1px solid rgba(255,255,255,.09);border-radius:13px;background:#17213b}
.git-comments-comment.maintainer{border-color:rgba(74,222,128,.55)}.git-comments-author{display:flex;gap:10px;align-items:center;font-weight:750}
.git-comments-avatar{width:32px;height:32px;border-radius:50%}.git-comments-time{font-weight:400;color:var(--muted-foreground);font-size:13px}
.git-comments-body{white-space:pre-wrap;overflow-wrap:anywhere;margin-top:12px;color:#c4cce0;line-height:1.55}.git-comments-empty{padding:18px;color:var(--muted-foreground)}
`;

  function fmt(value) {
    if (!value) return "Never";
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString();
  }

  function authorName(comment) {
    return comment.author?.login || comment.user?.login || comment.user || comment.author || "unknown";
  }

  function avatar(comment) {
    return comment.author?.avatar_url || comment.user?.avatar_url || comment.avatar_url || "";
  }

  function Issue({ issue, owner }) {
    const comments = Array.isArray(issue.comments) ? issue.comments : [];
    const received = comments.filter((comment) => authorName(comment).toLowerCase() !== owner.toLowerCase());
    const hasReceived = received.length > 0 || Number(issue.new_received_count || 0) > 0;
    const number = issue.number || issue.issue_number;
    const url = issue.html_url || issue.issue_url || `https://github.com/NousResearch/hermes-agent/issues/${number}`;
    return e("section", { className: `git-comments-issue${hasReceived ? " received" : ""}` },
      e("div", { className: "git-comments-issue-head" },
        MessageCircle ? e(MessageCircle, { size: 18 }) : "💬",
        e("span", { className: "git-comments-number" }, `#${number}`),
        e("a", { className: "git-comments-link", href: url, target: "_blank", rel: "noreferrer" }, "View on GitHub →"),
        e("span", { className: `git-comments-status${hasReceived ? " received" : ""}` }, hasReceived ? `${received.length} received` : "watching")
      ),
      comments.length ? e("div", { className: "git-comments-comments" }, comments.map((comment) => {
        const fromMaintainer = authorName(comment).toLowerCase() !== owner.toLowerCase();
        return e("article", { key: comment.id || `${authorName(comment)}-${comment.created_at}`, className: `git-comments-comment${fromMaintainer ? " maintainer" : ""}` },
          e("div", { className: "git-comments-author" },
            avatar(comment) ? e("img", { className: "git-comments-avatar", src: avatar(comment), alt: "" }) : null,
            e("span", null, authorName(comment)),
            e("span", { className: "git-comments-time" }, fmt(comment.created_at))
          ),
          e("div", { className: "git-comments-body" }, comment.body || "")
        );
      })) : e("div", { className: "git-comments-empty" }, "No comments yet.")
    );
  }

  function GitCommentsPage() {
    const [state, setState] = useState({ loading: true, data: null, error: null });
    useEffect(() => {
      let alive = true;
      fetchJSON("/api/plugins/git-comments/data").then((data) => alive && setState({ loading: false, data, error: null })).catch((error) => alive && setState({ loading: false, data: null, error: String(error) }));
      return () => { alive = false; };
    }, []);
    const data = state.data || {};
    const issues = Array.isArray(data.issues) ? data.issues : [];
    const owner = data.owner || "AgentAi-Leo";
    const commented = useMemo(() => issues.filter((issue) => (issue.comments || []).some((comment) => authorName(comment).toLowerCase() !== owner.toLowerCase())).length, [issues, owner]);
    if (state.loading) return e("div", { className: "git-comments-page" }, "Loading Git Comments…");
    if (state.error) return e("div", { className: "git-comments-page" }, `Git Comments failed: ${state.error}`);
    return e(React.Fragment, null,
      e("style", null, styles),
      e("div", { className: "git-comments-page" },
        e("section", { className: "git-comments-health" },
          e("div", null, e("div", { className: "git-comments-kicker" }, "Watcher healthy"), e("div", { className: "git-comments-muted" }, `Last successful check: ${fmt(data.checked_at || data.updated)}`)),
          e("div", { className: "git-comments-summary" }, `WATCHING (${issues.length}) · COMMENTED (${commented})`)
        ),
        e("section", { className: "git-comments-panel" },
          e("div", { className: "git-comments-panel-title" }, "💼 GITHUB ISSUES"),
          issues.map((issue) => e(Issue, { key: issue.number || issue.issue_number, issue, owner }))
        )
      )
    );
  }

  window.__HERMES_PLUGINS__.register("git-comments", GitCommentsPage);
})();
