# Stock Brief

**Date:** July 15, 2026  
**Timezone:** America/Los_Angeles  
**Contract:** stock-brief-data-v1

## SUMMARY

**+$46,014.58**

## Portfolio Position Comparison

| Position | Shares | Purchased price | Current price | +/- | Cost basis | Current value | Gain / loss | Return |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| DISNEY · DIS<br>8/05/66 | 268 | $25.00 | $121.44 | +$96.44 | $6,700.00 | $32,545.92 | +$25,845.92 | +385.76% |
| APPLE-1 · AAPL<br>5/29/24 | 146 | $191.00 | $333.26 | +$142.26 | $27,886.00 | $48,655.96 | +$20,769.96 | +74.48% |
| NVIDIA · NVDA<br>5/29/24 | 204 | $123.00 | $191.55 | +$68.55 | $25,092.00 | $39,076.20 | +$13,984.20 | +55.73% |
| AMAZON-1 · AMZN<br>5/29/24 | 138 | $181.00 | $242.71 | +$61.71 | $24,978.00 | $33,493.98 | +$8,515.98 | +34.09% |
| MICROSOFT · MSFT<br>4/21/26 | 83 | $419.00 | $512.31 | +$93.31 | $34,777.00 | $42,521.73 | +$7,744.73 | +22.27% |
| APPLE-2 · AAPL<br>4/29/26 | 57 | $266.00 | $333.26 | +$67.26 | $15,162.00 | $18,995.82 | +$3,833.82 | +25.29% |
| AMAZON-2 · AMZN<br>4/29/26 | 65 | $268.00 | $242.71 | -$25.29 | $17,420.00 | $15,776.15 | -$1,643.85 | -9.44% |
| SNAP · SNAP<br>2/3/26 | 1,786 | $6.18 | $4.75 | -$1.43 | $11,037.48 | $8,483.50 | -$2,553.98 | -23.14% |
| ALPHABET-1 · GOOGL<br>4/21/26 | 101 | $336.00 | $195.40 | -$140.60 | $33,936.00 | $19,735.40 | -$14,200.60 | -41.85% |
| ALPHABET-2 · GOOGL<br>4/29/26 | 106 | $349.00 | $195.40 | -$153.60 | $36,994.00 | $20,712.40 | -$16,281.60 | -44.01% |
| **Available-position total** ||||| **$233,982.48** | **$279,997.06** | **+$46,014.58** | **+19.67%** |

## AAPL
### APPLE INC.

Date · July 15, 2026
Performance · ▲ +$5.76 (+1.76%)
Price · $333.26
Day High · $335.26 · Day Low · $331.26 · 52-week High · $353.26 · 52-week Low · $313.26 · Volume · 1,234,567
Source · [Yahoo Finance](https://finance.yahoo.com/quote/AAPL/)

## AMZN
### AMAZON.COM, INC.

Date · July 15, 2026
Performance · ▼ -$1.22 (-0.50%)
Price · $242.71
Day High · $244.71 · Day Low · $240.71 · 52-week High · $262.71 · 52-week Low · $222.71 · Volume · 2,469,134
Source · [Yahoo Finance](https://finance.yahoo.com/quote/AMZN/)

## NVDA
### NVIDIA CORPORATION

Date · July 15, 2026
Performance · ▲ +$2.00 (+1.06%)
Price · $191.55
Day High · $193.55 · Day Low · $189.55 · 52-week High · $211.55 · 52-week Low · $171.55 · Volume · 3,703,701
Source · [Yahoo Finance](https://finance.yahoo.com/quote/NVDA/)

## SNAP
### SNAP INC.

Date · July 15, 2026
Performance · ▼ -$0.08 (-1.66%)
Price · $4.75
Day High · $6.75 · Day Low · $2.75 · 52-week High · $24.75 · 52-week Low · $0.00 · Volume · 4,938,268
Source · [Yahoo Finance](https://finance.yahoo.com/quote/SNAP/)

## GOOGL
### ALPHABET INC.

Date · July 15, 2026
Performance · ▲ +$1.40 (+0.72%)
Price · $195.40
Day High · $197.40 · Day Low · $193.40 · 52-week High · $215.40 · 52-week Low · $175.40 · Volume · 6,172,835
Source · [Yahoo Finance](https://finance.yahoo.com/quote/GOOGL/)

## MSFT
### MICROSOFT CORPORATION

Date · July 15, 2026
Performance · ▲ +$3.31 (+0.65%)
Price · $512.31
Day High · $514.31 · Day Low · $510.31 · 52-week High · $532.31 · 52-week Low · $492.31 · Volume · 7,407,402
Source · [Yahoo Finance](https://finance.yahoo.com/quote/MSFT/)

## DIS
### THE WALT DISNEY COMPANY

Date · July 15, 2026
Performance · ▼ -$0.56 (-0.46%)
Price · $121.44
Day High · $123.44 · Day Low · $119.44 · 52-week High · $141.44 · 52-week Low · $101.44 · Volume · 8,641,969
Source · [Yahoo Finance](https://finance.yahoo.com/quote/DIS/)
