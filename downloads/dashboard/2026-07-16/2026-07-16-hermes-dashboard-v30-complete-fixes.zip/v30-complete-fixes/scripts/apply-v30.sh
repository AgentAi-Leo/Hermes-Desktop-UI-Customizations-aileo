#!/usr/bin/env bash
set -euo pipefail

PREVIEW_ROOT="${1:-/Users/jb3/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
PROFILE_ROOT="${2:-/Users/jb3/.hermes/profiles/local-ai-assist1}"
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date +%Y-%m-%d-%H%M%S)"
BACKUP="$PREVIEW_ROOT/.hermes-ui-customization-backups/v30-$STAMP-complete-fixes"

require_file() { [[ -f "$1" ]] || { printf 'Missing required file: %s\n' "$1" >&2; exit 1; }; }
require_file "$PREVIEW_ROOT/web/src/lib/briefs.ts"
require_file "$PREVIEW_ROOT/web/src/lib/briefs.test.ts"
require_file "$PREVIEW_ROOT/web/src/pages/BriefsPage.tsx"
require_file "$PACKAGE_ROOT/files/preview/web/src/lib/briefs.ts"
require_file "$PACKAGE_ROOT/files/profile/plugins/git-comments/dashboard/plugin_api.py"

mkdir -p "$BACKUP/preview/web/src/lib" "$BACKUP/preview/web/src/pages" "$BACKUP/profile"
cp "$PREVIEW_ROOT/web/src/lib/briefs.ts" "$BACKUP/preview/web/src/lib/briefs.ts"
cp "$PREVIEW_ROOT/web/src/lib/briefs.test.ts" "$BACKUP/preview/web/src/lib/briefs.test.ts"
cp "$PREVIEW_ROOT/web/src/pages/BriefsPage.tsx" "$BACKUP/preview/web/src/pages/BriefsPage.tsx"

for rel in \
  plugins/git-comments/dashboard/manifest.json \
  plugins/git-comments/dashboard/plugin_api.py \
  plugins/git-comments/dashboard/dist/index.js \
  scripts/github-comments-checker.sh; do
  if [[ -e "$PROFILE_ROOT/$rel" ]]; then
    mkdir -p "$BACKUP/profile/$(dirname "$rel")"
    cp "$PROFILE_ROOT/$rel" "$BACKUP/profile/$rel"
  fi
done

cp "$PACKAGE_ROOT/files/preview/web/src/lib/briefs.ts" "$PREVIEW_ROOT/web/src/lib/briefs.ts"
cp "$PACKAGE_ROOT/files/preview/web/src/lib/briefs.test.ts" "$PREVIEW_ROOT/web/src/lib/briefs.test.ts"
cp "$PACKAGE_ROOT/files/preview/web/src/pages/BriefsPage.tsx" "$PREVIEW_ROOT/web/src/pages/BriefsPage.tsx"

mkdir -p "$PROFILE_ROOT/plugins/git-comments/dashboard/dist" "$PROFILE_ROOT/scripts"
cp "$PACKAGE_ROOT/files/profile/plugins/git-comments/dashboard/manifest.json" "$PROFILE_ROOT/plugins/git-comments/dashboard/manifest.json"
cp "$PACKAGE_ROOT/files/profile/plugins/git-comments/dashboard/plugin_api.py" "$PROFILE_ROOT/plugins/git-comments/dashboard/plugin_api.py"
cp "$PACKAGE_ROOT/files/profile/plugins/git-comments/dashboard/dist/index.js" "$PROFILE_ROOT/plugins/git-comments/dashboard/dist/index.js"
cp "$PACKAGE_ROOT/files/profile/scripts/github-comments-checker.sh" "$PROFILE_ROOT/scripts/github-comments-checker.sh"
chmod 755 "$PROFILE_ROOT/scripts/github-comments-checker.sh"

bash "$PROFILE_ROOT/scripts/github-comments-checker.sh"
export PROFILE_ROOT
python3 - <<'PY'
import json
import os
from pathlib import Path
p=Path(os.environ['PROFILE_ROOT'])/'plugins/git-comments/dashboard/data/git-comments.json'
d=json.loads(p.read_text())
assert d.get('schema_version') == 2
issues={int(i['number']):i for i in d['issues']}
assert 58130 in issues and 58510 in issues
assert issues[58510]['received_count'] >= 1
print('Git Comments live snapshot verified:', d['checked_at'])
PY

(
  cd "$PREVIEW_ROOT/web"
  npm test -- --run src/lib/briefs.test.ts
  npm run build
)

printf '\nV30 complete fixes applied and validated.\nRollback snapshot: %s\n' "$BACKUP"
printf 'Restart only isolated port 9120; production 9119 was not touched.\n'
