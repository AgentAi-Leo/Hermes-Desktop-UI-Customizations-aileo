# V31 — Seven-topic AI Brief and Git Comments runtime fixes

This complete replacement package includes:

- AI player counts the seven numbered topic cards only; Founder Takeaways remains available via ArrowUp without inflating the topic total.
- Numbered sibling headings are wrapped into independent playable/highlightable cards when archives do not supply card wrappers.
- Immediate keyboard navigation, pointer-only volume, final-card active highlight, full-page HTML export, semantic Markdown, and Stock behavior from V30.
- Git Comments uses the live Hermes dashboard plugin SDK and correct `register(name, component)` runtime API.
- Profile-local Git Comments checker/API and atomic snapshot publishing.

The installer snapshots all replaced preview/profile files, refreshes Git Comments data, runs the focused Briefs suite, and builds the production frontend. It never restarts production `9119` or changes `000_BACKUP-5HRs`.
