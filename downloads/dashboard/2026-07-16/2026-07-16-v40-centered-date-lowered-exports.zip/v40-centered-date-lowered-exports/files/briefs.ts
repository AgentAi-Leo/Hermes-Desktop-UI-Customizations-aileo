import type { BriefEntry, BriefKind } from "@/lib/api";

export const BRIEF_PREVIEW_SANDBOX = "allow-scripts";
export const BRIEF_PLAYER_MESSAGE_TYPE = "hermes-brief-player-command";
export const BRIEF_DATE_NAV_MESSAGE_TYPE = "hermes-brief-date-navigation";
export const BRIEF_EXPORT_BUTTON_CLASS = "h-[3.375rem] min-h-[3.375rem] px-6 text-[1.125rem] tracking-[0.08em] [&_svg]:h-6 [&_svg]:w-6";

export function supportsBriefDateNavigation(kind: BriefKind): boolean {
  return kind === "ai" || kind === "stock";
}

const SCRIPT_ELEMENT = /<script\b[^>]*>[\s\S]*?<\/script\s*>/gi;
const EVENT_HANDLER_ATTRIBUTE = /\s+on[a-z][\w:.-]*\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi;
const URL_ATTRIBUTE = /\s+(?:href|src|action|formaction|xlink:href)\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi;
const SRCDOC_ATTRIBUTE = /\s+srcdoc\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]+)/gi;
const META_ELEMENT = /<meta\b[^>]*>/gi;
const CSP_META = `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data: blob:; font-src data: blob:; connect-src 'none'; media-src 'none'; object-src 'none'; frame-src 'none'; worker-src 'none'; base-uri 'none'; form-action 'none'">`;

interface PortfolioLot {
  label: string;
  ticker: "AAPL" | "AMZN" | "NVDA" | "SNAP" | "GOOGL" | "MSFT" | "DIS";
  purchased: string;
  shares: number;
  purchasePrice: number;
}

const PORTFOLIO_LOTS: readonly PortfolioLot[] = [
  { label: "APPLE-1", ticker: "AAPL", purchased: "5/29/24", shares: 146, purchasePrice: 191 },
  { label: "APPLE-2", ticker: "AAPL", purchased: "4/28/26", shares: 57, purchasePrice: 266 },
  { label: "AMAZON-1", ticker: "AMZN", purchased: "5/29/24", shares: 138, purchasePrice: 181 },
  { label: "AMAZON-2", ticker: "AMZN", purchased: "4/29/26", shares: 65, purchasePrice: 268 },
  { label: "NVIDIA", ticker: "NVDA", purchased: "5/29/24", shares: 204, purchasePrice: 123 },
  { label: "SNAP", ticker: "SNAP", purchased: "2/3/26", shares: 1786, purchasePrice: 6.18 },
  { label: "ALPHABET-1", ticker: "GOOGL", purchased: "4/21/26", shares: 101, purchasePrice: 336 },
  { label: "ALPHABET-2", ticker: "GOOGL", purchased: "4/28/26", shares: 106, purchasePrice: 349 },
  { label: "DISNEY", ticker: "DIS", purchased: "8/05/66", shares: 268, purchasePrice: 25 },
  { label: "MICROSOFT", ticker: "MSFT", purchased: "4/21/26", shares: 83, purchasePrice: 419 },
];

const PLAYER_STYLE = `<style id="hermes-brief-player-style">
html, body { width: 100% !important; max-width: none !important; overflow-x: hidden !important; }
.wrap { width: 100% !important; max-width: none !important; margin: 0 !important; }
.hermes-brief-player-sticky {
  position: fixed !important;
  inset: 0 0 auto 0 !important;
  width: 100% !important;
  max-width: none !important;
  box-sizing: border-box !important;
  z-index: 2147483647 !important;
  margin: 0 !important;
  border-radius: 0 0 14px 14px !important;
  background: var(--bg, #0f1117) !important;
  box-shadow: 0 10px 24px rgba(0, 0, 0, .42), 0 1px 0 rgba(255, 255, 255, .12) !important;
  padding-top: max(10px, env(safe-area-inset-top)) !important;
  isolation: isolate;
}
.hermes-brief-player-placeholder { display: block !important; width: 100% !important; }
.hermes-brief-player-sticky input[type="range"] { width: 137.5px !important; min-width: 137.5px !important; height: 28px !important; cursor: pointer !important; }
.hermes-brief-player-sticky button { min-width: 38px !important; min-height: 38px !important; }
.hermes-brief-player-sticky button.hermes-command-active,
.hermes-brief-player-sticky button:active {
  border-color: var(--accent, var(--link, #8ab4ff)) !important;
  color: var(--accent, var(--link, #8ab4ff)) !important;
  box-shadow: 0 0 0 2px var(--accent, var(--link, #8ab4ff)) !important;
}
.hermes-brief-player-status { color: var(--muted, #93a4bd); font-size: 12px; white-space: nowrap; }
#hermes-brief-player .hermes-player-shell { position: relative !important; display: flex; min-height: 50px; align-items: center; gap: 9px; padding: 8px 16px 10px; color: var(--text, #f4f7fb); }
#hermes-brief-player .hermes-player-volume { display: inline-flex; align-items: center; gap: 7px; color: var(--muted, #aab8ca); font-size: 12px; white-space: nowrap; }
#hermes-brief-player .hermes-date-nav { position: absolute !important; top: 50% !important; left: 50% !important; transform: translate(-50%, -50%) !important; display: inline-flex !important; align-items: center !important; gap: 18px !important; margin: 0 !important; vertical-align: middle !important; }
#hermes-brief-player .hermes-date-nav-label { display: inline-flex !important; min-height: 42px !important; align-items: center !important; color: #67e8f9 !important; font-size: 42px !important; line-height: 42px !important; font-weight: 400 !important; letter-spacing: .04em !important; white-space: nowrap !important; }
#hermes-brief-player .hermes-date-nav button { width: 42px !important; height: 42px !important; min-width: 42px !important; min-height: 42px !important; margin: 0 !important; border: 1px solid #67e8f9 !important; border-radius: 999px !important; background: rgba(103, 232, 249, .08) !important; color: #67e8f9 !important; font-size: 26px !important; line-height: 1 !important; }
#hermes-brief-player + .hero, #hermes-brief-player ~ .hero { scroll-margin-top: var(--hermes-player-height, 10rem); }
header .tts, header .player { display: none !important; }
.card, .hermes-playable-card { width: 100% !important; max-width: none !important; scroll-margin-top: var(--hermes-player-height, 10rem) !important; }
.card[role="button"], .hermes-playable-card[role="button"] { cursor: pointer !important; }
.card[role="button"]:hover, .hermes-playable-card[role="button"]:hover { border-color: var(--accent, var(--link, #8ab4ff)) !important; }
.card[role="button"]:focus-visible, .hermes-playable-card[role="button"]:focus-visible { outline: 2px solid var(--accent, var(--link, #8ab4ff)) !important; outline-offset: 2px; }
.hermes-playable-card.active,
.hermes-playable-card[aria-current="true"] {
  border-color: #67e8f9 !important;
  box-shadow: 0 0 0 3px rgba(103, 232, 249, .32) !important;
}
/* AI topic headlines use the concise July 14 visual hierarchy. */
.hermes-playable-card h2, .hermes-playable-card h3 { color: var(--hot, #ffd166) !important; }
.hermes-playable-card.takeaways h2 { color: #67e8f9 !important; text-transform: uppercase !important; letter-spacing: .035em !important; }
.hermes-playable-card.takeaways ol { margin: 1.25rem 0 0 !important; padding-left: 2.15rem !important; }
.hermes-playable-card.takeaways li { font-size: 1.2em !important; line-height: 1.58 !important; margin: 0 0 1.15rem !important; }
.hermes-playable-card.takeaways li > strong:first-child { display: block !important; color: #67e8f9 !important; font-size: 1.35em !important; line-height: 1.25 !important; margin: 0 0 .32rem !important; }
.hermes-playable-card.takeaways li::marker { color: #67e8f9 !important; font-size: 1.35em !important; font-weight: 850 !important; }
/* Cron dates are metadata, not a secondary hierarchy. Keep them consistently cyan. */
header .date, header .sub { color: #67e8f9 !important; }
.hermes-portfolio-comparison { margin: 18px 0 22px; padding: 18px; border: 1px solid rgba(138, 180, 255, .45); border-radius: 14px; background: rgba(10, 24, 42, .72); color: var(--text, #f4f7fb); }
.hermes-portfolio-comparison h2 { color: #ffd166 !important; margin: 0 0 4px; font-size: clamp(28px, 3.08vw, 39px); }
.hermes-portfolio-comparison .hermes-portfolio-note { margin: 0 0 14px; color: var(--muted, #aab8ca); font-size: 18px; }
.hermes-portfolio-table-wrap { width: 100%; overflow-x: auto; }
.hermes-portfolio-table { width: 100%; min-width: 1360px; table-layout: fixed; border-collapse: collapse; font-variant-numeric: tabular-nums; }
.hermes-portfolio-table th, .hermes-portfolio-table td { padding: 8px 9px; border-bottom: 1px solid rgba(255, 255, 255, .12); text-align: right; white-space: nowrap; }
.hermes-portfolio-table th { font-size: 14.7px; }
.hermes-portfolio-table td { font-size: 18.2px; }
.hermes-portfolio-table th:first-child, .hermes-portfolio-table td:first-child { width: 20%; min-width: 230px; }
/* Stock quote cards are intentionally transformed into concise full-width rows. */
[aria-label="Stock price cards"] { display: flex !important; flex-direction: column !important; gap: 10px !important; }
[aria-label="Stock price cards"] .card { display: grid !important; grid-template-columns: minmax(210px, 1.45fr) repeat(5, minmax(92px, 1fr)) !important; grid-template-rows: auto auto; gap: 4px 14px !important; align-items: center !important; margin: 0 !important; padding: 16px 18px !important; }
[aria-label="Stock price cards"] .card h2 { grid-column: 1; grid-row: 1 / span 2; margin: 0 !important; }
.hermes-card-daily-change { display: inline-block; margin-left: 10px; font-size: .9em; font-weight: 760; }
[aria-label="Stock price cards"] .card > .change,
[aria-label="Stock price cards"] .card > p.positive,
[aria-label="Stock price cards"] .card > p.negative { display: none !important; }
[aria-label="Stock price cards"] .card .stats { display: contents !important; }
[aria-label="Stock price cards"] .card .stats > * { min-width: 0; margin: 0 !important; padding: 0 !important; border: 0 !important; background: transparent !important; }
[aria-label="Stock price cards"] .card .stats > *:nth-child(n+6) { display: none !important; }
[aria-label="Stock price cards"] .card .stats > *:nth-child(1) { grid-column: 2; grid-row: 1 / span 2; }
[aria-label="Stock price cards"] .card .stats > *:nth-child(2) { grid-column: 3; grid-row: 1 / span 2; }
[aria-label="Stock price cards"] .card .stats > *:nth-child(3) { grid-column: 4; grid-row: 1 / span 2; }
[aria-label="Stock price cards"] .card .stats > *:nth-child(4) { grid-column: 5; grid-row: 1 / span 2; }
[aria-label="Stock price cards"] .card .stats > *:nth-child(5) { grid-column: 6; grid-row: 1 / span 2; }
[aria-label="Stock price cards"] .card .stats .label { display: block; margin-bottom: 2px; font-size: 10px; letter-spacing: .07em; text-transform: uppercase; }
[aria-label="Stock price cards"] .card .stats strong { font-size: 1rem; }
@media (max-width: 840px) { [aria-label="Stock price cards"] .card { grid-template-columns: minmax(190px, 1fr) repeat(3, minmax(88px, 1fr)) !important; } [aria-label="Stock price cards"] .card .stats > *:nth-child(1) { grid-column: 2; grid-row: 1; } [aria-label="Stock price cards"] .card .stats > *:nth-child(2) { grid-column: 3; grid-row: 1; } [aria-label="Stock price cards"] .card .stats > *:nth-child(3) { grid-column: 4; grid-row: 1; } [aria-label="Stock price cards"] .card .stats > *:nth-child(4) { grid-column: 2; grid-row: 2; } [aria-label="Stock price cards"] .card .stats > *:nth-child(5) { grid-column: 3; grid-row: 2; } }
@media (max-width: 620px) { [aria-label="Stock price cards"] .card { grid-template-columns: 1fr 1fr !important; } [aria-label="Stock price cards"] .card h2 { grid-column: 1 / -1; grid-row: auto; } [aria-label="Stock price cards"] .card .stats > * { grid-column: auto !important; grid-row: auto !important; } }
.hermes-portfolio-table th:first-child, .hermes-portfolio-table td:first-child { text-align: left; }
.hermes-portfolio-table thead th { color: var(--muted, #aab8ca); font-size: 11px; letter-spacing: .08em; text-transform: uppercase; }
.hermes-portfolio-table tbody tr:hover { background: rgba(138, 180, 255, .07); }
.hermes-portfolio-position { display: block; font-weight: 750; }
.hermes-portfolio-meta { display: block; margin-top: 3px; color: var(--muted, #aab8ca); font-size: 12.2px; font-weight: 500; }
.hermes-portfolio-shares { color: #ffd766; font-weight: 800; }
.hermes-portfolio-table thead .hermes-portfolio-shares { color: #ffd766; }
.hermes-portfolio-purchase { color: #ffd766; font-weight: 800; }
.hermes-portfolio-table thead .hermes-portfolio-purchase { color: #ffd766; }
.hermes-portfolio-positive { color: #4ade80; font-weight: 750; }
.hermes-portfolio-negative { color: #fb7185; font-weight: 750; }
.hermes-card-inline-price { display: block; margin-top: .2rem; font-size: 1.35rem; font-weight: 850; white-space: nowrap; }
/* Preserve each archived brief's original card/grid layout.  Only the price moves beneath the ticker. */
.card h2 { display: block !important; }
.hermes-portfolio-unavailable { color: var(--muted, #aab8ca); }
.hermes-portfolio-table tfoot td { border-top: 2px solid rgba(138, 180, 255, .55); border-bottom: 0; font-weight: 800; }
@media (max-width: 700px) {
  .wrap { padding: 10px 8px 28px !important; }
  .hermes-brief-player-sticky { padding: 10px !important; }
  .hermes-brief-player-sticky .tts,
  .hermes-brief-player-sticky .player { justify-content: flex-start !important; gap: 8px !important; }
  .hermes-brief-player-sticky input[type="range"] { width: min(137.5px, 38vw) !important; min-width: min(137.5px, 38vw) !important; }
  .hermes-portfolio-comparison { margin: 10px 0 16px; padding: 12px; }
}
/* V21: archive-independent full-width Stock rows. */
.hermes-stock-row { grid-column: 1 / -1 !important; width: 100% !important; max-width: none !important; display: grid !important; grid-template-columns: minmax(280px, 1.45fr) repeat(5, minmax(118px, 1fr)) !important; grid-template-rows: auto auto !important; gap: 6px 22px !important; align-items: center !important; margin: 0 !important; padding: 15px 20px !important; }
.hermes-stock-row h2 { grid-column: 1 !important; grid-row: 1 / span 2 !important; margin: 0 !important; }
.hermes-stock-row .hermes-card-company { display: inline !important; margin-left: 9px !important; color: var(--muted, #aab8ca) !important; font-size: .68em !important; font-weight: 550 !important; }
.hermes-stock-row .hermes-card-daily-change { display: inline !important; margin-left: 10px !important; font-size: .78em !important; }
.hermes-stock-row .hermes-card-inline-price { display: block !important; margin-top: 5px !important; font-size: 1.42rem !important; }
.hermes-stock-row > .change, .hermes-stock-row > p.positive, .hermes-stock-row > p.negative, .hermes-stock-row > .company { display: none !important; }
.hermes-stock-row .stats { display: contents !important; }
.hermes-stock-row .stats > * { min-width: 0 !important; margin: 0 !important; padding: 0 !important; border: 0 !important; background: transparent !important; }
.hermes-stock-row .stats > *:nth-child(n+6) { display: none !important; }
.hermes-stock-row .stats > *:nth-child(1) { grid-column: 2 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-row .stats > *:nth-child(2) { grid-column: 3 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-row .stats > *:nth-child(3) { grid-column: 4 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-row .stats > *:nth-child(4) { grid-column: 5 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-row .stats > *:nth-child(5) { grid-column: 6 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-row .stats .label { display: block !important; margin-bottom: 3px !important; font-size: 11px !important; letter-spacing: .08em !important; text-transform: uppercase !important; }
.hermes-stock-row .stats strong { font-size: 1.08rem !important; }
@media (max-width: 940px) { .hermes-stock-row { grid-template-columns: minmax(230px, 1fr) repeat(3, minmax(100px, 1fr)) !important; } .hermes-stock-row .stats > *:nth-child(1) { grid-column: 2 !important; grid-row: 1 !important; } .hermes-stock-row .stats > *:nth-child(2) { grid-column: 3 !important; grid-row: 1 !important; } .hermes-stock-row .stats > *:nth-child(3) { grid-column: 4 !important; grid-row: 1 !important; } .hermes-stock-row .stats > *:nth-child(4) { grid-column: 2 !important; grid-row: 2 !important; } .hermes-stock-row .stats > *:nth-child(5) { grid-column: 3 !important; grid-row: 2 !important; } }
@media (max-width: 680px) { .hermes-stock-row { grid-template-columns: 1fr 1fr !important; } .hermes-stock-row h2 { grid-column: 1 / -1 !important; grid-row: auto !important; } .hermes-stock-row .stats > * { grid-column: auto !important; grid-row: auto !important; } }
/* Stock archives are rewritten to a stable, canonical row markup rather than restyled opportunistically. */
main.grid { display: flex !important; flex-direction: column !important; gap: 12px !important; }
.hermes-stock-row { grid-column: 1 / -1 !important; width: 100% !important; max-width: none !important; box-sizing: border-box !important; display: grid !important; grid-template-columns: minmax(280px, 1.65fr) repeat(5, minmax(104px, 1fr)) !important; grid-template-rows: auto auto !important; gap: 6px 12px !important; align-items: center !important; margin: 0 !important; padding: 16px 22px !important; border: 1px solid var(--line, #334155) !important; border-radius: 16px !important; background: var(--panel, #111827) !important; box-shadow: none !important; }
.hermes-stock-identity { display: contents !important; }
.hermes-stock-title { grid-column: 1 !important; grid-row: 1 !important; display: flex !important; align-items: baseline !important; flex-wrap: wrap !important; gap: 0 10px !important; min-width: 0 !important; }
.hermes-stock-ticker { color: var(--text, #f4f7fb) !important; font-size: 1.55rem !important; font-weight: 850 !important; letter-spacing: .02em !important; }
.hermes-stock-company { color: var(--text, #f4f7fb) !important; font-size: 1.1rem !important; font-weight: 700 !important; }
.hermes-stock-change { font-size: 1.1rem !important; font-weight: 800 !important; white-space: nowrap !important; }
.hermes-stock-price { grid-column: 1 !important; grid-row: 2 !important; color: #ffe08a !important; font-size: 1.84rem !important; line-height: 1 !important; font-variant-numeric: tabular-nums !important; }
.hermes-stock-metrics { display: contents !important; margin: 0 !important; }
.hermes-stock-metrics > div { min-width: 0 !important; }
.hermes-stock-metrics > div:nth-child(1) { grid-column: 2 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-metrics > div:nth-child(2) { grid-column: 3 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-metrics > div:nth-child(3) { grid-column: 4 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-metrics > div:nth-child(4) { grid-column: 5 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-metrics > div:nth-child(5) { grid-column: 6 !important; grid-row: 1 / span 2 !important; }
.hermes-stock-metrics dt { color: var(--muted, #aab8ca) !important; font-size: .9625rem !important; font-weight: 650 !important; letter-spacing: .04em !important; line-height: 1.2 !important; text-transform: uppercase !important; }
.hermes-stock-metrics dd { margin: 4px 0 0 !important; color: var(--text, #f4f7fb) !important; font-size: 1.4375rem !important; font-weight: 800 !important; font-variant-numeric: tabular-nums !important; }
@media (max-width: 1040px) { .hermes-stock-row { grid-template-columns: minmax(240px, 1fr) repeat(3, minmax(104px, 1fr)) !important; } .hermes-stock-metrics > div:nth-child(1) { grid-column: 2 !important; grid-row: 1 !important; } .hermes-stock-metrics > div:nth-child(2) { grid-column: 3 !important; grid-row: 1 !important; } .hermes-stock-metrics > div:nth-child(3) { grid-column: 4 !important; grid-row: 1 !important; } .hermes-stock-metrics > div:nth-child(4) { grid-column: 2 !important; grid-row: 2 !important; } .hermes-stock-metrics > div:nth-child(5) { grid-column: 3 !important; grid-row: 2 !important; } }
@media (max-width: 680px) { .hermes-stock-row { grid-template-columns: 1fr 1fr !important; gap: 12px !important; } .hermes-stock-title, .hermes-stock-price { grid-column: 1 / -1 !important; } .hermes-stock-price { grid-row: 2 !important; } .hermes-stock-metrics > div { grid-column: auto !important; grid-row: auto !important; } }
</style>`;

const AI_RESTORED_STYLE = `<style id="hermes-ai-restored-style">
:root { --bg: #0b1020; --card: #121a33; --text: #eef3ff; --muted: #aab6d3; --accent: #8bd3ff; --line: #263456; --hot: #ffd166; }
html, body { width: 100% !important; max-width: none !important; min-height: 100% !important; margin: 0 !important; background: #0b1020 !important; color: #eef3ff !important; }
body { box-sizing: border-box !important; padding: 40px 22px 64px !important; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important; font-size: 32px !important; line-height: 1.6 !important; }
.wrap, body > main { width: 100% !important; max-width: none !important; margin: 0 !important; padding: 0 !important; }
body > header, body > main > header, .wrap > header, .hero { box-sizing: border-box !important; width: 100% !important; max-width: none !important; margin: 0 0 22px !important; padding: 28px !important; border: 1px solid #263456 !important; border-radius: 22px !important; background: linear-gradient(135deg, #182345, #10182f) !important; color: #eef3ff !important; box-shadow: 0 20px 60px rgba(0,0,0,.25) !important; }
body > header::before, body > main > header::before, .wrap > header::before, .hero::before { content: none !important; display: none !important; }
html body .hero .tag, html body header .tag, html body .tag { display: none !important; visibility: hidden !important; }
html body .hero .pill, html body header .pill { display: inline-block !important; visibility: visible !important; margin: 0 0 18px !important; padding: 10px 22px !important; border-radius: 999px !important; background: #ffd166 !important; color: #0b1020 !important; font-size: 22px !important; font-weight: 800 !important; line-height: 1.2 !important; letter-spacing: .02em !important; }
.hermes-date-nav { position: relative !important; top: 10px !important; display: inline-flex !important; align-items: center !important; gap: 18px !important; margin: 0 0 18px 22px !important; vertical-align: middle !important; }
.hermes-date-nav button { display: inline-grid !important; width: 46px !important; height: 46px !important; place-items: center !important; padding: 0 !important; border: 1px solid #67e8f9 !important; border-radius: 999px !important; background: rgba(103,232,249,.10) !important; color: #67e8f9 !important; font-size: 32px !important; font-weight: 800 !important; line-height: 1 !important; cursor: pointer !important; }
.hermes-date-nav button:hover, .hermes-date-nav button:focus-visible { background: #67e8f9 !important; color: #0b1020 !important; outline: none !important; }
body > header h1, body > main > header h1, .wrap > header h1, .hero h1 { margin: 0 0 10px !important; color: #eef3ff !important; font-size: 64px !important; line-height: 1.05 !important; letter-spacing: .015em !important; }
body > header p, body > main > header p, .wrap > header p, html body .hero p, body > header .date, body > main > header .date, .wrap > header .date, html body .hero .date, body > header strong, body > main > header strong, .wrap > header strong, html body .hero strong { margin: 0 !important; color: #eef3ff !important; font-size: 27px !important; line-height: 1.35 !important; }
.takeaways, body > main > .takeaways, .hermes-playable-card.takeaways { box-sizing: border-box !important; width: 100% !important; max-width: none !important; margin: 12px 0 !important; padding: 22px 26px !important; border: 1px solid #263456 !important; border-radius: 18px !important; background: #121a33 !important; color: #eef3ff !important; box-shadow: none !important; }
.takeaways h2, .hermes-playable-card.takeaways h2 { margin: 0 0 14px !important; padding: 0 !important; border: 0 !important; color: #ffd166 !important; font-size: 38px !important; font-weight: 700 !important; line-height: 1.15 !important; letter-spacing: .015em !important; text-transform: uppercase !important; }
.takeaways ol, .hermes-playable-card.takeaways ol { margin: 0 !important; padding-left: 1.5em !important; }
.takeaways li, .hermes-playable-card.takeaways li { margin: 0 0 10px !important; color: #eef3ff !important; font-size: 27px !important; font-weight: 400 !important; line-height: 1.34 !important; }
.takeaways li:last-child, .hermes-playable-card.takeaways li:last-child { margin-bottom: 0 !important; }
.takeaways li > strong:first-child, .hermes-playable-card.takeaways li > strong:first-child { display: block !important; margin: 0 0 2px !important; color: #8bd3ff !important; font-size: 34px !important; font-weight: 700 !important; line-height: 1.16 !important; letter-spacing: -.02em !important; }
.takeaways li::marker, .hermes-playable-card.takeaways li::marker { color: #8bd3ff !important; font-size: 30px !important; font-weight: 700 !important; }
.topics { display: grid !important; gap: 22px !important; }
.topics > .card, .hermes-playable-card:not(.takeaways), body > main > article, body > main > section.hermes-generated-topic { box-sizing: border-box !important; width: 100% !important; max-width: none !important; margin: 0 0 22px !important; padding: 24px !important; border: 1px solid #263456 !important; border-radius: 18px !important; background: rgba(18,26,51,.55) !important; color: #eef3ff !important; font-size: 32px !important; line-height: 1.6 !important; box-shadow: none !important; }
.topics > .card h2, .hermes-playable-card:not(.takeaways) h2, .hermes-playable-card:not(.takeaways) h3 { margin: 0 0 28px !important; padding: 0 !important; border: 0 !important; color: #ffd166 !important; font-size: 44px !important; line-height: 1.25 !important; }
.topics > .card p, .hermes-playable-card:not(.takeaways) p, .topics > .card li, .hermes-playable-card:not(.takeaways) li, .topics > .card a, .hermes-playable-card:not(.takeaways) a { font-size: 32px !important; line-height: 1.6 !important; }
.topics > .card a, .hermes-playable-card:not(.takeaways) a { color: #8bd3ff !important; text-decoration-thickness: .08em !important; text-underline-offset: .18em !important; }
.sources { margin-top: 28px !important; color: #aab6d3 !important; }
#hermes-brief-player { font-size: 16px !important; }
@media (max-width: 900px) {
  body { padding: 20px 12px 36px !important; font-size: 26px !important; }
  body > header, body > main > header, .wrap > header, .hero { padding: 34px !important; }
  .takeaways, body > main > .takeaways, .hermes-playable-card.takeaways { padding: 24px !important; }
  .topics > .card, .hermes-playable-card:not(.takeaways), body > main > article, body > main > section.hermes-generated-topic { padding: 30px !important; }
  body > header h1, body > main > header h1, .wrap > header h1, .hero h1 { font-size: 48px !important; }
  .takeaways h2, .hermes-playable-card.takeaways h2 { font-size: 32px !important; }
  .takeaways li > strong:first-child, .hermes-playable-card.takeaways li > strong:first-child { font-size: 30px !important; }
  .takeaways li, .hermes-playable-card.takeaways li { font-size: 24px !important; }
  .topics > .card h2, .hermes-playable-card:not(.takeaways) h2, .hermes-playable-card:not(.takeaways) h3 { font-size: 36px !important; }
  .topics > .card, .hermes-playable-card:not(.takeaways), .topics > .card p, .hermes-playable-card:not(.takeaways) p, .topics > .card li, .hermes-playable-card:not(.takeaways) li, .topics > .card a, .hermes-playable-card:not(.takeaways) a { font-size: 26px !important; }
}
</style>`;

const STOCK_HERO_STYLE = `<style id="hermes-stock-hero-style">
body > header, body > main > header, .wrap > header, .hero { box-sizing: border-box !important; width: 100% !important; max-width: none !important; margin: 0 0 22px !important; padding: 28px !important; border: 1px solid #263456 !important; border-radius: 22px !important; background: linear-gradient(135deg, #182345, #10182f) !important; color: #eef3ff !important; box-shadow: 0 20px 60px rgba(0,0,0,.25) !important; }
html body .hero .pill, html body header .pill { display: inline-block !important; margin: 0 0 18px !important; padding: 10px 22px !important; border-radius: 999px !important; background: #ffd166 !important; color: #0b1020 !important; font-size: 22px !important; font-weight: 800 !important; line-height: 1.2 !important; letter-spacing: .02em !important; }
.hermes-date-nav { position: relative !important; top: 10px !important; display: inline-flex !important; align-items: center !important; gap: 18px !important; margin: 0 0 18px 22px !important; vertical-align: middle !important; }
.hermes-date-nav button { display: inline-grid !important; width: 46px !important; height: 46px !important; place-items: center !important; padding: 0 !important; border: 1px solid #67e8f9 !important; border-radius: 999px !important; background: rgba(103,232,249,.10) !important; color: #67e8f9 !important; font-size: 32px !important; font-weight: 800 !important; line-height: 1 !important; cursor: pointer !important; }
.hermes-date-nav button:hover, .hermes-date-nav button:focus-visible { background: #67e8f9 !important; color: #0b1020 !important; outline: none !important; }
body > header h1, body > main > header h1, .wrap > header h1, .hero h1 { margin: 0 0 10px !important; color: #eef3ff !important; font-size: 64px !important; line-height: 1.05 !important; letter-spacing: .015em !important; }
body > header .date, body > main > header .date, .wrap > header .date, .hero .date { margin: 0 !important; color: #eef3ff !important; font-size: 27px !important; line-height: 1.35 !important; }
@media (max-width: 900px) { body > header h1, body > main > header h1, .wrap > header h1, .hero h1 { font-size: 48px !important; } }
</style>`;

const STOCK_DATE_NAV_CONTROLLER = `<script id="hermes-stock-date-nav-controller">
(() => {
  const MESSAGE_TYPE = "${BRIEF_DATE_NAV_MESSAGE_TYPE}";
  function init() {
    const header = document.querySelector(".hero, body > header, body > main > header, .wrap > header, header");
    const pill = header?.querySelector(".pill");
    if (!header || !pill || header.querySelector(".hermes-date-nav")) return;
    const navigator = document.createElement("span");
    navigator.className = "hermes-date-nav";
    navigator.setAttribute("role", "group");
    navigator.setAttribute("aria-label", "Cron date navigation");
    navigator.innerHTML = '<button type="button" aria-label="Load newer cron date" title="Newer cron date">‹</button><button type="button" aria-label="Load older cron date" title="Older cron date">›</button>';
    pill.insertAdjacentElement("afterend", navigator);
    const buttons = navigator.querySelectorAll("button");
    buttons[0]?.addEventListener("click", () => window.parent?.postMessage({ type: MESSAGE_TYPE, direction: "newer" }, "*"));
    buttons[1]?.addEventListener("click", () => window.parent?.postMessage({ type: MESSAGE_TYPE, direction: "older" }, "*"));
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true });
  else init();
})();
</script>`;

const PLAYER_CONTROLLER = `<script id="hermes-brief-player-controller">
(() => {
  const MESSAGE_TYPE = "${BRIEF_PLAYER_MESSAGE_TYPE}";
  const DATE_NAV_MESSAGE_TYPE = "${BRIEF_DATE_NAV_MESSAGE_TYPE}";

  const PLAYER_CLASS = "hermes-brief-player-sticky";
  const PLACEHOLDER_CLASS = "hermes-brief-player-placeholder";
  const synth = window.speechSynthesis;
  const preferredVoiceNames = [
    "Samantha", "Ava", "Allison", "Susan", "Victoria", "Karen", "Moira",
    "Tessa", "Serena", "Kate", "Fiona", "Veena", "Zira", "Jenny", "Aria",
    "Google US English"
  ];
  const blockedVoiceNames = [
    "Bad News", "Bahh", "Bells", "Boing", "Bubbles", "Cellos", "Deranged",
    "Good News", "Hysterical", "Pipe Organ", "Trinoids", "Whisper", "Zarvox"
  ];

  let cards = [];
  let index = 0;
  let navigationStarted = false;
  let playing = false;
  let paused = false;
  let currentUtterance = null;
  let volumeDirty = false;
  let volumeRestartTimer = null;
  let root = null;
  let previousButton = null;
  let playButton = null;
  let nextButton = null;
  let volumeInput = null;
  let statusElement = null;
  let placeholder = null;
  let founderTakeaways = null;

  function ensureHermesPlayer() {
    let player = document.getElementById("hermes-brief-player");
    if (player) return player;
    player = document.createElement("nav");
    player.id = "hermes-brief-player";
    player.setAttribute("aria-label", "Brief playback controls");
    player.innerHTML = '<div class="hermes-player-shell"><button id="tts-prev" type="button" aria-label="Previous topic" title="Previous topic">←</button><button id="tts-toggle" type="button" aria-label="Play reading" aria-pressed="false" title="Play or pause">▶</button><button id="tts-next" type="button" aria-label="Next topic" title="Next topic">→</button><label class="hermes-player-volume"><input id="tts-volume" type="range" min="0" max="1" step="0.05" value="1" aria-label="Volume" title="Volume"></label></div>';
    document.body.insertBefore(player, document.body.firstChild);
    return player;
  }

  function normalizeAiVisualStructure() {
    document.querySelectorAll(".tag").forEach((label) => label.remove());
    const header = document.querySelector(".hero, body > header, body > main > header, .wrap > header, header");
    if (!header) return;
    const dateParagraph = header.querySelector(".date");
    const dateLine = dateParagraph?.textContent?.trim();
    const pill = header.querySelector(".pill");
    const alreadyNormalized = header.dataset.hermesDateNormalized === "true";
    if (dateLine && !alreadyNormalized) {
      const [pillDate, ...metadataParts] = dateLine.split("·").map((part) => part.trim());
      if (pillDate && pill) pill.textContent = pillDate;
      const archiveMetadata = metadataParts.filter(Boolean).join(" · ");
      const metadataLine = archiveMetadata;
      if (dateParagraph && metadataLine) dateParagraph.textContent = metadataLine;
      else dateParagraph?.remove();
    }
    header.querySelectorAll(".meta").forEach((metadata) => metadata.remove());
    const heading = header.querySelector("h1");
    if (heading) heading.textContent = heading.textContent.replace(/\\s*(?:—|-)\\s*\\d{4}-\\d{2}-\\d{2}\\s*$/, "");
  }

  function ensureDateNavigator() {
    const shell = document.querySelector("#hermes-brief-player .hermes-player-shell");
    if (!shell) return;
    const header = document.querySelector(".hero, body > header, body > main > header, .wrap > header, header");
    let navigator = document.querySelector(".hermes-date-nav");
    if (!navigator) navigator = document.createElement("span");
    navigator.className = "hermes-date-nav";
    navigator.setAttribute("role", "group");
    navigator.setAttribute("aria-label", "Cron date navigation");
    navigator.innerHTML = '<button id="hermes-date-newer" type="button" aria-label="Load newer cron date" title="Newer cron date">‹</button><span class="hermes-date-nav-label">DATE</span><button id="hermes-date-older" type="button" aria-label="Load older cron date" title="Older cron date">›</button>';
    shell.appendChild(navigator);
    header?.querySelectorAll(".hermes-date-nav").forEach((element) => {
      if (element !== navigator) element.remove();
    });
    navigator.querySelector("#hermes-date-newer")?.addEventListener("click", () => {
      window.parent?.postMessage({ type: DATE_NAV_MESSAGE_TYPE, direction: "newer" }, "*");
    });
    navigator.querySelector("#hermes-date-older")?.addEventListener("click", () => {
      window.parent?.postMessage({ type: DATE_NAV_MESSAGE_TYPE, direction: "older" }, "*");
    });
  }

  function isNumberedTopicHeading(element) {
    return /^\s*\d+\s*[.)]\s+/.test(element.textContent || "");
  }

  function wrapSiblingTopic(heading) {
    const parent = heading.parentElement;
    if (!parent) return heading;
    const wrapper = document.createElement("section");
    wrapper.className = "hermes-playable-card hermes-generated-topic";
    parent.insertBefore(wrapper, heading);
    let node = heading;
    while (node) {
      const next = node.nextSibling;
      if (node !== heading && node instanceof Element && node.matches("h2, h3") && isNumberedTopicHeading(node)) break;
      wrapper.appendChild(node);
      node = next;
    }
    return wrapper;
  }

  function playableCards() {
    const numberedHeadings = Array.from(document.querySelectorAll("main h2, main h3, body > h2, body > h3"))
      .filter(isNumberedTopicHeading);
    if (numberedHeadings.length) {
      return numberedHeadings.map((heading) => {
        const container = heading.closest(".card, article, section");
        const numberedInside = container
          ? Array.from(container.querySelectorAll("h2, h3")).filter(isNumberedTopicHeading)
          : [];
        const card = container && numberedInside.length === 1 ? container : wrapSiblingTopic(heading);
        card.classList.add("hermes-playable-card");
        return card;
      }).filter((element, position, all) => all.indexOf(element) === position)
        .filter((element) => !element.matches(".agenda, [data-hermes-exclude-from-player]"));
    }
    const explicit = Array.from(document.querySelectorAll(".card, article.card"))
      .filter((element) => !element.matches(".takeaways, .agenda, [data-hermes-exclude-from-player]"));
    const fallback = explicit.length
      ? explicit
      : Array.from(document.querySelectorAll("main article, main section, article, section"))
        .filter((element) => element.querySelector("h2, h3"))
        .filter((element) => !element.closest("#hermes-brief-player"))
        .filter((element) => !element.matches(".takeaways, .agenda, [data-hermes-exclude-from-player]"));
    return fallback;
  }

  function controls() {
    root = ensureHermesPlayer();
    previousButton = document.getElementById("tts-prev");
    playButton = document.getElementById("tts-toggle");
    nextButton = document.getElementById("tts-next");
    volumeInput = document.getElementById("tts-volume");
    founderTakeaways = document.querySelector(".takeaways");
    cards = playableCards();
    return Boolean(root && previousButton && playButton && nextButton && volumeInput && cards.length);
  }

  function normalizedIndex(value) {
    if (!cards.length) return 0;
    return ((value % cards.length) + cards.length) % cards.length;
  }

  function textFor(card) {
    const clone = card.cloneNode(true);
    clone.querySelectorAll(".sources, .source, script, style").forEach((element) => element.remove());
    if (card.classList.contains("takeaways")) return clone.textContent.trim();
    const parts = Array.from(clone.querySelectorAll("h1, h2, h3, h4, p, li, blockquote, dt, dd"))
      .map((element) => element.textContent.trim())
      .filter(Boolean);
    if (parts.length) return parts.join(". ");
    return clone.textContent.trim();
  }

  function configureNaturalVoice(utterance) {
    const voices = synth ? synth.getVoices() : [];
    const usableVoices = voices.filter((voice) =>
      /^en([-_]|$)/i.test(voice.lang || "") &&
      !blockedVoiceNames.some((name) => voice.name.toLowerCase().includes(name.toLowerCase()))
    );
    const selectedVoice = preferredVoiceNames
      .map((name) => usableVoices.find((voice) => voice.name.toLowerCase().includes(name.toLowerCase())))
      .find(Boolean) || usableVoices.find((voice) => voice.localService) || usableVoices[0] || null;
    if (selectedVoice) utterance.voice = selectedVoice;
    utterance.lang = selectedVoice?.lang || "en-US";
    utterance.pitch = 1;
    utterance.rate = 1;
    return Boolean(selectedVoice);
  }

  function speakWhenNaturalVoiceReady(utterance, attempt = 0) {
    if (!synth || currentUtterance !== utterance) return;
    if (configureNaturalVoice(utterance)) {
      synth.speak(utterance);
      return;
    }
    if (attempt >= 50) {
      currentUtterance = null;
      playing = false;
      paused = false;
      updateControls();
      if (statusElement) statusElement.textContent = "Natural voice unavailable";
      return;
    }
    if (statusElement) statusElement.textContent = "Loading natural voice…";
    window.setTimeout(() => speakWhenNaturalVoiceReady(utterance, attempt + 1), 100);
  }

  function setStatus() {
    if (!statusElement) return;
    const state = paused ? " · paused" : playing ? " · playing" : "";
    statusElement.textContent = "Topic " + (index + 1) + " of " + cards.length + state;
  }

  function updateControls() {
    playButton.textContent = paused || !playing ? "▶" : "⏸";
    playButton.setAttribute("aria-label", paused || !playing ? "Play reading" : "Pause reading");
    playButton.setAttribute("aria-pressed", playing ? "true" : "false");
    setStatus();
  }

  function mark(options = {}) {
    if (founderTakeaways) {
      founderTakeaways.classList.remove("active");
      founderTakeaways.removeAttribute("aria-current");
    }
    cards.forEach((card, cardIndex) => {
      const active = cardIndex === index;
      card.classList.toggle("active", active);
      card.setAttribute("aria-current", active ? "true" : "false");
    });
    const card = cards[index];
    if (card && options.scroll !== false) {
      card.scrollIntoView({ behavior: options.behavior || "smooth", block: "start" });
    }
    setStatus();
  }

  function flash(button) {
    button.classList.add("hermes-command-active");
    window.setTimeout(() => button.classList.remove("hermes-command-active"), 220);
  }

  function stopSpeech(options = {}) {
    window.clearTimeout(volumeRestartTimer);
    synth?.cancel();
    currentUtterance = null;
    playing = false;
    paused = false;
    if (options.clearHighlight) {
      if (founderTakeaways) {
        founderTakeaways.classList.remove("active");
        founderTakeaways.removeAttribute("aria-current");
      }
      cards.forEach((card) => {
        card.classList.remove("active");
        card.removeAttribute("aria-current");
      });
    }
    updateControls();
  }

  function speakCurrent() {
    if (!synth || !cards.length) return;
    window.clearTimeout(volumeRestartTimer);
    synth.cancel();
    index = normalizedIndex(index);
    navigationStarted = true;
    const utterance = new SpeechSynthesisUtterance(textFor(cards[index]));
    utterance.volume = Math.max(0, Math.min(1, Number(volumeInput.value) || 0));
    utterance.onend = () => {
      if (currentUtterance !== utterance) return;
      currentUtterance = null;
      playing = false;
      paused = false;
      updateControls();
    };
    utterance.onerror = () => {
      if (currentUtterance !== utterance) return;
      currentUtterance = null;
      playing = false;
      paused = false;
      updateControls();
    };
    currentUtterance = utterance;
    playing = true;
    paused = false;
    volumeDirty = false;
    mark();
    updateControls();
    speakWhenNaturalVoiceReady(utterance);
  }

  function selectAndPlay(selectedIndex) {
    index = normalizedIndex(selectedIndex);
    speakCurrent();
  }

  function playFounderTakeaways() {
    if (!founderTakeaways || !synth) {
      selectAndPlay(0);
      return;
    }
    window.clearTimeout(volumeRestartTimer);
    synth.cancel();
    cards.forEach((card) => {
      card.classList.remove("active");
      card.removeAttribute("aria-current");
    });
    founderTakeaways.classList.add("hermes-playable-card", "active");
    founderTakeaways.setAttribute("aria-current", "true");
    founderTakeaways.scrollIntoView({ behavior: "smooth", block: "start" });
    const utterance = new SpeechSynthesisUtterance(textFor(founderTakeaways));
    utterance.volume = Math.max(0, Math.min(1, Number(volumeInput.value) || 0));
    utterance.onend = utterance.onerror = () => {
      if (currentUtterance !== utterance) return;
      currentUtterance = null;
      playing = false;
      paused = false;
      updateControls();
    };
    currentUtterance = utterance;
    playing = true;
    paused = false;
    volumeDirty = false;
    playButton.textContent = "⏸";
    playButton.setAttribute("aria-label", "Pause reading");
    playButton.setAttribute("aria-pressed", "true");
    if (statusElement) statusElement.textContent = "Founder takeaways · playing";
    speakWhenNaturalVoiceReady(utterance);
  }

  function togglePlayback() {
    if (!synth) return;
    if (playing) {
      synth.pause();
      playing = false;
      paused = true;
      updateControls();
      return;
    }
    if (paused && !volumeDirty) {
      synth.resume();
      playing = true;
      paused = false;
      updateControls();
      return;
    }
    speakCurrent();
  }

  function setVolume(value) {
    const normalized = Math.max(0, Math.min(1, Number(value)));
    volumeInput.value = String(Number.isFinite(normalized) ? normalized : 1);
    volumeDirty = true;
    if (!playing) return;
    window.clearTimeout(volumeRestartTimer);
    volumeRestartTimer = window.setTimeout(() => speakCurrent(), 120);
  }

  function runCommand(command) {
    if (command === "toggle") {
      togglePlayback();
      flash(playButton);
    } else if (command === "previous") {
      if (!navigationStarted) selectAndPlay(index);
      else selectAndPlay(index - 1);
      flash(previousButton);
    } else if (command === "next") {
      if (!navigationStarted) selectAndPlay(index);
      else selectAndPlay(index + 1);
      flash(nextButton);
    } else if (command === "first") {
      playFounderTakeaways();
      flash(previousButton);
    }
  }

  function commandForEvent(event) {
    if (event.code === "Space" || event.key === " " || event.key === "Spacebar") return "toggle";
    if (event.key === "ArrowLeft") return "previous";
    if (event.key === "ArrowRight") return "next";
    if (event.key === "ArrowUp") return "first";
    return null;
  }

  function interactiveTarget(target) {
    return target instanceof Element && Boolean(
      target.closest('input, textarea, select, button, a, [contenteditable="true"]')
    );
  }

  function textEditingTarget(target) {
    return target instanceof Element && Boolean(
      target.closest('input:not([type="range"]), textarea, select, [contenteditable="true"]')
    );
  }

  function isVolumeControl(target) {
    return target instanceof HTMLInputElement && target.id === "tts-volume" && target.type === "range";
  }

  function pinPlayer() {
    root.classList.add(PLAYER_CLASS);
    placeholder = root.previousElementSibling;
    if (!placeholder || !placeholder.classList.contains(PLACEHOLDER_CLASS)) {
      placeholder = document.createElement("div");
      placeholder.className = PLACEHOLDER_CLASS;
      root.parentElement?.insertBefore(placeholder, root);
    }
    const syncHeight = () => {
      const height = Math.ceil(root.getBoundingClientRect().height);
      placeholder.style.height = height + "px";
      document.documentElement.style.setProperty("--hermes-player-height", height + 20 + "px");
    };
    syncHeight();
    if ("ResizeObserver" in window) new ResizeObserver(syncHeight).observe(root);
  }

  function init() {
    normalizeAiVisualStructure();
    if (!controls()) return;
    ensureDateNavigator();
    synth.cancel();
    synth.getVoices();
    volumeInput.min = "0";
    volumeInput.max = "1";
    volumeInput.step = "0.05";
    volumeInput.setAttribute("aria-label", "Volume");
    volumeInput.setAttribute("title", "Volume");


    cards.forEach((card, cardIndex) => {
      card.classList.add("hermes-playable-card");
      card.setAttribute("role", "button");
      card.setAttribute("tabindex", "0");
      card.setAttribute("aria-label", "Play topic " + (cardIndex + 1));
      card.addEventListener("click", (event) => {
        if (interactiveTarget(event.target)) return;
        selectAndPlay(cardIndex);
      });
      card.addEventListener("keydown", (event) => {
        if (event.key !== "Enter" && event.key !== " ") return;
        event.preventDefault();
        event.stopPropagation();
        selectAndPlay(cardIndex);
      });
    });

    previousButton.onclick = (event) => { event.preventDefault(); runCommand("previous"); };
    playButton.onclick = (event) => { event.preventDefault(); runCommand("toggle"); };
    nextButton.onclick = (event) => { event.preventDefault(); runCommand("next"); };
    volumeInput.oninput = () => setVolume(volumeInput.value);
    // The slider is pointer-only: preserve player keys and suppress every native range key.
    volumeInput.tabIndex = -1;
    volumeInput.addEventListener("keydown", (event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
    });

    document.addEventListener("keydown", (event) => {
      const command = commandForEvent(event);
      if (!command) return;
      if (textEditingTarget(event.target) && !isVolumeControl(event.target)) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      runCommand(command);
    }, true);

    window.addEventListener("message", (event) => {
      if (event.source !== window.parent || event.data?.type !== MESSAGE_TYPE) return;
      runCommand(event.data.command);
    });
    window.addEventListener("beforeunload", () => stopSpeech({ clearHighlight: true }));

    pinPlayer();
    index = 0;
    mark({ behavior: "auto", scroll: false });
    updateControls();
    window.parent?.postMessage({ type: "hermes-brief-player-ready" }, "*");
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
</script>`;

function injectBeforeClosingTag(html: string, tag: "head" | "body", addition: string): string {
  const closingTag = new RegExp(`</${tag}\\s*>`, "i");
  if (closingTag.test(html)) return html.replace(closingTag, `${addition}</${tag}>`);
  return `${html}${addition}`;
}

function sanitizeArchivedHtmlWithRegex(html: string): string {
  return html
    .replace(SCRIPT_ELEMENT, "")
    .replace(EVENT_HANDLER_ATTRIBUTE, "")
    .replace(URL_ATTRIBUTE, (attribute) => {
      const separator = attribute.indexOf("=");
      const rawValue = attribute.slice(separator + 1).trim();
      const unquotedValue =
        (rawValue.startsWith('"') && rawValue.endsWith('"')) ||
        (rawValue.startsWith("'") && rawValue.endsWith("'"))
          ? rawValue.slice(1, -1)
          : rawValue;
      const normalizedValue = unquotedValue.replace(/[\u0000-\u0020\u007f]/g, "").toLowerCase();
      return normalizedValue.startsWith("javascript:") ? "" : attribute;
    })
    .replace(SRCDOC_ATTRIBUTE, "")
    .replace(META_ELEMENT, (meta) => {
      const unsafeHttpEquiv = /http-equiv\s*=\s*(?:["']?)(?:refresh|content-security-policy)(?:["']?)/i;
      return unsafeHttpEquiv.test(meta) ? "" : meta;
    });
}

function sanitizeArchivedHtml(html: string): string {
  if (typeof DOMParser === "undefined") return sanitizeArchivedHtmlWithRegex(html);

  const documentNode = new DOMParser().parseFromString(html, "text/html");
  documentNode.querySelectorAll("script").forEach((element) => element.remove());
  documentNode.querySelectorAll("meta[http-equiv]").forEach((element) => {
    const directive = element.getAttribute("http-equiv")?.trim().toLowerCase();
    if (directive === "refresh" || directive === "content-security-policy") element.remove();
  });
  documentNode.querySelectorAll("*").forEach((element) => {
    Array.from(element.attributes).forEach((attribute) => {
      const name = attribute.name.toLowerCase();
      const value = attribute.value.replace(/[\u0000-\u0020\u007f]/g, "").toLowerCase();
      if (
        name.startsWith("on") ||
        name === "srcdoc" ||
        (["href", "src", "action", "formaction", "xlink:href"].includes(name) && value.startsWith("javascript:"))
      ) {
        element.removeAttribute(attribute.name);
      }
    });
  });

  const doctype = /^\s*<!doctype[^>]*>/i.test(html) ? "<!doctype html>" : "";
  return `${doctype}${documentNode.documentElement.outerHTML}`;
}

function extractStockPrices(html: string): Map<PortfolioLot["ticker"], number> {
  const normalizeText = (fragment: string) =>
    fragment
      .replace(/<style\b[^>]*>[\s\S]*?<\/style\s*>/gi, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/&mdash;|&#8212;|&#x2014;/gi, "—")
      .replace(/&ndash;|&#8211;|&#x2013;/gi, "–")
      .replace(/&nbsp;|&#160;/gi, " ")
      .replace(/\s+/g, " ")
      .trim();

  const candidates: string[] = [];
  const boundedElement = /<(h[1-6]|tr)\b[^>]*>([\s\S]*?)<\/\1\s*>/gi;
  for (const match of html.matchAll(boundedElement)) candidates.push(normalizeText(match[2]));

  const cardElement = /<article\b([^>]*)>([\s\S]*?)<\/article\s*>/gi;
  for (const match of html.matchAll(cardElement)) {
    candidates.push(normalizeText(match[2]));
  }
  const cardSection = /<section\b([^>]*)>([\s\S]*?)<\/section\s*>/gi;
  for (const match of html.matchAll(cardSection)) {
    if (/\bcard\b/i.test(match[1]) && !/<article\b/i.test(match[2])) {
      candidates.push(normalizeText(match[2]));
    }
  }

  if (!candidates.length) {
    candidates.push(...html.split(/\r?\n/).map(normalizeText).filter(Boolean));
  }

  const prices = new Map<PortfolioLot["ticker"], number>();
  const tickerPattern = "AAPL|AMZN|NVDA|SNAP|GOOGL|MSFT|DIS";
  const unsafePriceContext = /\b(?:unavailable|not\s+available|missing)\b|(?:^|\s)n\/?a(?:\s|$)|market\s*cap|market\s+value|valuation|revenue|volume/i;

  for (const candidate of candidates) {
    const start = candidate.match(new RegExp(`^\\s*(${tickerPattern})\\b`, "i"));
    const parenthesized = candidate.match(new RegExp(`\\(\\s*(${tickerPattern})\\s*\\)`, "i"));
    const anywhere = candidate.match(new RegExp(`\\b(${tickerPattern})\\b`, "i"));
    const tickerMatch = start ?? parenthesized ?? anywhere;
    if (!tickerMatch || tickerMatch.index === undefined) continue;

    const ticker = tickerMatch[1].toUpperCase() as PortfolioLot["ticker"];
    const afterTicker = candidate.slice(tickerMatch.index + tickerMatch[0].length, tickerMatch.index + tickerMatch[0].length + 160);
    const priceMatch = afterTicker.match(/\$\s*([0-9][0-9,]*(?:\.\d+)?)/);
    if (!priceMatch || priceMatch.index === undefined) continue;
    const context = afterTicker.slice(0, priceMatch.index);
    if (unsafePriceContext.test(context)) continue;

    const price = Number(priceMatch[1].replace(/,/g, ""));
    if (Number.isFinite(price) && price >= 0 && !prices.has(ticker)) prices.set(ticker, price);
  }
  return prices;
}

const usd = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

function signedCurrency(value: number): string {
  return `${value >= 0 ? "+" : "-"}${usd.format(Math.abs(value))}`;
}

function signedPercent(value: number): string {
  return `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
}

function csvCell(value: string | number): string {
  const text = String(value);
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export function stockPortfolioCsv(html: string, briefDate: string): string {
  const prices = extractStockPrices(html);
  const headers = [
    "Brief Date",
    "Position",
    "Ticker",
    "Purchase Date",
    "Shares",
    "Purchased Price",
    "Current Price",
    "Price Difference",
    "Cost Basis",
    "Current Value",
    "Gain Loss",
    "Position Return Percent",
  ];
  const rows = PORTFOLIO_LOTS.map((lot) => {
    const currentPrice = prices.get(lot.ticker);
    const basis = lot.shares * lot.purchasePrice;
    if (currentPrice === undefined) {
      return {
        gain: Number.NEGATIVE_INFINITY,
        cells: [
          briefDate,
          lot.label,
          lot.ticker,
          lot.purchased,
          lot.shares,
          lot.purchasePrice.toFixed(2),
          "",
          "",
          basis.toFixed(2),
          "",
          "",
          "",
        ],
      };
    }

    const priceDifference = currentPrice - lot.purchasePrice;
    const currentValue = lot.shares * currentPrice;
    const gain = currentValue - basis;
    const returnPercent = (gain / basis) * 100;
    return {
      gain,
      cells: [
        briefDate,
        lot.label,
        lot.ticker,
        lot.purchased,
        lot.shares,
        lot.purchasePrice.toFixed(2),
        currentPrice.toFixed(2),
        priceDifference.toFixed(2),
        basis.toFixed(2),
        currentValue.toFixed(2),
        gain.toFixed(2),
        returnPercent.toFixed(2),
      ],
    };
  })
    .sort((left, right) => right.gain - left.gain)
    .map((row) => row.cells);

  return [headers, ...rows]
    .map((row) => row.map(csvCell).join(","))
    .join("\r\n") + "\r\n";
}

export function stockPortfolioCsvName(date: string): string {
  return `Stock Portfolio - ${date}.csv`;
}

export interface StockPortfolioCsvExport {
  date: string;
  content: string;
}

export function matchingStockPortfolioCsv(
  exportData: StockPortfolioCsvExport | null,
  selectedDate: string | undefined,
): StockPortfolioCsvExport | null {
  return exportData && exportData.date === selectedDate ? exportData : null;
}

function stockPortfolioComparison(html: string): string {
  const prices = extractStockPrices(html);
  if (!prices.size) return "";

  let totalBasis = 0;
  let totalValue = 0;
  const rows = PORTFOLIO_LOTS.map((lot) => {
    const currentPrice = prices.get(lot.ticker);
    const basis = lot.shares * lot.purchasePrice;
    if (currentPrice === undefined) {
      return { gain: Number.NEGATIVE_INFINITY, basis, value: 0, html: `<tr><td><span class="hermes-portfolio-position">${lot.label} · ${lot.ticker}</span><span class="hermes-portfolio-meta">${lot.purchased}</span></td><td class="hermes-portfolio-shares">${lot.shares.toLocaleString("en-US")}</td><td class="hermes-portfolio-purchase">${usd.format(lot.purchasePrice)}</td><td class="hermes-portfolio-unavailable" colspan="6">Current ${lot.ticker} price unavailable</td></tr>` };
    }

    const priceDifference = currentPrice - lot.purchasePrice;
    const currentValue = lot.shares * currentPrice;
    const gain = currentValue - basis;
    const returnPercent = (gain / basis) * 100;
    const resultClass = priceDifference >= 0 ? "hermes-portfolio-positive" : "hermes-portfolio-negative";
    totalBasis += basis;
    totalValue += currentValue;

    return { gain, basis, value: currentValue, html: `<tr><td><span class="hermes-portfolio-position">${lot.label} · ${lot.ticker}</span><span class="hermes-portfolio-meta">${lot.purchased}</span></td><td class="hermes-portfolio-shares">${lot.shares.toLocaleString("en-US")}</td><td class="hermes-portfolio-purchase">${usd.format(lot.purchasePrice)}</td><td>${usd.format(currentPrice)}</td><td class="${resultClass}">${signedCurrency(priceDifference)}</td><td>${usd.format(basis)}</td><td>${usd.format(currentValue)}</td><td class="${resultClass}">${signedCurrency(gain)}</td><td class="${resultClass}">${signedPercent(returnPercent)}</td></tr>` };
  })
    .sort((left, right) => right.gain - left.gain)
    .map((row) => row.html)
    .join("");

  const totalGain = totalValue - totalBasis;
  const totalReturn = totalBasis ? (totalGain / totalBasis) * 100 : 0;
  const totalClass = totalGain >= 0 ? "hermes-portfolio-positive" : "hermes-portfolio-negative";

  return `<section id="hermes-portfolio-comparison" class="hermes-portfolio-comparison" aria-labelledby="hermes-portfolio-title">
    <h2 id="hermes-portfolio-title">Portfolio Position Comparison</h2>
    <p class="hermes-portfolio-note">Daily prices compared with your purchase lots. Precise basis uses shares × purchased price.</p>
    <div class="hermes-portfolio-table-wrap">
      <table class="hermes-portfolio-table" aria-label="Portfolio positions compared with current stock brief prices">
        <thead><tr><th>Position</th><th class="hermes-portfolio-shares">Shares</th><th class="hermes-portfolio-purchase">Purchased price</th><th>Current price</th><th>+/-</th><th>Cost basis</th><th>Current value</th><th>Gain / loss</th><th>Return</th></tr></thead>
        <tbody>${rows}</tbody>
        <tfoot><tr><td colspan="5">Available-position total</td><td>${usd.format(totalBasis)}</td><td>${usd.format(totalValue)}</td><td class="${totalClass}">${signedCurrency(totalGain)}</td><td class="${totalClass}">${signedPercent(totalReturn)}</td></tr></tfoot>
      </table>
    </div>
  </section>`;
}

function normalizeStockQuoteRows(html: string): string {
  const text = (fragment: string) => fragment.replace(/<[^>]+>/g, " ").replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
  const escape = (value: string) => value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const cardPattern = /<(section|article)\b(?=[^>]*\bclass\s*=\s*(?:"[^"]*\bcard\b[^"]*"|'[^']*\bcard\b[^']*'))([^>]*)>([\s\S]*?)<\/\1\s*>/gi;

  return html.replace(cardPattern, (source, _tag: string, attributes: string, body: string) => {
    if (!/\bclass\s*=\s*(?:"[^"]*\bcard\b[^"]*"|'[^']*\bcard\b[^']*')/i.test(attributes)) return source;
    const tickerMatch = text(body.match(/<(?:div|span|h[1-6])\b[^>]*class\s*=\s*(?:"[^"]*\bticker\b[^"]*"|'[^']*\bticker\b[^']*')[^>]*>([\s\S]*?)<\/(?:div|span|h[1-6])\s*>/i)?.[1] ?? body.match(/<h[1-6]\b[^>]*>\s*(AAPL|AMZN|NVDA|SNAP|GOOGL|MSFT|DIS)\b/i)?.[1] ?? "").match(/(AAPL|AMZN|NVDA|SNAP|GOOGL|MSFT|DIS)/i);
    const ticker = tickerMatch?.[1]?.toUpperCase();
    const price = text(body.match(/<(?:div|span|strong)\b[^>]*class\s*=\s*(?:"[^"]*\bprice\b[^"]*"|'[^']*\bprice\b[^']*')[^>]*>([\s\S]*?)<\/(?:div|span|strong)\s*>/i)?.[1] ?? body.match(/<strong\b[^>]*>\s*(\$\s*[0-9][0-9,]*(?:\.\d+)?)\s*<\/strong\s*>/i)?.[1] ?? "");
    if (!ticker || !/^\$\s*[0-9]/.test(price)) return source;

    const company = text(body.match(/<(?:div|span|p)\b[^>]*class\s*=\s*(?:"[^"]*\bcompany\b[^"]*"|'[^']*\bcompany\b[^']*')[^>]*>([\s\S]*?)<\/(?:div|span|p)\s*>/i)?.[1] ?? "").replace(/\bCorporation\b/gi, "Co.");
    const dailyChange = text(body.match(/<(?:div|span|p)\b[^>]*class\s*=\s*(?:"[^"]*\bchange\b[^"]*"|'[^']*\bchange\b[^']*')[^>]*>([\s\S]*?)<\/(?:div|span|p)\s*>/i)?.[1] ?? "");
    const negative = /(?:\bdown\b|(?:^|\s)-\s*\$|▼)/i.test(dailyChange);
    const changeClass = dailyChange ? (negative ? "hermes-portfolio-negative" : "hermes-portfolio-positive") : "";
    const metrics = Array.from(body.matchAll(/<dt\b[^>]*>([\s\S]*?)<\/dt\s*>\s*<dd\b[^>]*>([\s\S]*?)<\/dd\s*>/gi))
      .slice(0, 5)
      .map((entry) => `<div><dt>${escape(text(entry[1]))}</dt><dd>${escape(text(entry[2]))}</dd></div>`)
      .join("");

    const priceClass = changeClass ? ` ${changeClass}` : "";
    return `<section class="hermes-stock-row" data-ticker="${ticker}"><div class="hermes-stock-identity"><div class="hermes-stock-title"><span class="hermes-stock-ticker">${ticker}</span>${company ? `<span class="hermes-stock-company">${escape(company)}</span>` : ""}${dailyChange ? `<span class="hermes-stock-change ${changeClass}">${escape(dailyChange)}</span>` : ""}</div><strong class="hermes-stock-price${priceClass}">${escape(price)}</strong></div><dl class="hermes-stock-metrics">${metrics}</dl></section>`;
  });
}

function injectStockPortfolioComparison(html: string): string {
  const comparison = stockPortfolioComparison(html);
  if (!comparison) return html;
  const dateMatch = html.match(/\bdate\s*:\s*(\d{4}-\d{2}-\d{2})/i) ?? html.match(/Stock Brief\s*[—-]\s*(\d{4}-\d{2}-\d{2})/i);
  const titleDate = dateMatch?.[1];
  html = html.replace(
    /<h1>\s*Stock Brief(?:\s*[—-]\s*[^<]+)?\s*<\/h1>/i,
    `<h1>Stock Brief${titleDate ? ` — ${titleDate}` : ""}</h1>`,
  );
  html = normalizeStockQuoteRows(html);
  const closingHeader = /<\/header\s*>/i;
  if (closingHeader.test(html)) return html.replace(closingHeader, (tag) => `${tag}${comparison}`);
  return injectBeforeClosingTag(html, "body", comparison);
}

function removeTacticalAgenda(html: string): string {
  return html.replace(
    /<section\b[^>]*\bclass\s*=\s*(?:"[^"]*\bagenda\b[^"]*"|'[^']*\bagenda\b[^']*')[^>]*>[\s\S]*?<\/section\s*>/gi,
    "",
  );
}

function formatArchiveGenerationTime(generatedAt: number | undefined, timezone: string): string {
  if (!Number.isFinite(generatedAt) || !timezone) return "";
  try {
    const parts = new Intl.DateTimeFormat("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
      timeZone: timezone,
    }).formatToParts(new Date((generatedAt as number) * 1000));
    const hour = parts.find((part) => part.type === "hour")?.value ?? "";
    const minute = parts.find((part) => part.type === "minute")?.value ?? "";
    const dayPeriod = (parts.find((part) => part.type === "dayPeriod")?.value ?? "").toLowerCase();
    if (!hour || !minute || !dayPeriod) return "";
    return minute === "00" ? `${hour}${dayPeriod}` : `${hour}:${minute}${dayPeriod}`;
  } catch {
    return "";
  }
}

function normalizeAiHeroMarkup(html: string, generatedAt?: number): string {
  const dateMarkup = html.match(
    /<p\b(?=[^>]*\bclass\s*=\s*(?:"[^"]*\bdate\b[^"]*"|'[^']*\bdate\b[^']*'))[^>]*>([\s\S]*?)<\/p\s*>/i,
  )?.[1] ?? "";
  const titleDate = html.match(/<h1\b[^>]*>\s*AI Morning Brief\s*(?:—|&mdash;|&#8212;|-)\s*(\d{4}-\d{2}-\d{2})\s*<\/h1\s*>/i)?.[1] ?? "";
  const dateLine = dateMarkup
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&middot;|&#183;/gi, "·")
    .replace(/&amp;/gi, "&")
    .replace(/^\s*Date\/timezone:\s*/i, "")
    .replace(/\s+/g, " ")
    .trim() || titleDate;
  const [pillDate, ...metadataParts] = dateLine.split("·").map((part) => part.trim());
  const archiveMetadata = metadataParts.filter(Boolean).join(" · ");
  const timezone = metadataParts.find((part) => /^[A-Za-z_]+\/[A-Za-z_]+$/.test(part)) ?? "";
  const generationTime = formatArchiveGenerationTime(generatedAt, timezone);
  const metadataLine = [generationTime, archiveMetadata].filter(Boolean).join(" - ");
  const escapeText = (value: string) => value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
  const escapedPillDate = escapeText(pillDate);
  const escapedMetadata = escapeText(metadataLine);

  let normalized = html.replace(
    /<(div|span|p)\b(?=[^>]*\bclass\s*=\s*(?:"[^"]*\btag\b[^"]*"|'[^']*\btag\b[^']*'))[^>]*>[\s\S]*?<\/\1\s*>/gi,
    "",
  );
  const pillPattern = /<(span|div)\b(?=[^>]*\bclass\s*=\s*(?:"[^"]*\bpill\b[^"]*"|'[^']*\bpill\b[^']*'))([^>]*)>[\s\S]*?<\/\1\s*>/i;
  if (pillDate && pillPattern.test(normalized)) {
    normalized = normalized.replace(pillPattern, (_pill, tag: string, attributes: string) => `<${tag}${attributes}>${escapedPillDate}</${tag}>`);
  } else if (pillDate) {
    normalized = normalized.replace(/<h1\b/i, `<span class="pill">${escapedPillDate}</span><h1`);
  }
  const dateParagraphPattern = /<p\b(?=[^>]*\bclass\s*=\s*(?:"[^"]*\bdate\b[^"]*"|'[^']*\bdate\b[^']*'))([^>]*)>[\s\S]*?<\/p\s*>/i;
  normalized = metadataLine
    ? normalized.replace(dateParagraphPattern, (_date, attributes: string) => `<p${attributes}>${escapedMetadata}</p>`)
    : normalized.replace(dateParagraphPattern, "");
  normalized = normalized.replace(
    /<p\b(?=[^>]*\bclass\s*=\s*(?:"[^"]*\bmeta\b[^"]*"|'[^']*\bmeta\b[^']*'))[^>]*>[\s\S]*?<\/p\s*>/gi,
    "",
  );
  normalized = normalized.replace(
    /(<h1\b[^>]*>)\s*AI Morning Brief\s*(?:—|&mdash;|&#8212;|-)\s*\d{4}-\d{2}-\d{2}\s*(<\/h1\s*>)/gi,
    "$1AI Morning Brief$2",
  );
  return normalized.replace(
    /<(header|div)\b(?=[^>]*\bclass\s*=\s*(?:"[^"]*\bhero\b[^"]*"|'[^']*\bhero\b[^']*'))([^>]*)>/i,
    (opening, tag: string, attributes: string) => /\bdata-hermes-date-normalized\s*=/i.test(opening)
      ? opening
      : `<${tag}${attributes} data-hermes-date-normalized="true">`,
  );
}

function formatArchiveDate(date: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return date;
  try {
    return new Intl.DateTimeFormat("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric",
      timeZone: "UTC",
    }).format(new Date(`${date}T00:00:00Z`));
  } catch {
    return date;
  }
}

function normalizeStockHeroMarkup(html: string, generatedAt?: number): string {
  const withoutLegacyPlayer = html.replace(
    /<(button|p|span|div)\b[^>]*>\s*Play\s*\/\s*Pause\s*<\/\1\s*>/gi,
    "",
  );
  const titleDate = withoutLegacyPlayer.match(
    /<h1\b[^>]*>\s*Stock Brief\s*(?:—|&mdash;|&#8212;|-)\s*(\d{4}-\d{2}-\d{2})\s*<\/h1\s*>/i,
  )?.[1] ?? "";
  const timezone = withoutLegacyPlayer.match(/\b([A-Za-z_]+\/[A-Za-z_]+)\b/)?.[1] ?? "";
  const generationTime = formatArchiveGenerationTime(generatedAt, timezone);
  const metadataLine = [generationTime, timezone].filter(Boolean).join(" - ");
  const pillDate = formatArchiveDate(titleDate);
  const escapeText = (value: string) => value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

  let normalized = withoutLegacyPlayer.replace(
    /<(span|div|p)\b(?=[^>]*\bclass\s*=\s*(?:"[^"]*\b(?:pill|tag)\b[^"]*"|'[^']*\b(?:pill|tag)\b[^']*'))[^>]*>[\s\S]*?<\/\1\s*>/gi,
    "",
  );
  normalized = normalized.replace(
    /<(button|p|span|div)\b[^>]*>\s*Play\s*\/\s*Pause\s*<\/\1\s*>/gi,
    "",
  );
  if (titleDate) {
    normalized = normalized.replace(
      /(<h1\b[^>]*>)\s*Stock Brief(?:\s*(?:—|&mdash;|&#8212;|-)\s*\d{4}-\d{2}-\d{2})?\s*(<\/h1\s*>)/gi,
      `$1Stock Brief — ${titleDate}$2`,
    );
  }
  if (pillDate) {
    normalized = normalized.replace(/<h1\b/i, `<span class="pill">${escapeText(pillDate)}</span><h1`);
  }
  const metadataParagraph = /<p\b(?=[^>]*\bclass\s*=\s*(?:"[^"]*\b(?:date|sub)\b[^"]*"|'[^']*\b(?:date|sub)\b[^']*'))[^>]*>[\s\S]*?<\/p\s*>/i;
  if (metadataLine && metadataParagraph.test(normalized)) {
    normalized = normalized.replace(metadataParagraph, `<p class="date">${escapeText(metadataLine)}</p>`);
  } else if (metadataLine) {
    normalized = normalized.replace(/<\/h1\s*>/i, `</h1><p class="date">${escapeText(metadataLine)}</p>`);
  }
  return normalized.replace(/<header\b([^>]*)>/i, (opening, attributes: string) => {
    let updated = opening;
    if (/\bclass\s*=/i.test(attributes)) {
      updated = updated.replace(/\bclass\s*=\s*(["'])(.*?)\1/i, (_match, quote: string, classes: string) => (
        `class=${quote}${classes.split(/\s+/).includes("hero") ? classes : `${classes} hero`}${quote}`
      ));
    } else {
      updated = updated.replace(/^<header/i, '<header class="hero"');
    }
    return /\bdata-hermes-date-normalized\s*=/i.test(updated)
      ? updated
      : updated.replace(/>$/, ' data-hermes-date-normalized="true">');
  });
}

function normalizeAiTakeawayHeadlines(html: string): string {
  return html.replace(
    /(<(?:section|div)\b[^>]*\bclass\s*=\s*(?:"[^"]*\btakeaways\b[^"]*"|'[^']*\btakeaways\b[^']*')[^>]*>[\s\S]*?<\/(?:section|div)\s*>)/gi,
    (takeaways) => takeaways.replace(
      /(<li\b[^>]*>)(?!\s*<strong\b)([\s\S]*?)(<\/li\s*>)/gi,
      (_item, opening, content, closing) => `${opening}<strong>${content.trim()}</strong>${closing}`,
    ),
  );
}

/**
 * Preserves the archived brief's visual HTML/CSS while replacing all archived
 * JavaScript with one isolated, format-independent speech/navigation controller.
 */
export function prepareBriefPreviewHtml(html: string, kind?: BriefKind, generatedAt?: number): string {
  const sanitized = sanitizeArchivedHtml(html);
  const aiArchiveWithoutAgenda = kind === "ai" ? removeTacticalAgenda(sanitized) : sanitized;
  const aiArchiveWithHero = kind === "ai" ? normalizeAiHeroMarkup(aiArchiveWithoutAgenda, generatedAt) : aiArchiveWithoutAgenda;
  const archiveWithHero = kind === "stock" ? normalizeStockHeroMarkup(aiArchiveWithHero, generatedAt) : aiArchiveWithHero;
  const aiArchiveWithHeadlines = kind === "ai" ? normalizeAiTakeawayHeadlines(archiveWithHero) : archiveWithHero;
  const withoutArchivedScripts = kind === "stock" ? injectStockPortfolioComparison(aiArchiveWithHeadlines) : aiArchiveWithHeadlines;

  let withCsp: string;
  if (/<head(?:\s[^>]*)?>/i.test(withoutArchivedScripts)) {
    withCsp = withoutArchivedScripts.replace(
      /<head(?:\s[^>]*)?>/i,
      (head) => `${head}${CSP_META}`,
    );
  } else {
    const head = `<head>${CSP_META}</head>`;
    if (/<html(?:\s[^>]*)?>/i.test(withoutArchivedScripts)) {
      withCsp = withoutArchivedScripts.replace(
        /<html(?:\s[^>]*)?>/i,
        (htmlElement) => `${htmlElement}${head}`,
      );
    } else {
      const doctype = withoutArchivedScripts.match(/^\s*<!doctype[^>]*>/i);
      if (doctype) {
        const insertionPoint = doctype.index! + doctype[0].length;
        withCsp = `${withoutArchivedScripts.slice(0, insertionPoint)}${head}${withoutArchivedScripts.slice(insertionPoint)}`;
      } else {
        withCsp = `${head}${withoutArchivedScripts}`;
      }
    }
  }

  const withPlayerStyle = injectBeforeClosingTag(withCsp, "head", PLAYER_STYLE);
  const withArchiveStyle = kind === "ai"
    ? injectBeforeClosingTag(withPlayerStyle, "head", AI_RESTORED_STYLE)
    : kind === "stock"
      ? injectBeforeClosingTag(withPlayerStyle, "head", STOCK_HERO_STYLE)
      : withPlayerStyle;
  return kind === "stock"
    ? injectBeforeClosingTag(withArchiveStyle, "body", STOCK_DATE_NAV_CONTROLLER)
    : injectBeforeClosingTag(withArchiveStyle, "body", PLAYER_CONTROLLER);
}

/** A text-template export of the same transformed archive used by the iframe. */
export function briefDashboardHtml(
  html: string,
  kind: BriefKind,
  selectedDate: string,
  archiveDates: string[],
  generatedAt?: number,
): string {
  const prepared = prepareBriefPreviewHtml(html, kind, generatedAt);
  const escape = (value: string) => value.replace(/[&<>\"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '\"': "&quot;",
  })[character] || character);
  const title = kind === "ai" ? "BRIEFS-AI" : "BRIEFS-STOCKS";
  const dates = archiveDates.map((date) => {
    const current = date === selectedDate ? ' aria-current="date"' : "";
    return `<span${current}>${escape(date)}</span>`;
  }).join("");
  const shellStyle = `<style id="hermes-brief-export-shell-style">
#hermes-brief-export-shell { margin: 0; padding: 22px 28px; border-bottom: 1px solid rgba(255,255,255,.18); background: #03211f; color: #f9dec9; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
#hermes-brief-export-shell .hermes-export-title { font: 750 24px/1.2 system-ui, sans-serif; letter-spacing: .08em; }
#hermes-brief-export-shell .hermes-export-meta { margin-top: 14px; color: #c9baa8; }
#hermes-brief-export-shell .hermes-export-dates { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 14px; }
#hermes-brief-export-shell .hermes-export-dates span { padding: 8px 12px; border: 1px solid rgba(249,222,201,.35); }
#hermes-brief-export-shell .hermes-export-dates [aria-current="date"] { background: #f9dec9; color: #03211f; font-weight: 800; }
</style>`;
  const shell = `<section id="hermes-brief-export-shell" data-hermes-exclude-from-player><div class="hermes-export-title">${title}</div><div class="hermes-export-meta">Self-contained dashboard export · ${escape(selectedDate)}</div><div class="hermes-export-dates" aria-label="Archive dates">${dates}</div></section>`;
  return prepared
    .replace(/<\/head>/i, `${shellStyle}</head>`)
    .replace(/<body([^>]*)>/i, `<body$1>${shell}`);
}

export function briefDashboardMarkdown(html: string, kind: BriefKind, generatedAt?: number): string {
  const document = new DOMParser().parseFromString(prepareBriefPreviewHtml(html, kind, generatedAt), "text/html");
  const clean = (value: string | null | undefined) => (value ?? "").replace(/\s+/g, " ").trim();
  const lines: string[] = [];
  const heading = clean(document.querySelector("h1")?.textContent) || (kind === "ai" ? "AI Morning Brief" : "Stock Brief");
  lines.push(`# ${heading}`);
  const metadata = clean(document.querySelector("header .date, header .sub")?.textContent);
  if (metadata) lines.push("", metadata);
  const takeaways = document.querySelector(".takeaways");
  if (takeaways) {
    lines.push("", "## FOUNDER TAKEAWAYS");
    takeaways.querySelectorAll("li").forEach((item) => {
      const headline = clean(item.querySelector("strong")?.textContent);
      const detail = clean(item.textContent).replace(headline, "").trim();
      if (headline) lines.push("", `### ${headline}`);
      if (detail) lines.push(detail);
    });
  }
  if (kind === "stock") {
    const comparison = document.querySelector("#hermes-portfolio-comparison");
    if (comparison) lines.push("", clean(comparison.textContent));
    document.querySelectorAll(".hermes-stock-row").forEach((row) => {
      const ticker = clean(row.querySelector(".hermes-stock-ticker")?.textContent);
      const company = clean(row.querySelector(".hermes-stock-company")?.textContent);
      const price = clean(row.querySelector(".hermes-stock-price")?.textContent);
      const metrics = Array.from(row.querySelectorAll("dt, dd")).map((element) => clean(element.textContent)).filter(Boolean).join(" · ");
      lines.push("", `## ${ticker}${company ? ` — ${company}` : ""}`, price, metrics);
    });
  } else {
    document.querySelectorAll(".card, article.card, main article, main section").forEach((card) => {
      const title = clean(card.querySelector("h2, h3")?.textContent);
      const body = clean(card.textContent).replace(title, "").trim();
      if (title) lines.push("", `## ${title}`);
      if (body) lines.push(body);
    });
  }
  return `${lines.filter((line, index) => line || lines[index - 1] !== "").join("\n").trim()}\n`;
}

export function briefPreviewCanvasColor(kind: BriefKind): string {
  return kind === "ai" ? "#0b1020" : "#ffffff";
}

export function briefRoute(
  kind: BriefKind,
  format: "html" | "markdown",
  date: string,
): string {
  return `/api/briefs/${kind}/${format}/${encodeURIComponent(date)}`;
}

export function filterBriefs(briefs: BriefEntry[], query: string): BriefEntry[] {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return briefs;
  return briefs.filter((brief) => brief.date.toLowerCase().includes(normalized));
}

export const BRIEF_DATE_PAGE_SIZE = 5;

export function paginateBriefs(briefs: BriefEntry[], page: number, pageSize = BRIEF_DATE_PAGE_SIZE): BriefEntry[] {
  const safePage = Math.max(0, Math.floor(page));
  return briefs.slice(safePage * pageSize, safePage * pageSize + pageSize);
}

export function adjacentBriefDate(
  briefs: BriefEntry[],
  currentDate: string,
  direction: "newer" | "older",
): BriefEntry | null {
  const currentIndex = briefs.findIndex((brief) => brief.date === currentDate);
  if (currentIndex < 0) return null;
  const targetIndex = currentIndex + (direction === "older" ? 1 : -1);
  return briefs[targetIndex] ?? null;
}

export function briefHtmlDownloadName(kind: BriefKind, date: string): string {
  return `BRIEFS-${kind === "ai" ? "AI" : "STOCKS"} - ${date}.html`;
}

export function briefDownloadName(kind: BriefKind, date: string): string {
  const stem = kind === "ai" ? "AI Morning Brief" : "Stock Brief";
  return `${stem} - ${date}.md`;
}

export function isBriefPlayerShortcut(key: string): boolean {
  return [" ", "Spacebar", "ArrowLeft", "ArrowRight", "ArrowUp"].includes(key);
}

/** Reserved player keys remain global unless the user is editing text. */
export function isBriefPlayerTextEditingTarget(target: EventTarget | null): boolean {
  if (!target || typeof (target as Element).closest !== "function") return false;
  return Boolean((target as Element).closest('input:not([type="range"]), textarea, select, [contenteditable="true"]'));
}

export function focusBriefPreview(iframe: HTMLIFrameElement): void {
  iframe.focus();
  iframe.contentWindow?.focus();
}
