#!/usr/bin/env python3
"""Fail-closed, offline verifier for the sealed V32 Briefs review package."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATES = ["2026-07-20", "2026-07-18", "2026-07-17", "2026-07-16", "2026-07-15"]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"V32_VERIFY_FAIL: {message}")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalized_scripts(document: str) -> list[str]:
    scripts = re.findall(r"<script\b[^>]*>([\s\S]*?)</script>", document, re.I)
    return [re.sub(r"const state = \{.*?\};", "const state = <DATE_PAYLOAD>;", script, count=1) for script in scripts]


def csv_rows(path: Path) -> list[list[str]]:
    text = path.read_text(encoding="utf-8-sig")
    return list(csv.reader(io.StringIO(text)))


# Syntax-check every bundled Python source without writing __pycache__.
python_sources = [ROOT / "server.py", ROOT / "verify_v32.py"]
python_sources.extend(sorted((ROOT / "TEMPLATE-SOURCE" / "materializer").glob("*.py")))
for source_path in python_sources:
    require(source_path.is_file(), f"missing Python source: {source_path.name}")
    compile(source_path.read_text(), str(source_path), "exec")

for kind, label, stream in (("ai", "BRIEFS-AI", "AI"), ("stock", "BRIEFS-STOCKS", "STOCK")):
    style_baseline = None
    script_baseline = None
    for date in DATES:
        html_path = ROOT / "EXPORTS" / stream / f"{label} - {date}.html"
        markdown_path = html_path.with_suffix(".md")
        require(html_path.is_file() and markdown_path.is_file(), f"missing {kind} export for {date}")
        html = html_path.read_text()
        markdown = markdown_path.read_text()
        require("V32 SELF-CONTAINED EXPORT GUIDE" in html, f"missing HTML guide: {html_path.name}")
        require("V32 INLINE CONTROLLER" in html, f"missing controller explanation: {html_path.name}")
        require('"export_schema":"briefs-v32-inline-cyclic"' in html, f"wrong manifest: {html_path.name}")
        require("(current + offset + state.archiveDates.length) % state.archiveDates.length" in html, f"missing cyclic controller: {html_path.name}")
        require("state.archiveDates[current + offset]" not in html, f"linear boundary controller remains: {html_path.name}")
        require(not re.search(r"<script\b[^>]*\bsrc\s*=", html, re.I), f"external script: {html_path.name}")
        require(not re.search(r"<link\b[^>]*\brel=[\"']?stylesheet", html, re.I), f"external stylesheet: {html_path.name}")
        require("V32 SEMANTIC EXPORT" in markdown, f"missing Markdown explanation: {markdown_path.name}")
        if kind == "ai":
            require("hermes-briefs-ai-volume-v1" in html, f"missing volume persistence: {html_path.name}")
            require("hermes-ai-volume-restore" in html and "hermes-ai-volume-change" in html, f"missing volume relay: {html_path.name}")
            require("volumeRestartTimer" not in html, f"volume restart logic remains: {html_path.name}")
        styles = re.findall(r"<style\b[^>]*>([\s\S]*?)</style>", html, re.I)
        scripts = normalized_scripts(html)
        if style_baseline is None:
            style_baseline, script_baseline = styles, scripts
        require(styles == style_baseline, f"style drift: {html_path.name}")
        require(scripts == script_baseline, f"controller drift: {html_path.name}")

# Raw quote CSVs are dynamic per date and must carry the requested trailing Agent field.
quote_csvs = sorted((ROOT / "REFERENCES" / "STOCK").glob("BRIEFS-STOCKS - *.csv"))
require(len(quote_csvs) == 5, "expected five Stock quote CSV files")
for csv_path in quote_csvs:
    rows = csv_rows(csv_path)
    require(rows[0] == ["ticker", "current_price", "daily_change", "daily_change_pct", "Agent"], f"quote CSV header drift: {csv_path.name}")
    require(len(rows) == 8 and all(row[-1] == "HERMES" for row in rows[1:]), f"quote CSV Agent values invalid: {csv_path.name}")

# Dashboard Position Comparison CSVs must also end in Agent=HERMES.
portfolio_csvs = sorted((ROOT / "EXPORTS" / "STOCK").glob("Stock Portfolio - *.csv"))
require(len(portfolio_csvs) == 5, "expected five Position Comparison CSV exports")
for csv_path in portfolio_csvs:
    data = csv_path.read_bytes()
    require(data.startswith(b"\xef\xbb\xbf") and b"\r\n" in data, f"dashboard CSV encoding drift: {csv_path.name}")
    rows = csv_rows(csv_path)
    require(rows[0][-1] == "Agent", f"portfolio CSV header missing Agent: {csv_path.name}")
    require(len(rows) == 11 and all(row[-1] == "HERMES" for row in rows[1:]), f"portfolio CSV Agent values invalid: {csv_path.name}")

# Friday and Monday must be genuinely different; Saturday must carry Friday's completed session.
stock_data = {date: json.loads((ROOT / "REFERENCES" / "STOCK-DATA" / f"{date}.json").read_text()) for date in DATES}
require(stock_data["2026-07-17"]["quotes"] != stock_data["2026-07-20"]["quotes"], "Friday and Monday quote snapshots are still identical")
require(stock_data["2026-07-17"]["quotes"] == stock_data["2026-07-18"]["quotes"], "Saturday does not carry Friday's completed-session quote data")
require(any(q["daily_change"] not in ("$0.00", "+$0.00", "-$0.00") for q in stock_data["2026-07-18"]["quotes"]), "Saturday incorrectly zeroes Friday movement")

collector = (ROOT / "TEMPLATE-SOURCE" / "materializer" / "stock_quote_collector.py").read_text()
prompt = (ROOT / "TEMPLATE-SOURCE" / "materializer" / "prompts" / "stock-generator-prompt.md").read_text()
require("FreshnessError" in collector and "query1.finance.yahoo.com/v8/finance/chart" in collector, "deterministic Yahoo collector missing")
require("<<<HERMES_BRIEF_STOCK_JSON>>>" in prompt and "<<<END_HERMES_BRIEF_STOCK_JSON>>>" in prompt, "producer marker contract missing")
require("copy a prior payload" in prompt and "one identical market-session date" in prompt, "producer freshness rules missing")

export_audit = json.loads((ROOT / "EXPORT_AUDIT.json").read_text())
browser_audit = json.loads((ROOT / "QA" / "BROWSER_AUDIT.json").read_text())
download_audit = json.loads((ROOT / "QA" / "DOWNLOAD_PARITY_AUDIT.json").read_text())
require(export_audit.get("status") == "PASS" and export_audit.get("files") == 25 and not export_audit.get("errors"), "export audit is not 25/25 clean")
require(browser_audit.get("status") == "PASS" and browser_audit.get("checks") == 37, "browser audit is not 37/37")
require(download_audit.get("status") == "PASS" and download_audit.get("files") == 25, "browser download parity is not 25/25")
for screenshot in ("dashboard-ai.png", "dashboard-stock.png", "standalone-ai.png", "standalone-stock.png"):
    require((ROOT / "QA" / screenshot).is_file(), f"missing visual evidence: {screenshot}")
require(not list(ROOT.rglob("*.pyc")) and not list(ROOT.rglob("__pycache__")), "transient Python cache found")

print("V32_STATIC_EXPORT_VERIFY=PASS")
print("HTML_EXPORTS=10 MARKDOWN_EXPORTS=10")
print("AI_VOLUME_NO_RESTART_AND_PERSISTENCE=PASS")
print("DYNAMIC_STOCK_SESSIONS=PASS")
print("QUOTE_CSV_AGENT_HERMES=5/5")
print("PORTFOLIO_CSV_AGENT_HERMES=5/5")
print("BROWSER_EVIDENCE=37/37")
print("BROWSER_DOWNLOAD_PARITY=25/25")
