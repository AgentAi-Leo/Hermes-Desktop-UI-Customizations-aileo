# Briefs AI V61 — complete dashboard review

This is the complete Briefs AI review surface recovered from the verified `LAYOUT_FINAL_BRIEFS-AI-v1-JB` backup and populated with the validated current host cron archive.

## What it includes

- the complete Hermes dashboard shell;
- the full upper cron-output/date section;
- the accepted five-date rail, newest first:
  - `2026-07-20`
  - `2026-07-18`
  - `2026-07-17`
  - `2026-07-16`
  - `2026-07-15`
- HTML and MD availability badges;
- date filtering and selection;
- the embedded accepted V61 AI presentation;
- the real HTML and Markdown export controls;
- the backup's exact preserved `web_dist` build.

The four July 16–20 dates come from the validated normal Mac host directory `~/.hermes/zDownloads/__AI-DAILY-BRIEFS`. July 15 is the newest preserved historical fallback. July 19 is not present and is not fabricated.

## Open

Double-click:

`1_OPEN_FULL_BRIEFS_AI_REVIEW.command`

It starts a read-only local server on `127.0.0.1:9120` and opens Brave. If macOS asks for confirmation, choose **Open**.

Opening the page is silent. Pressing the page's Play control can produce Briefs-AI narration.

## Stop

When finished, double-click:

`2_STOP_BRIEFS_AI_REVIEW.command`

## Safety

- No Hermes files are installed or modified.
- Production port 9119 is not used.
- Port 9120 is never killed or replaced if another process owns it.
- The preview API is read-only and serves only the five bundled pairs.
- Other dashboard sidebar pages are outside this review package's scope.
- Finder metadata and all symbolic links are excluded.
