#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

printf '\nLAYOUTS_FINAL_JB — verifying preserved files...\n'
shasum -a 256 -c CHECKSUMS.sha256

PACKAGE="$ROOT/PACKAGES/PRIMARY-2026-07-17-v42-restore-safe-exports.zip"
EXPECTED_PACKAGE_SHA="2f272469b95f7667aef30834811118d7af5435848fde5a3299713afe2435af69"
ACTUAL_PACKAGE_SHA="$(shasum -a 256 "$PACKAGE" | awk '{print $1}')"
if [ "$ACTUAL_PACKAGE_SHA" != "$EXPECTED_PACKAGE_SHA" ]; then
  echo "Primary restoration package checksum mismatch." >&2
  exit 1
fi

TMP="$(mktemp -d /tmp/layouts-final-jb.XXXXXX)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$PACKAGE" -d "$TMP"
INSTALLER="$TMP/v42-restore-safe-exports/scripts/install-build-restart-open-v42.sh"
if [ ! -f "$INSTALLER" ]; then
  echo "Verified package is missing the V42 installer." >&2
  exit 1
fi

printf '\nChecksums passed. Restoring the cumulative accepted Briefs layout...\n'
bash "$INSTALLER"
printf '\nLAYOUTS_FINAL_JB_RESTORE=PASS\n'
