import { readFileSync } from "node:fs";
// @ts-expect-error jsdom is a transitive test-only dependency without bundled declarations.
import { JSDOM } from "jsdom";
import { describe, expect, it } from "vitest";
import type { BriefEntry } from "@/lib/api";
import {
  BRIEF_DATE_NAV_MESSAGE_TYPE,
  BRIEF_EXPORT_BUTTON_CLASS,
  BRIEF_PLAYER_MESSAGE_TYPE,
  BRIEF_PREVIEW_SANDBOX,
  adjacentBriefDate,
  briefDashboardHtml,
  briefDashboardMarkdown,
  briefDownloadName,
  briefHtmlDownloadName,
  briefPreviewCanvasColor,
  briefRoute,
  filterBriefs,
  focusBriefPreview,
  isBriefPlayerShortcut,
  isBriefPlayerTextEditingTarget,
  matchingStockPortfolioCsv,
  paginateBriefs,
  prepareBriefPreviewHtml,
  stockPortfolioCsv,
  stockPortfolioCsvName,
  stockDateNavigationDirection,
  supportsBriefDateNavigation,
} from "./briefs";

const entries: BriefEntry[] = [
  {
    date: "2026-07-14",
    generated_at: 1_784_214_000,
    html_exists: true,
    markdown_exists: true,
    html_route: "/api/briefs/ai/html/2026-07-14",
    markdown_route: "/api/briefs/ai/markdown/2026-07-14",
  },
  {
    date: "2026-07-13",
    generated_at: 1_784_127_600,
    html_exists: true,
    markdown_exists: false,
    html_route: "/api/briefs/ai/html/2026-07-13",
    markdown_route: null,
  },
];

describe("brief helpers", () => {
  it("builds archive routes", () => {
    expect(briefRoute("stock", "html", "2026-07-14")).toBe(
      "/api/briefs/stock/html/2026-07-14",
    );
  });

  it("uses a dark AI preview canvas to prevent white flashes during date navigation", () => {
    expect(briefPreviewCanvasColor("ai")).toBe("#0b1020");
    expect(briefPreviewCanvasColor("stock")).toBe("#ffffff");
  });

  it("supports adjacent-date messages for AI and Stock and keeps export controls 50% larger", () => {
    expect(supportsBriefDateNavigation("ai")).toBe(true);
    expect(supportsBriefDateNavigation("stock")).toBe(true);
    expect(BRIEF_EXPORT_BUTTON_CLASS).toContain("h-[3.375rem]");
    expect(BRIEF_EXPORT_BUTTON_CLASS).toContain("text-[1.125rem]");
    expect(BRIEF_EXPORT_BUTTON_CLASS).toContain("[&_svg]:h-6");
  });

  it("keeps the accepted AI export overlay while moving Stock exports and adjacent-date navigation into the selected-date toolbar", () => {
    const briefsPage = readFileSync(new URL("../pages/BriefsPage.tsx", import.meta.url), "utf8");
    const briefsSource = readFileSync(new URL("./briefs.ts", import.meta.url), "utf8");
    const app = readFileSync(new URL("../App.tsx", import.meta.url), "utf8");
    expect(briefsPage.match(/renderExportButtons\(\"preview\"\)/g)).toHaveLength(1);
    expect(briefsPage.match(/renderExportButtons\(\"stock-toolbar\"\)/g)).toHaveLength(1);
    expect(briefsPage).toContain('data-hermes-stock-date-navigation');
    expect(briefsPage).toContain('kind === "ai" && !previewLoading && previewUrl && selected');
    expect(briefsPage).not.toContain('kind === "stock" && !previewLoading && previewUrl && selected');
    expect(app).toContain('to={{ pathname: "/briefs-ai", search: location.search, hash: location.hash }}');
    expect(briefsSource).toContain("left: 50% !important");
    expect(briefsSource).toContain("transform: translate(-50%, -50%) !important");
  });

  it("filters entries by date", () => {
    expect(filterBriefs(entries, "07-13")).toEqual([entries[1]]);
    expect(filterBriefs(entries, "   ")).toEqual(entries);
  });

  it("paginates date rails newest-first without expanding their width", () => {
    const dated = Array.from({ length: 15 }, (_, index) => ({ ...entries[0], date: `2026-07-${String(15 - index).padStart(2, "0")}` }));
    expect(paginateBriefs(dated, 0).map((entry) => entry.date)).toHaveLength(5);
    expect(paginateBriefs(dated, 1).map((entry) => entry.date)).toEqual(dated.slice(5, 10).map((entry) => entry.date));
    expect(paginateBriefs(dated, 2).map((entry) => entry.date)).toEqual(dated.slice(10, 15).map((entry) => entry.date));
  });

  it("selects adjacent cron dates without wrapping at archive boundaries", () => {
    expect(adjacentBriefDate(entries, "2026-07-14", "older")?.date).toBe("2026-07-13");
    expect(adjacentBriefDate(entries, "2026-07-13", "newer")?.date).toBe("2026-07-14");
    expect(adjacentBriefDate(entries, "2026-07-14", "newer")).toBeNull();
    expect(adjacentBriefDate(entries, "2026-07-13", "older")).toBeNull();
  });

  it("maps Stock left and right arrow keys to the visible newer and older date controls", () => {
    expect(stockDateNavigationDirection("ArrowLeft")).toBe("newer");
    expect(stockDateNavigationDirection("ArrowRight")).toBe("older");
    expect(stockDateNavigationDirection("ArrowUp")).toBeNull();

    const stockPreview = prepareBriefPreviewHtml(
      '<!doctype html><html><head></head><body><header><h1>Stock Brief — 2026-07-16</h1></header><article id="AAPL">AAPL $333.26</article></body></html>',
      "stock",
    );
    expect(stockPreview).toContain('id="hermes-stock-interaction-controller"');
    expect(stockPreview).toContain('event.key === "ArrowLeft" ? "newer"');
    expect(stockPreview).toContain('event.key === "ArrowRight" ? "older"');
    expect(stockPreview).toContain('event.target instanceof HTMLInputElement');
    expect(stockPreview).toContain('type: "hermes-brief-date-navigation", direction, position: captureViewportPosition()');
    expect(stockPreview).toContain('type: "hermes-stock-viewport-state", position: captureViewportPosition()');
    expect(stockPreview).toContain('event.data?.type !== "hermes-stock-viewport-restore"');
    expect(stockPreview).toContain('window.scrollTo(targetX, targetY)');
    expect(stockPreview).toContain('requestAnimationFrame(applyPosition)');
    expect(stockPreview).not.toContain('candidate.getAttribute("data-ticker") === ticker');
    expect(stockPreview).not.toContain('row.getBoundingClientRect().top - anchor.top');
    const briefsPage = readFileSync(new URL("../pages/BriefsPage.tsx", import.meta.url), "utf8");
    expect(briefsPage).toContain("latestStockViewportPositionRef");
    expect(briefsPage).toContain("pendingStockViewportPositionRef.current = latestStockViewportPositionRef.current");
    expect(briefsPage).toContain('type: "hermes-stock-viewport-restore", position');
    expect(briefsPage).toContain("Number.isFinite(position?.scrollX)");
    expect(briefsPage).toContain("Number.isFinite(position?.scrollY)");
  });

  it("adds a working fullscreen toggle immediately beside the Stock Brief title", () => {
    const stockPreview = prepareBriefPreviewHtml(
      '<!doctype html><html><head></head><body><header><h1>Stock Brief — 2026-07-16</h1></header><article id="AAPL">AAPL $333.26</article></body></html>',
      "stock",
    );
    const dom = new JSDOM(stockPreview, { runScripts: "dangerously" });
    const titleRow = dom.window.document.querySelector(".hermes-stock-title-row");
    const button = titleRow?.querySelector<HTMLButtonElement>("h1 + #hermes-stock-fullscreen-button");
    let requested = 0;
    let exited = 0;
    Object.defineProperty(dom.window.document.documentElement, "requestFullscreen", {
      configurable: true,
      value: () => { requested += 1; },
    });
    Object.defineProperty(dom.window.document, "exitFullscreen", {
      configurable: true,
      value: () => { exited += 1; },
    });

    expect(button?.getAttribute("aria-label")).toBe("Enter Stock Brief fullscreen");
    expect(button?.querySelector('svg[viewBox="0 0 24 24"]')).not.toBeNull();
    button?.click();
    expect(requested).toBe(1);

    Object.defineProperty(dom.window.document, "fullscreenElement", {
      configurable: true,
      get: () => dom.window.document.documentElement,
    });
    button?.click();
    expect(exited).toBe(1);

    const briefsPage = readFileSync(new URL("../pages/BriefsPage.tsx", import.meta.url), "utf8");
    expect(briefsPage).toContain("allowFullScreen");
    expect(stockPreview).toContain('type: "hermes-stock-fullscreen-toggle"');
    expect(stockPreview).toContain('event.data?.type === "hermes-stock-fullscreen-state"');
    expect(briefsPage).toContain("await iframe.requestFullscreen()");
    expect(briefsPage).toContain("document.fullscreenElement === iframe");
    expect(briefsPage.match(/setPreviewUrl\(null\)/g)).toHaveLength(1);
    expect(briefsPage).toContain("{previewUrl && (");
    expect(briefsPage).toContain("{previewLoading && (");
    expect(stockPreview).toContain(".hermes-stock-title-row { display: flex !important; align-items: center !important;");
    expect(stockPreview).toContain("#hermes-stock-fullscreen-button { display: inline-grid !important; width: 44px !important; height: 44px !important; flex: 0 0 44px !important;");
    expect(stockPreview).toContain("#hermes-stock-fullscreen-button svg { width: 26px !important; height: 26px !important;");
  });

  it("reserves Enter exclusively for Stock fullscreen even on focused controls", () => {
    const stockPreview = prepareBriefPreviewHtml(
      '<!doctype html><html><head></head><body><header><h1>Stock Brief — 2026-07-16</h1></header><input aria-label="Filter"><article id="AAPL">AAPL $333.26</article></body></html>',
      "stock",
    );
    const dom = new JSDOM(stockPreview, { runScripts: "dangerously" });
    let requested = 0;
    Object.defineProperty(dom.window.document.documentElement, "requestFullscreen", {
      configurable: true,
      value: () => { requested += 1; },
    });

    dom.window.document.body.dispatchEvent(new dom.window.KeyboardEvent("keydown", {
      key: "Enter", bubbles: true, cancelable: true,
    }));
    expect(requested).toBe(1);

    dom.window.document.querySelector("input")?.dispatchEvent(new dom.window.KeyboardEvent("keydown", {
      key: "Enter", bubbles: true, cancelable: true,
    }));
    expect(requested).toBe(2);
  });

  it("gives AI page-level Enter fullscreen parity without starting or cancelling audio", () => {
    const aiPreview = prepareBriefPreviewHtml(`<!doctype html><html><head></head><body><main>
      <header><span class="pill">July 16, 2026</span><h1>AI Morning Brief</h1><p class="date">July 16, 2026 · America/Los_Angeles</p></header>
      <section class="topics"><article class="card"><h2>1. Topic one</h2><p>Summary one.</p></article></section>
    </main></body></html>`, "ai");
    const dom = new JSDOM(aiPreview, { runScripts: "outside-only" });
    let requested = 0;
    let cancelled = 0;
    let spoken = 0;
    Object.defineProperty(dom.window, "speechSynthesis", {
      configurable: true,
      value: {
        cancel: () => { cancelled += 1; },
        speak: () => { spoken += 1; },
        getVoices: () => [{ name: "Samantha", lang: "en-US", localService: true }],
        pause: () => undefined,
        resume: () => undefined,
      },
    });
    Object.defineProperty(dom.window, "SpeechSynthesisUtterance", {
      configurable: true,
      value: class { text: string; constructor(text: string) { this.text = text; } },
    });
    Object.defineProperty(dom.window, "ResizeObserver", {
      configurable: true,
      value: class { observe() {} },
    });
    Object.defineProperty(dom.window.document.documentElement, "requestFullscreen", {
      configurable: true,
      value: () => { requested += 1; },
    });
    const controller = dom.window.document.querySelector("#hermes-brief-player-controller")?.textContent ?? "";
    dom.window.eval(controller);
    dom.window.document.dispatchEvent(new dom.window.Event("DOMContentLoaded"));
    const cancelledAfterInitialization = cancelled;

    const button = dom.window.document.querySelector<HTMLButtonElement>("h1 + #hermes-ai-fullscreen-button");
    expect(button?.getAttribute("aria-label")).toBe("Enter AI Morning Brief fullscreen");
    dom.window.document.body.dispatchEvent(new dom.window.KeyboardEvent("keydown", {
      key: "Enter", bubbles: true, cancelable: true,
    }));

    expect(requested).toBe(1);
    expect(spoken).toBe(0);
    expect(cancelled).toBe(cancelledAfterInitialization);
  });

  it("shows the exact active date beside Founder Takeaways and every topic Sources line", () => {
    const aiPreview = prepareBriefPreviewHtml(`<!doctype html><html><head></head><body><main>
      <header><span class="pill">July 16, 2026</span><h1>AI Morning Brief</h1><p class="date">July 16, 2026 · America/Los_Angeles</p></header>
      <section class="takeaways"><h2>FOUNDER TAKEAWAYS</h2><ol><li><strong>Key point.</strong> Detail.</li></ol></section>
      <section class="topics">
        <article class="card"><h2>1. Topic one</h2><p>Summary one.</p><p class="sources">Sources: Reuters</p></article>
        <article class="card"><h2>2. Topic two</h2><p>Summary two.</p><p class="sources">Sources: TechCrunch</p></article>
      </section>
    </main></body></html>`, "ai");

    expect(aiPreview).toContain('class="hermes-takeaways-heading-row"');
    expect(aiPreview.match(/class="hermes-ai-active-date-pill"/g)).toHaveLength(3);
    expect(aiPreview.match(/>July 16, 2026<\/span>/g)).toHaveLength(4);
    expect(aiPreview.match(/class="hermes-ai-sources-row"/g)).toHaveLength(2);
    expect(aiPreview).toContain(".hermes-ai-active-date-pill { display: inline-flex !important;");
  });

  it("keeps the stable parent iframe fullscreen for AI and republishes state after date loads", () => {
    const aiPreview = prepareBriefPreviewHtml(`<!doctype html><html><head></head><body><main>
      <header><span class="pill">July 16, 2026</span><h1>AI Morning Brief</h1><p class="date">July 16, 2026 · America/Los_Angeles</p></header>
      <article class="card"><h2>1. Topic one</h2><p>Summary one.</p></article>
    </main></body></html>`, "ai");
    const briefsPage = readFileSync(new URL("../pages/BriefsPage.tsx", import.meta.url), "utf8");

    expect(aiPreview).toContain('type: "hermes-ai-fullscreen-toggle"');
    expect(aiPreview).toContain('event.data?.type === "hermes-ai-fullscreen-state"');
    expect(briefsPage).toContain('kind !== "ai" && kind !== "stock"');
    expect(briefsPage).toContain('event.data?.type !== `${fullscreenMessagePrefix}-fullscreen-toggle`');
    expect(briefsPage).toContain('{ type: `${fullscreenMessagePrefix}-fullscreen-state`, active: document.fullscreenElement === iframe }');
    expect(briefsPage).toContain("await iframe.requestFullscreen()");
    expect(briefsPage).toContain("document.fullscreenElement === iframe");
    expect(briefsPage.match(/setPreviewUrl\(null\)/g)).toHaveLength(1);
  });

  it("reserves parent-document Enter exclusively for the stable preview iframe fullscreen", () => {
    const briefsPage = readFileSync(new URL("../pages/BriefsPage.tsx", import.meta.url), "utf8");
    expect(briefsPage).toContain("const handlePreviewFullscreenShortcut = (event: KeyboardEvent) => {");
    expect(briefsPage).toContain('if (event.key !== "Enter") return;');
    expect(briefsPage).not.toContain("isBriefFullscreenInteractiveTarget");
    expect(briefsPage).toContain("await iframe.requestFullscreen()");
    expect(briefsPage).toContain("window.addEventListener(\"keydown\", handlePreviewFullscreenShortcut, true)");
    expect(briefsPage).toContain("window.removeEventListener(\"keydown\", handlePreviewFullscreenShortcut, true)");
  });

  it("reserves topic-card Enter for fullscreen and never restarts active-card narration", () => {
    const aiPreview = prepareBriefPreviewHtml(`<!doctype html><html><head></head><body><main>
      <header><span class="pill">July 16, 2026</span><h1>AI Morning Brief</h1><p class="date">July 16, 2026 · America/Los_Angeles</p></header>
      <section class="topics"><article class="card"><h2>1. Topic one</h2><p>Summary one.</p></article></section>
    </main></body></html>`, "ai");
    const dom = new JSDOM(aiPreview, { runScripts: "outside-only" });
    let requested = 0;
    let cancelled = 0;
    let spoken = 0;
    Object.defineProperty(dom.window, "speechSynthesis", {
      configurable: true,
      value: {
        cancel: () => { cancelled += 1; },
        speak: () => { spoken += 1; },
        getVoices: () => [{ name: "Samantha", lang: "en-US", localService: true }],
        pause: () => undefined,
        resume: () => undefined,
      },
    });
    Object.defineProperty(dom.window, "SpeechSynthesisUtterance", {
      configurable: true,
      value: class { text: string; volume = 1; voice = null; lang = ""; pitch = 1; rate = 1; onend = null; onerror = null; constructor(text: string) { this.text = text; } },
    });
    Object.defineProperty(dom.window, "ResizeObserver", {
      configurable: true,
      value: class { observe() {} },
    });
    Object.defineProperty(dom.window.document.documentElement, "requestFullscreen", {
      configurable: true,
      value: () => { requested += 1; },
    });
    Object.defineProperty(dom.window.HTMLElement.prototype, "scrollIntoView", {
      configurable: true,
      value: () => undefined,
    });
    const controller = dom.window.document.querySelector("#hermes-brief-player-controller")?.textContent ?? "";
    dom.window.eval(controller);
    dom.window.document.dispatchEvent(new dom.window.Event("DOMContentLoaded"));

    const card = dom.window.document.querySelector<HTMLElement>(".hermes-playable-card");
    card?.click();
    expect(spoken).toBe(1);
    const cancelledAfterNarrationStart = cancelled;

    card?.dispatchEvent(new dom.window.KeyboardEvent("keydown", {
      key: "Enter", bubbles: true, cancelable: true,
    }));
    expect(requested).toBe(1);
    expect(spoken).toBe(1);
    expect(cancelled).toBe(cancelledAfterNarrationStart);

    const escape = new dom.window.KeyboardEvent("keydown", {
      key: "Escape", bubbles: true, cancelable: true,
    });
    dom.window.document.body.dispatchEvent(escape);
    expect(escape.defaultPrevented).toBe(false);
    expect(spoken).toBe(1);
    expect(cancelled).toBe(cancelledAfterNarrationStart);
  });

  it("locks AI narration to the accepted 1.15x rate without changing the female voice policy", () => {
    const aiPreview = prepareBriefPreviewHtml(`<!doctype html><html><head></head><body><main>
      <header><span class="pill">July 16, 2026</span><h1>AI Morning Brief</h1><p class="date">July 16, 2026 · America/Los_Angeles</p></header>
      <section class="topics"><article class="card"><h2>1. Topic one</h2><p>Summary one.</p></article></section>
    </main></body></html>`, "ai");

    expect(aiPreview).toContain('"Samantha", "Ava", "Allison", "Susan", "Victoria", "Karen", "Moira"');
    expect(aiPreview).toContain("utterance.pitch = 1;");
    expect(aiPreview).toContain("utterance.rate = 1.15;");
    expect(aiPreview).not.toContain("utterance.rate = 1.25;");
  });

  it("keeps keyboard focus and viewport on the player while play and topic controls run", () => {
    const aiPreview = prepareBriefPreviewHtml(`<!doctype html><html><head></head><body><main>
      <header><span class="pill">July 16, 2026</span><h1>AI Morning Brief</h1><p class="date">July 16, 2026 · America/Los_Angeles</p></header>
      <section class="topics">
        <article class="card"><h2>1. Topic one</h2><p>Summary one.</p></article>
        <article class="card"><h2>2. Topic two</h2><p>Summary two.</p></article>
      </section>
    </main></body></html>`, "ai");
    const dom = new JSDOM(aiPreview, { runScripts: "outside-only" });
    let scrollCalls = 0;
    let spoken = 0;
    Object.defineProperty(dom.window, "speechSynthesis", {
      configurable: true,
      value: {
        cancel: () => undefined,
        speak: () => { spoken += 1; },
        getVoices: () => [{ name: "Samantha", lang: "en-US", localService: true }],
        pause: () => undefined,
        resume: () => undefined,
      },
    });
    Object.defineProperty(dom.window, "SpeechSynthesisUtterance", {
      configurable: true,
      value: class { text: string; volume = 1; voice = null; lang = ""; pitch = 1; rate = 1; onend = null; onerror = null; constructor(text: string) { this.text = text; } },
    });
    Object.defineProperty(dom.window, "ResizeObserver", {
      configurable: true,
      value: class { observe() {} },
    });
    Object.defineProperty(dom.window.HTMLElement.prototype, "scrollIntoView", {
      configurable: true,
      value: () => { scrollCalls += 1; },
    });
    const controller = dom.window.document.querySelector("#hermes-brief-player-controller")?.textContent ?? "";
    dom.window.eval(controller);
    dom.window.document.dispatchEvent(new dom.window.Event("DOMContentLoaded"));

    const play = dom.window.document.querySelector<HTMLButtonElement>('#hermes-brief-player button[aria-label="Play reading"]');
    const next = dom.window.document.querySelector<HTMLButtonElement>('#hermes-brief-player button[aria-label="Next topic"]');
    play?.focus();
    play?.click();
    expect(dom.window.document.activeElement).toBe(play);
    expect(spoken).toBe(1);
    expect(scrollCalls).toBe(0);

    next?.focus();
    next?.click();
    expect(dom.window.document.activeElement).toBe(next);
    expect(spoken).toBe(2);
    expect(scrollCalls).toBe(0);
  });

  it("builds stable download filenames", () => {
    expect(briefDownloadName("ai", "2026-07-14")).toBe(
      "AI Morning Brief - 2026-07-14.md",
    );
    expect(briefDownloadName("stock", "2026-07-14")).toBe(
      "Stock Brief - 2026-07-14.md",
    );
    expect(briefHtmlDownloadName("ai", "2026-07-14")).toBe("BRIEFS-AI - 2026-07-14.html");
    expect(briefHtmlDownloadName("stock", "2026-07-14")).toBe("BRIEFS-STOCKS - 2026-07-14.html");
  });

  it("removes archived scripts and injects one network-isolated controller", () => {
    const archivedScript = `
      <script>
        function toggleSpeech() { speechSynthesis.speak(new SpeechSynthesisUtterance("brief")); }
        document.addEventListener("keydown", archivedKeyboardHandler);
      </script>`;

    const result = prepareBriefPreviewHtml(`<!doctype html><html><head>
      <style>body { color: navy; }</style>
      <script src="https://cdn.example.test/player.js"></script>
      ${archivedScript}
    </head><body><h1>Morning brief</h1></body></html>`);

    expect(result).not.toContain("toggleSpeech");
    expect(result).not.toContain("archivedKeyboardHandler");
    expect(result).toContain('id="hermes-brief-player-controller"');
    expect(result).toContain("<style>body { color: navy; }</style>");
    expect(result).toContain("<h1>Morning brief</h1>");
    expect(result).not.toContain("cdn.example.test");
    expect(result).toContain('http-equiv="Content-Security-Policy"');
    expect(result).toContain("default-src 'none'");
    expect(result).toContain("script-src 'unsafe-inline'");
    expect(result).toContain("connect-src 'none'");
  });

  it("removes every external script regardless of attribute order or quote style", () => {
    const result = prepareBriefPreviewHtml(`<html><body>
      <script defer SRC='https://example.test/a.js'>fallbackA()</script>
      <script src=/relative.js async>fallbackB()</script>
      <script data-purpose="src=example">keepInline()</script>
    </body></html>`);

    expect(result).not.toContain("example.test/a.js");
    expect(result).not.toContain("/relative.js");
    expect(result).not.toContain("fallbackA()");
    expect(result).not.toContain("fallbackB()");
    expect(result).not.toContain('data-purpose="src=example"');
    expect(result).not.toContain("keepInline()");
    expect(result.match(/<script\b/gi)).toHaveLength(1);
  });

  it("removes archived inline handlers, javascript URLs, srcdoc, and meta refresh", () => {
    const result = prepareBriefPreviewHtml(`<!doctype html><html><head>
      <meta http-equiv="refresh" content="0;url=https://example.test">
      <meta http-equiv="Content-Security-Policy" content="script-src *">
    </head><body onload="oldLoad()">
      <section class="card" onclick='oldClick()' onkeydown=oldKey()>
        <a href="javascript:oldLink()">Unsafe link</a>
        <a href="java
script:oldObfuscatedLink()">Obfuscated unsafe link</a>
        <iframe srcdoc="&lt;script&gt;oldFrame()&lt;/script&gt;"></iframe>
      </section>
    </body></html>`);

    expect(result).not.toMatch(/\son(?:load|click|keydown)\s*=/i);
    expect(result).not.toMatch(/href\s*=\s*["']?\s*javascript:/i);
    expect(result).not.toMatch(/\ssrcdoc\s*=/i);
    expect(result).not.toMatch(/http-equiv\s*=\s*["']refresh/i);
    expect(result).not.toContain("oldLoad()");
    expect(result).not.toContain("oldClick()");
    expect(result).not.toContain("oldKey()");
    expect(result).not.toContain("oldLink()");
    expect(result).not.toContain("oldObfuscatedLink()");
    expect(result).not.toContain("oldFrame()");
    expect(result).not.toContain("script-src *");
  });

  it("injects one fixed player supporting historical and current controls", () => {
    const result = prepareBriefPreviewHtml(`<!doctype html><html><head></head><body>
      <main class="wrap"><header><h1>AI Morning Brief</h1>
      <div class="tts"><button id="prev">previous</button><button id="play">play</button><button id="next">next</button><input id="vol" type="range"></div>
      </header><section class="card"><h2>First topic</h2><p class="summary">Summary</p></section></main>
      <script>document.addEventListener('keydown', brokenArchivedHandler)</script>
    </body></html>`);

    expect(result).not.toContain("brokenArchivedHandler");
    expect(result).toContain("hermes-brief-player-sticky");
    expect(result).toContain("position: fixed !important");
    expect(result).toContain("hermes-brief-player-placeholder");
    expect(result).toContain("ResizeObserver");
    expect(result).toContain("ensureHermesPlayer");
    expect(result).toContain('player.id = "hermes-brief-player"');
    expect(result).toContain('id="tts-volume"');
    expect(result).toContain('class="hermes-player-volume"><input');
    expect(result).not.toContain('class="hermes-player-volume">Volume ');
    expect(result).not.toContain('id="tts-status"');
    expect(result).not.toContain('statusElement = document.getElementById("tts-status")');
    expect(result).toContain("width: 137.5px !important");
    expect(result).toContain(".wrap { width: 100% !important");
    expect(result).not.toContain("Keys: Space Play/Pause · ← Previous · → Next · ↑ Founder takeaways / first topic + Play");
    expect(result).toContain("function selectAndPlay(selectedIndex, options = {})");
    expect(result).toContain("function setVolume(value)");
    expect(result).toContain("volumeRestartTimer");
    expect(result).toContain("configureNaturalVoice(utterance)");
    expect(result).toContain("utterance.rate = 1.15");
    expect(result).not.toContain("utterance.rate = 1.25");
    expect(result).toContain('card.addEventListener("click"');
    expect(result).toContain("const selectedIndex = cards.indexOf(selectedCard)");
    expect(result).toContain('card.setAttribute("role", "button")');
    expect(result).toContain("playButton.textContent = paused || !playing ?");
    expect(result).toContain(BRIEF_PLAYER_MESSAGE_TYPE);
    expect(result).toContain(BRIEF_DATE_NAV_MESSAGE_TYPE);
    expect(result).toContain('navigator.setAttribute("aria-label", "Cron date navigation")');
    expect(result).toContain('id="hermes-date-newer"');
    expect(result).toContain('id="hermes-date-older"');
    expect(result).toContain('id="hermes-date-newer"');
    expect(result).toContain('class="hermes-date-nav-label">DATE</span>');
    expect(result).toMatch(/id="hermes-date-newer"[^>]*>‹<\/button><span class="hermes-date-nav-label">DATE<\/span><button id="hermes-date-older"/);
    expect(result).toContain("shell.appendChild(navigator)");
    expect(result).not.toContain('pill.insertAdjacentElement("afterend", navigator)');
    expect(result).toContain("event.source !== window.parent");
    expect(result).toContain("function isVolumeControl(target)");
    expect(result).toContain("if (textEditingTarget(event.target) && !isVolumeControl(event.target)) return;");
    expect(result).toContain("volumeInput.tabIndex = -1;");
    expect(result).toContain('volumeInput.addEventListener("keydown", (event) => {');
    expect(result).toContain("// The slider is pointer-only: preserve player keys and suppress every native range key.");
    expect(result).toContain("runCommand(command);\n    }, true);");
    expect(result).toContain("selectAndPlay(0)");
  });

  it("restores the exact top Portfolio Position Comparison, removes the producer bottom comparison, and keeps quote rows and CSV data", () => {
    const stockHtml = `<!doctype html><html><head></head><body><main>
      <header><h1>Stock Brief — 2026-07-06</h1><button id="playPause">Play/Pause</button></header>
      <section aria-label="Stock price cards">
        <article class="card"><h2>AAPL — Apple</h2><p class="positive">▲ +3.96 (+1.28%)</p><strong>$312.59</strong></article>
        <article class="card"><h2>GOOGL — Alphabet</h2><p class="positive">▲ +1.48 (+0.41%)</p><strong>$361.39</strong></article>
        <article class="card"><h2>AMZN — Amazon</h2><p class="positive">▲ +0.04 (+0.02%)</p><strong>$242.71</strong></article>
        <article class="card"><h2>MSFT — Microsoft</h2><p class="negative">▼ -2.03 (-0.52%)</p><strong>$385.49</strong></article>
        <article class="card"><h2>NVDA — NVIDIA</h2><p class="positive">▲ +5.44 (+2.86%)</p><strong>$195.82</strong></article>
        <article class="card"><h2>DIS — Disney</h2><p class="negative">▼ -2.07 (-2.08%)</p><strong>$95.87</strong></article>
        <article class="card"><h2>SNAP — Snap</h2><p class="negative">▼ -0.10 (-2.06%)</p><strong>$4.75</strong></article>
      </section>
      <section id="hermes-portfolio-comparison" aria-label="Portfolio Position Comparison"><h2>Portfolio comparison</h2><table><tbody><tr><td>Legacy portfolio row</td></tr></tbody></table></section>
    </main></body></html>`;

    const result = prepareBriefPreviewHtml(stockHtml, "stock");

    expect(result).toContain('<span id="hermes-stock-date-pill" data-hermes-stock-date-pill="true" role="status" aria-label="Stock brief date: July 6, 2026"');
    expect(result).toContain("<h1>Stock Brief</h1>");
    expect(result).not.toContain("<h1>Stock Brief — 2026-07-06</h1>");
    expect(result.match(/id="hermes-portfolio-comparison"/g)).toHaveLength(1);
    expect(result).toContain("Portfolio Position Comparison");
    expect(result).toContain("Daily prices compared with your purchase lots. Precise basis uses shares × purchased price.");
    expect(result).toContain("Available-position total");
    expect(result).not.toContain("Legacy portfolio row");
    expect(result).not.toContain("<h2>Portfolio comparison</h2>");
    expect(result).not.toContain("Play/Pause");
    expect(result).not.toContain("hermes-stock-date-nav-controller");
    expect(result).toContain('<section class="hermes-stock-row" data-ticker="AAPL">');
    expect(result).toContain(".hermes-stock-row { grid-column: 1 / -1 !important;");
    expect(result).toContain("grid-template-columns: minmax(520px, 1.05fr) minmax(190px, .42fr) minmax(0, 1.75fr) !important");
    expect(result).toContain('<span class="hermes-stock-ticker">NVDA</span>');
    expect(result).toContain('<strong class="hermes-stock-price">$195.82</strong>');
    expect(result).toContain('<span class="hermes-stock-ticker">DIS</span>');
    expect(result).toContain('<strong class="hermes-stock-price">$95.87</strong>');
    expect(result).not.toContain('<article class="card"><h2>AAPL');
    expect(result).not.toContain("<strong>$312.59</strong>");
    expect(result).toContain(".hermes-stock-price { display: block !important; margin-top: 8px !important; color: #ffe08a !important; font-size: 1.84rem !important;");
    expect(result).toContain(".hermes-stock-metrics dd { margin: 7px 0 0 !important; color: var(--text, #f4f7fb) !important; font-size: 1.9rem !important;");

    const missingSnapHtml = stockHtml.replace(
      /\s*<article class="card"><h2>SNAP — Snap<\/h2><p class="negative">▼ -0\.10 \(-2\.06%\)<\/p><strong>\$4\.75<\/strong><\/article>/,
      "",
    );
    const csv = stockPortfolioCsv(stockHtml, "2026-07-06");
    const lines = csv.trim().split("\r\n");
    expect(lines).toHaveLength(11);
    lines.forEach((line) => expect(line.split(",")).toHaveLength(12));
    expect(lines[0]).toBe(
      "Brief Date,Position,Ticker,Purchase Date,Shares,Purchased Price,Current Price,Price Difference,Cost Basis,Current Value,Gain Loss,Position Return Percent",
    );
    expect(lines[1]).toBe(
      "2026-07-06,DISNEY,DIS,8/05/66,268,25.00,95.87,70.87,6700.00,25693.16,18993.16,283.48",
    );
    expect(lines[2]).toBe(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,312.59,121.59,27886.00,45638.14,17752.14,63.66",
    );
    expect(lines).toContain(
      "2026-07-06,SNAP,SNAP,2/3/26,1786,6.18,4.75,-1.43,11037.48,8483.50,-2553.98,-23.14",
    );
    expect(csv).not.toContain("$");
    expect(csv).not.toContain("bought");
    expect(stockPortfolioCsvName("2026-07-06")).toBe("Stock Portfolio - 2026-07-06.csv");

    const missingSnapCsv = stockPortfolioCsv(missingSnapHtml, "2026-07-06");
    expect(missingSnapCsv).toContain(
      "2026-07-06,SNAP,SNAP,2/3/26,1786,6.18,,,11037.48,,,",
    );

    const crossCardHtml = "<h2>AAPL — price unavailable</h2><h2>AMZN — Amazon $242.71</h2>";
    const crossCardCsv = stockPortfolioCsv(crossCardHtml, "2026-07-06").split("\r\n");
    expect(crossCardCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,,,27886.00,,,",
    );
    expect(crossCardCsv).toContain(
      "2026-07-06,AMAZON-1,AMZN,5/29/24,138,181.00,242.71,61.71,24978.00,33493.98,8515.98,34.09",
    );
    const crossCardUi = prepareBriefPreviewHtml(crossCardHtml, "stock");
    expect(crossCardUi).toContain("Portfolio Position Comparison");
    expect(crossCardUi).toContain("Current AAPL price unavailable");
    expect(crossCardUi).not.toContain("APPLE-1 · AAPL</span><span class=\"hermes-portfolio-meta\">5/29/24</span></td><td class=\"hermes-portfolio-shares\">146</td><td class=\"hermes-portfolio-purchase\">$191.00</td><td>$242.71</td>");
    expect(crossCardUi).toContain("AMZN — Amazon $242.71");

    const tableRowsHtml =
      "<table><tr><td>AAPL — price unavailable</td></tr><tr><td>AMZN</td><td>Amazon</td><td>$242.71</td></tr></table>";
    const tableRowsCsv = stockPortfolioCsv(tableRowsHtml, "2026-07-06").split("\r\n");
    expect(tableRowsCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,,,27886.00,,,",
    );
    expect(tableRowsCsv).toContain(
      "2026-07-06,AMAZON-1,AMZN,5/29/24,138,181.00,242.71,61.71,24978.00,33493.98,8515.98,34.09",
    );

    const alternateHeadingCsv = stockPortfolioCsv(
      "<h2>Amazon (AMZN) | $242.71</h2><section class=\"card\">SNAP — Snap $4.75</section>",
      "2026-07-06",
    ).split("\r\n");
    expect(alternateHeadingCsv).toContain(
      "2026-07-06,AMAZON-1,AMZN,5/29/24,138,181.00,242.71,61.71,24978.00,33493.98,8515.98,34.09",
    );
    expect(alternateHeadingCsv).toContain(
      "2026-07-06,SNAP,SNAP,2/3/26,1786,6.18,4.75,-1.43,11037.48,8483.50,-2553.98,-23.14",
    );

    const unrelatedDollarHtml =
      "<article><h2>AAPL — Apple</h2><p>Price unavailable. Market cap rose by $12.5 billion.</p></article><h2>AMZN — Amazon $242.71</h2>";
    const unrelatedDollarCsv = stockPortfolioCsv(unrelatedDollarHtml, "2026-07-06").split("\r\n");
    expect(unrelatedDollarCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,,,27886.00,,,",
    );
    expect(unrelatedDollarCsv).toContain(
      "2026-07-06,AMAZON-1,AMZN,5/29/24,138,181.00,242.71,61.71,24978.00,33493.98,8515.98,34.09",
    );

    const unavailableHeadingCsv = stockPortfolioCsv(
      "<h2>AAPL — Apple price unavailable; market cap $12.5 billion</h2>",
      "2026-07-06",
    ).split("\r\n");
    expect(unavailableHeadingCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,,,27886.00,,,",
    );

    const companyProseCsv = stockPortfolioCsv(
      "<h2>AAPL — Supplier SNAP — social platform note $312.59</h2>",
      "2026-07-06",
    ).split("\r\n");
    expect(companyProseCsv).toContain(
      "2026-07-06,APPLE-1,AAPL,5/29/24,146,191.00,312.59,121.59,27886.00,45638.14,17752.14,63.66",
    );
    expect(companyProseCsv).toContain(
      "2026-07-06,SNAP,SNAP,2/3/26,1786,6.18,,,11037.48,,,",
    );

    const datedCsv = { date: "2026-07-06", content: csv };
    expect(matchingStockPortfolioCsv(datedCsv, "2026-07-06")).toBe(datedCsv);
    expect(matchingStockPortfolioCsv(datedCsv, "2026-07-14")).toBeNull();
  });

  it("normalizes the July 17 article-and-portfolio producer contract without purchase-price fallback or light-mode drift", () => {
    const stockHtml = `<!doctype html><html><head><style>
      :root{color-scheme:light;--ink:#172033;--muted:#647084;--line:#dce2ea;--panel:#fff;--bg:#f4f6f9}
      body{margin:0;background:var(--bg);color:var(--ink)}
      main{width:min(1120px,calc(100% - 32px));margin:auto}
    </style></head><body><main>
      <header><h1>Stock Brief</h1><div class="context"><strong>Friday, July 17, 2026</strong> · End of U.S. regular session · Generated 7:55:11 PM PDT</div><p>Primary quotes: Yahoo Finance chart metadata; regular-market close and prior close used for daily movement.</p></header>
      <section class="stock-list" aria-label="Tracked stocks">
        <article class="stock-row up" data-ticker="AAPL"><div class="identity"><h2>AAPL — Apple Inc.</h2><div class="price">$333.74</div></div><div class="movement">▲ +$0.48 (+0.14%)</div><dl class="metrics"><div><dt>Day high</dt><dd>$334.98</dd></div><div><dt>Day low</dt><dd>$329.00</dd></div><div><dt>52-week high</dt><dd>$334.99</dd></div><div><dt>52-week low</dt><dd>$201.50</dd></div><div><dt>Volume</dt><dd>63,325,386</dd></div></dl></article>
      </section>
      <section class="portfolio"><h2>Portfolio Position Comparison</h2><table><tbody><tr><td>APPLE-1 · AAPL (5/29/24)</td><td>146</td><td>$191.00</td><td>$333.74</td></tr></tbody></table></section>
    </main></body></html>`;

    const result = prepareBriefPreviewHtml(stockHtml, "stock", 1784346911);
    const csv = stockPortfolioCsv(stockHtml, "2026-07-17");

    expect(result).toContain('aria-label="Stock brief date: July 17, 2026"');
    expect(result).toContain('body > main { width: 100% !important; max-width: none !important; margin: 0 !important; padding: 28px !important; }');
    expect(result.match(/Yahoo Finance snapshot generated at end-of-day after U\.S\. close · \$USD/g)).toHaveLength(1);
    expect(result).not.toContain("Friday, July 17, 2026");
    expect(result).not.toContain("Generated 7:55:11 PM PDT");
    expect(result).not.toContain("Primary quotes: Yahoo Finance chart metadata");
    expect(result).toContain('<span class="hermes-stock-ticker">AAPL</span>');
    expect(result).toContain('<strong class="hermes-stock-price hermes-portfolio-positive">$333.74</strong>');
    expect(result).toContain('APPLE-1 · AAPL</span><span class="hermes-portfolio-meta">5/29/24</span></td><td class="hermes-portfolio-shares">146</td><td class="hermes-portfolio-purchase">$191.00</td><td>$333.74</td>');
    expect(result).not.toContain('<section class="portfolio">');
    expect(result).toContain(':root { color-scheme: dark !important;');
    expect(result).toContain('html, body { width: 100% !important; max-width: none !important; min-height: 100% !important; margin: 0 !important; background: #0b1020 !important; color: #eef3ff !important; }');
    expect(csv).toContain('2026-07-17,APPLE-1,AAPL,5/29/24,146,191.00,333.74,142.74,27886.00,48726.04,20840.04,74.73');
  });

  it("normalizes actual section-card stock archives into one horizontal quote row per ticker", () => {
    const stockHtml = `<!doctype html><html><body><main class="grid">
      <section class="card" id="AAPL"><div class="top"><div><div class="ticker">AAPL</div><div class="company">Apple Inc.</div></div><div><div class="price">$327.50</div><div class="change up">+$12.64</div></div></div><dl><div><dt>Day High</dt><dd>$328.72</dd></div><div><dt>Day Low</dt><dd>$317.32</dd></div><div><dt>52-week High</dt><dd>$328.72</dd></div><div><dt>52-week Low</dt><dd>$201.50</dd></div><div><dt>Volume</dt><dd>60,780,931</dd></div></dl><div class="sources"><a href="https://example.test">Yahoo source</a></div></section>
    </main></body></html>`;
    const result = prepareBriefPreviewHtml(stockHtml, "stock");

    expect(result).toContain('<section class="hermes-stock-row" data-ticker="AAPL">');
    expect(result).toContain('<span class="hermes-stock-ticker">AAPL</span>');
    expect(result).toContain('<div class="hermes-stock-title"><span class="hermes-stock-ticker">AAPL</span><span class="hermes-stock-company">APPLE INC.</span></div>');
    expect(result).toContain(".hermes-stock-title { display: flex !important; min-width: 0 !important; flex-direction: column !important;");
    expect(result).toContain(".hermes-stock-ticker { color: #ffe08a !important;");
    expect(result).toContain(".hermes-stock-price { display: block !important; margin-top: 8px !important; color: #ffe08a !important;");
    expect(result).toContain('<span class="hermes-stock-change hermes-portfolio-positive">+$12.64</span>');
    expect(result).toContain('<strong class="hermes-stock-price hermes-portfolio-positive">$327.50</strong>');
    expect(result).toContain('<dt>Day High</dt><dd>$328.72</dd>');
    expect(result).toContain('.hermes-stock-row { grid-column: 1 / -1 !important;');
    expect(result).not.toContain("Yahoo source");
    expect(result).not.toContain('id="hermes-brief-player-controller"');

    const normalizedCompanyNames = prepareBriefPreviewHtml(
      '<main class="grid"><article class="stock-row"><h2>DIS — The Walt Disney Company</h2><div class="price">$99.71</div></article><article class="stock-row"><h2>AMZN — Amazon.com, Inc.</h2><div class="price">$249.89</div></article></main>',
      "stock",
    );
    expect(normalizedCompanyNames).toContain('<span class="hermes-stock-company">THE WALT DISNEY CO.</span>');
    expect(normalizedCompanyNames).toContain('<span class="hermes-stock-company">AMAZON.COM, INC.</span>');
  });

  it("normalizes July 14 stock-card archives with linked tickers and span/b metrics", () => {
    const stockHtml = `<!doctype html><html><body><header><h1>Stock Brief — 2026-07-14</h1></header><main class="grid">
      <article class="stock-card" data-symbol="AAPL"><div class="card-head"><div><a class="ticker" href="https://finance.yahoo.com/quote/AAPL">AAPL</a><div class="name">Apple Inc.</div></div><div class="price">$314.86</div></div><div class="change down">-2.45 / -0.77%</div><div class="metrics"><div><span>Day High</span><b>$316.19</b></div><div><span>Day Low</span><b>$311.91</b></div><div><span>52w High</span><b>$323.45</b></div><div><span>52w Low</span><b>$201.50</b></div><div><span>Volume</span><b>36.33M</b></div><div><span>Source</span><b>Yahoo Finance</b></div></div></article>
    </main></body></html>`;
    const result = prepareBriefPreviewHtml(stockHtml, "stock");

    expect(result).toContain('<section class="hermes-stock-row" data-ticker="AAPL">');
    expect(result).toContain('<span class="hermes-stock-company">APPLE INC.</span>');
    expect(result).toContain('<span class="hermes-stock-change hermes-portfolio-negative">▼ -$2.45 (-0.77%)</span>');
    expect(result).toContain('<dt>Day High</dt><dd>$316.19</dd>');
    expect(result).toContain('<dt>52-week High</dt><dd>$323.45</dd>');
    expect(result).toContain('<dt>Volume</dt><dd>36.33M</dd>');
    expect(result.match(/<div><dt>/g)).toHaveLength(5);
    expect(result).not.toContain("Yahoo Finance</b>");
  });

  it("normalizes July 5 and 6 card archives with text/strong stats", () => {
    const stockHtml = `<!doctype html><html><body><main class="wrap"><header><h1>Stock Brief — 2026-07-06</h1></header><section class="cards" aria-label="Stock price cards">
      <article class="card"><h2>AAPL — Apple <span class="price">$312.59</span></h2><p class="change up">▲ +3.96 (+1.28%)</p><div class="stats"><div class="stat">Day High<strong>$312.75</strong></div><div class="stat">Day Low<strong>$307.01</strong></div><div class="stat">52w High<strong>$323.45</strong></div><div class="stat">52w Low<strong>$201.50</strong></div><div class="stat">Volume<strong>13.47M</strong></div></div></article>
    </section></main></body></html>`;
    const result = prepareBriefPreviewHtml(stockHtml, "stock");

    expect(result).toContain('<section class="hermes-stock-row" data-ticker="AAPL">');
    expect(result).toContain('<dt>Day High</dt><dd>$312.75</dd>');
    expect(result).toContain('<dt>52-week High</dt><dd>$323.45</dd>');
    expect(result).toContain('<dt>Volume</dt><dd>13.47M</dd>');
    expect(result.match(/<div><dt>/g)).toHaveLength(5);
  });

  it("repeats the active cron date in a yellow pill on every daily-price row", () => {
    const stockHtml = `<!doctype html><html><body><header><h1>Stock Brief — 2026-07-16</h1><p class="date">Los Angeles date: 2026-07-16</p></header><main class="grid">
      <article class="stock-row"><h2>DIS — The Walt Disney Company</h2><div class="price">$99.71</div></article>
      <article class="stock-row"><h2>AAPL — Apple Inc.</h2><div class="price">$333.26</div></article>
    </main></body></html>`;
    const result = prepareBriefPreviewHtml(stockHtml, "stock");

    expect(result.match(/class="hermes-stock-row-date"/g)).toHaveLength(2);
    expect(result.match(/class="hermes-stock-row-date"[^>]*>July 16, 2026<\/span>/g)).toHaveLength(2);
    expect(result).toContain('aria-label="Daily prices date: July 16, 2026"');
    expect(result).toContain("grid-template-columns: minmax(520px, 1.05fr) minmax(190px, .42fr) minmax(0, 1.75fr) !important");
    expect(result).toContain(".hermes-stock-row-date { grid-column: 2 !important;");
  });

  it("groups daily movement under the ticker and expands five timestamp-free metrics across the row", () => {
    const stockHtml = `<!doctype html><html><body><main class="grid">
      <article class="stock-row up" id="MSFT" data-ticker="MSFT"><div class="identity"><h2>MSFT — Microsoft Corporation</h2><div class="price">$401.10</div></div><div class="movement"><span>▲ +$5.47 (+1.38%)</span></div><dl class="metrics"><div><dt>Day High</dt><dd>$405.99</dd></div><div><dt>Day Low</dt><dd>$392.05</dd></div><div><dt>52-week High</dt><dd>$555.45</dd></div><div><dt>52-week Low</dt><dd>$349.20</dd></div><div><dt>Volume</dt><dd>34,338,326</dd></div></dl><div class="asof">As of 2026-07-16 1:00:00 PM PDT</div></article>
      <p class="archive-timestamp">As of 2026-07-16 1:00:00 PM PDT</p>
    </main></body></html>`;
    const result = prepareBriefPreviewHtml(stockHtml, "stock");

    expect(result).toContain('<div class="hermes-stock-identity"><div class="hermes-stock-title"><span class="hermes-stock-ticker">MSFT</span><span class="hermes-stock-company">MICROSOFT CORP.</span></div><span class="hermes-stock-change hermes-portfolio-positive">▲ +$5.47 (+1.38%)</span><strong class="hermes-stock-price hermes-portfolio-positive">$401.10</strong></div>');
    expect(result.match(/<div><dt>/g)).toHaveLength(5);
    expect(result).toContain("<dt>Day High</dt><dd>$405.99</dd>");
    expect(result).toContain("<dt>Volume</dt><dd>34,338,326</dd>");
    expect(result).not.toMatch(/As of\s+2026-07-16/i);
    expect(result).not.toContain('class="movement"');
    expect(result).not.toContain('class="metrics"');
    expect(result).toContain("grid-template-columns: minmax(520px, 1.05fr) minmax(190px, .42fr) minmax(0, 1.75fr) !important");
    expect(result).toContain("grid-template-columns: repeat(5, minmax(132px, 1fr)) !important");
    expect(result).toContain(".hermes-stock-metrics dt { color: var(--muted, #aab8ca) !important; font-size: 1.15rem !important;");
    expect(result).toContain(".hermes-stock-metrics dd { margin: 7px 0 0 !important; color: var(--text, #f4f7fb) !important; font-size: 1.9rem !important;");
    expect(result).toContain(".hermes-stock-title-row { display: flex !important; align-items: center !important;");
  });

  it("uses cyan archive metadata and a weighted Founder Takeaways keypoint hierarchy", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><header><div class="date">Wednesday, July 15, 2026</div><div class="sub">America/Los_Angeles date: 2026-07-15 · USD</div></header><main><div class="takeaways"><h2>Founder takeaways</h2><ol><li><strong>1. Agentic coding is now a price/performance war, not a novelty.</strong> Supporting detail.</li></ol></div></main></body></html>',
      "ai",
    );

    expect(result).toContain("header .date, header .sub { color: #67e8f9 !important; }");
    expect(result).toContain(".hermes-playable-card.takeaways h2 { color: #67e8f9 !important; text-transform: uppercase !important;");
    expect(result).toContain(".hermes-playable-card.takeaways li { font-size: 1.2em !important;");
    expect(result).toContain(".hermes-playable-card.takeaways li > strong:first-child { display: block !important; color: #67e8f9 !important; font-size: 1.35em !important;");
    expect(result).toContain(".hermes-playable-card.takeaways li::marker { color: #67e8f9 !important;");
    expect(result).toContain(".hermes-takeaways-heading-row .hermes-ai-active-date-pill { transform: translateY(-5px) !important;");
    expect(result).toContain(".hermes-ai-sources-row .hermes-ai-active-date-pill { transform: none !important;");
  });

  it("exports a self-contained full-page dashboard clone with archive context and player", () => {
    const result = briefDashboardHtml(
      '<html><head><title>AI Morning Brief</title></head><body><header><span class="pill">AI Morning Brief</span><h1>AI Morning Brief — 2026-07-16</h1><p class="date">July 16, 2026 · America/Los_Angeles</p></header><main><div class="takeaways"><h2>Founder takeaways</h2></div><section><h2>Topic one</h2></section></main></body></html>',
      "ai",
      "2026-07-16",
      ["2026-07-16", "2026-07-15"],
      1_784_236_080,
    );
    expect(result).toContain('id="hermes-brief-export-shell"');
    expect(result).toContain("BRIEFS-AI");
    expect(result).toContain('aria-current="date">2026-07-16');
    expect(result).toContain(">2026-07-15<");
    expect(result).toContain('id="hermes-brief-player-controller"');
    expect(result.match(/id="hermes-brief-player-controller"/g)).toHaveLength(1);
    expect(result).toContain('class="hermes-ai-title-row"');
    expect(result).toContain('id="hermes-ai-fullscreen-button"');
    expect(result).toContain('type: "hermes-ai-fullscreen-toggle"');
    expect(result).toContain('event.data?.type === "hermes-ai-fullscreen-state"');
    expect(result).toContain('if (event.key === "Enter")');
    expect(result).toContain("event.stopImmediatePropagation()");
    expect(result).not.toContain("fullscreenExcludedTarget");
    expect(result).toContain("script-src 'unsafe-inline'");
    expect(result).toContain('<header data-hermes-date-normalized="true"><span class="pill">July 16, 2026</span><div class="hermes-ai-title-row">');
    expect(result).toContain('<p class="date">2:08pm - America/Los_Angeles</p>');
    expect(result).toContain("margin: 0 0 18px 22px !important");
    expect(result).toContain("border: 1px solid #67e8f9 !important");
    expect(result).not.toContain('class="hermes-player-volume">Volume ');
    expect(result).not.toContain('id="tts-status"');
    expect(result).toContain("HERMES_BRIEFS_EXPORT_MANIFEST");
    expect(result).toContain('"accepted_ui":"v61-date-load-keyboard-focus"');
    expect(result).toContain('"html_self_contained":true');
    expect(result).toContain('href="BRIEFS-AI - 2026-07-15.html"');
    expect(result).toContain('id="hermes-brief-export-navigation-controller"');
    expect(result).toContain('frame.id = "hermes-ai-stable-date-frame"');
    expect(result).toContain("hermes-ai-date-frame-active");
    expect(result).toContain('type: "hermes-ai-export-date-load"');
    expect(result).toContain('type: "hermes-ai-stop-audio"');
    expect(result).toContain("function stopActiveAudio()");
    expect(result).toContain("stopSpeech({ clearHighlight: true })");
    expect(result).toContain("stopActiveAudio();\n    pendingPosition = viewportPosition;");
    expect(result).toContain('type: "hermes-ai-viewport-restore"');
    expect(result).toContain("topicIndex: activeCardIndex");
    expect(result).toContain("if (activeCardIndex === -1) playFounderTakeaways();\n    else speakCurrent();");
    expect(result).toContain("if (event.code === \"Space\" || event.key === \" \" || event.key === \"Spacebar\") return \"toggle\"");
    expect(result).toContain("const activeCardByDate = new Map()");
    expect(result).toContain("activeCardByDate.set(currentDate, viewportPosition.topicIndex)");
    expect(result).toContain("activeCardByDate.get(destinationDate)");
    expect(result).toContain("function restoreActiveCard(topicIndex)");
    expect(result).toContain('target.scrollIntoView({ behavior: "auto", block: "start" })');
    expect(result).toContain("let framesRemaining = 8");
    expect(result).toContain("function focusActiveFrame()");
    expect(result).toContain("target.focus({ preventScroll: true })");
    expect(result).toContain("target.contentWindow?.focus()");
    expect(result).toContain("window.requestAnimationFrame(focusActiveFrame)");
    expect(result).toContain('event.data?.type === "hermes-ai-fullscreen-toggle"');
    expect(result).toContain("await document.documentElement.requestFullscreen()");
    expect(result).toContain("target.src = file");
    expect(result).toContain("frame-src 'self' file:");
    expect(result).not.toContain("window.location.href = destination");
    expect(result).not.toContain("HERMES_BRIEFS_RESTORE_MANIFEST");
    expect(result).not.toContain("v41-restore-safe-exports");
  });

  it("exports a semantic Markdown snapshot from the same transformed archive", () => {
    const previousDomParser = globalThis.DOMParser;
    globalThis.DOMParser = new JSDOM("").window.DOMParser as typeof DOMParser;
    try {
      const markdown = briefDashboardMarkdown(
        '<html><body><header><h1>AI Morning Brief — 2026-07-15</h1></header><main><div class="takeaways"><h2>Founder takeaways</h2><ol><li><strong>1. Keypoint headline</strong> Supporting detail.</li></ol></div><section class="card"><h2>Topic one</h2><p>Topic detail.</p></section></main></body></html>',
        "ai",
      );
      expect(markdown).toContain("# AI Morning Brief");
      expect(markdown).not.toContain("# AI Morning Brief — 2026-07-15");
      expect(markdown).toContain("## FOUNDER TAKEAWAYS");
      expect(markdown).toContain("### 1. Keypoint headline");
      expect(markdown).toContain("Supporting detail.");
      expect(markdown).toContain("## Topic one");
      expect(markdown).toContain("Topic detail.");
    } finally {
      globalThis.DOMParser = previousDomParser;
    }
  });

  it("exports complete V69 Stock semantics to Markdown", () => {
    const previousDomParser = globalThis.DOMParser;
    globalThis.DOMParser = new JSDOM("").window.DOMParser as typeof DOMParser;
    try {
      const markdown = briefDashboardMarkdown(
        `<!doctype html><html><body><header><h1>Stock Brief — 2026-07-16</h1><p class="date">Los Angeles date: 2026-07-16</p></header><main class="grid">
          <article class="stock-row"><h2>AAPL — Apple Inc.</h2><div class="price">$333.26</div><div class="movement">▲ +$5.76 (+1.76%)</div><dl><div><dt>Day High</dt><dd>$334.68</dd></div><div><dt>Day Low</dt><dd>$326.79</dd></div><div><dt>52-week High</dt><dd>$334.68</dd></div><div><dt>52-week Low</dt><dd>$201.50</dd></div><div><dt>Volume</dt><dd>62,673,782</dd></div></dl></article>
        </main></body></html>`,
        "stock",
      );
      expect(markdown).toContain("**Brief Date:** July 16, 2026");
      expect(markdown).toContain("**SUMMARY:** +$24,603.78");
      expect(markdown).toContain("## Portfolio Position Comparison");
      expect(markdown).toContain("| Position | Shares | Purchased price | Current price | +/- | Cost basis | Current value | Gain / loss | Return |");
      expect(markdown).toContain("## AAPL\n### APPLE INC.");
      expect(markdown).toContain("Date · July 16, 2026");
      expect(markdown).toContain("Performance · ▲ +$5.76 (+1.76%)");
      expect(markdown).toContain("Price · $333.26");
      expect(markdown).toContain("Day High · $334.68 · Day Low · $326.79 · 52-week High · $334.68 · 52-week Low · $201.50 · Volume · 62,673,782");
      expect(markdown).toContain('\"accepted_ui\":\"v74-ticker-above-company\"');
    } finally {
      globalThis.DOMParser = previousDomParser;
    }
  });

  it("exports one Founder section and exactly seven non-collapsed AI topics with a restore manifest", () => {
    const previousDomParser = globalThis.DOMParser;
    globalThis.DOMParser = new JSDOM("").window.DOMParser as typeof DOMParser;
    try {
      const topics = Array.from({ length: 7 }, (_, index) =>
        `<article class="card"><h2>${index + 1}) Topic ${index + 1}</h2><p>Summary ${index + 1}.</p><p>Action ${index + 1}.</p></article>`,
      ).join("");
      const markdown = briefDashboardMarkdown(
        `<html><body><header><h1>AI Morning Brief</h1></header><main><section class="takeaways"><h2>FOUNDER TAKEAWAYS</h2><ol><li><strong>Founder item</strong><span>Founder detail.</span></li></ol></section><section class="topics">${topics}</section></main></body></html>`,
        "ai",
      );
      expect(markdown.match(/^## FOUNDER TAKEAWAYS$/gm)).toHaveLength(1);
      expect(markdown.match(/^## \d+[.)] Topic \d+$/gm)).toHaveLength(7);
      expect(markdown.match(/^## 1[.)] Topic 1$/gm)).toHaveLength(1);
      expect(markdown).not.toContain("Topic 1 Summary 1. Action 1. 2) Topic 2");
      expect(markdown).toContain("HERMES_BRIEFS_EXPORT_MANIFEST");
      expect(markdown).toContain('"accepted_ui":"v61-date-load-keyboard-focus"');
      expect(markdown).toContain('"html_self_contained":false');
      expect(markdown).toContain('"companion_html_pattern":"BRIEFS-AI - YYYY-MM-DD.html"');
      expect(markdown).not.toContain("HERMES_BRIEFS_RESTORE_MANIFEST");
      expect(markdown).not.toContain("v41-restore-safe-exports");
    } finally {
      globalThis.DOMParser = previousDomParser;
    }
  });

  it("exports Stock with the shared date pill, undated title, dynamic time, archive-date links, and no player", () => {
    const result = briefDashboardHtml(
      '<html><head><title>Stock Brief</title></head><body><header><h1>Stock Brief — 2026-07-15</h1><p class="sub">America/Los_Angeles date: 2026-07-15 · Live web quote snapshot · USD</p></header><main><section class="card"><h2>AAPL — Apple</h2><p>$210.00</p></section></main></body></html>',
      "stock",
      "2026-07-15",
      ["2026-07-15", "2026-07-14"],
      1_784_236_080,
    );

    expect(result).toContain('<span id="hermes-stock-date-pill" data-hermes-stock-date-pill="true" role="status" aria-label="Stock brief date: July 15, 2026"');
    expect(result).toContain('style="display:inline-block !important;visibility:visible !important;position:static !important;');
    expect(result).toContain("html body .hero .pill, html body header .pill { display: inline-block !important; visibility: visible !important; position: static !important;");
    expect(result).toContain("opacity: 1 !important; clip: auto !important; clip-path: none !important; transform: none !important; overflow: visible !important;");
    expect(result).toContain("<h1>Stock Brief</h1>");
    expect(result).not.toContain("<h1>Stock Brief — 2026-07-15</h1>");
    expect(result).toContain('<p class="date">2:08pm - America/Los_Angeles</p>');
    expect(result).toContain('href="BRIEFS-STOCKS - 2026-07-14.html"');
    expect(result).toContain('const VIEWPORT_HASH_PREFIX = "#hermes-stock-viewport="');
    expect(result).toContain("position: captureViewportPosition()");
    expect(result).toContain("window.scrollTo(targetX, targetY)");
    expect(result).toContain('document.querySelectorAll("#hermes-brief-export-shell a[href]")');
    expect(result).toContain("navigate(event.data.direction, event.data.position)");
    expect(result).toContain("background: linear-gradient(135deg, #10182f, #0b1020)");
    expect(result).toContain('[aria-current="date"] { border-color: #ffd166; background: #ffd166; color: #0b1020;');
    expect(result).toContain('"accepted_ui":"v74-ticker-above-company"');
    expect(result).not.toContain('id="hermes-stock-date-nav-controller"');
    expect(result).not.toContain('id="hermes-brief-player-controller"');
    expect(result).not.toContain('id="hermes-brief-player"');
  });

  it("renders the yellow date pill from the exact live July 16 header shape", () => {
    const result = prepareBriefPreviewHtml(
      `<!doctype html><html><head><title>Stock Brief</title></head><body><header>
        <div>
          <h1>Stock Brief</h1>
          <p>Gain/Loss</p>
          <div class="sub">Los Angeles date: 2026-07-16 · Generated at 2026-07-16T19:11:31-07:00 · End-of-day regular-market snapshot after the U.S. close · USD</div>
        </div>
      </header><main aria-label="Tracked stock quote rows"><section class="card"><h2>AAPL — Apple Inc.</h2><strong class="price">$333.26</strong></section></main></body></html>`,
      "stock",
      1_784_293_891,
    );
    const dom = new JSDOM(result);
    const pill = dom.window.document.querySelector<HTMLElement>("#hermes-stock-date-pill");

    expect(pill?.textContent).toBe("July 16, 2026");
    expect(pill?.getAttribute("aria-label")).toBe("Stock brief date: July 16, 2026");
    expect(pill?.style.getPropertyValue("display")).toBe("inline-block");
    expect(pill?.style.getPropertyPriority("display")).toBe("important");
    expect(pill?.style.getPropertyValue("visibility")).toBe("visible");
    expect(pill?.style.getPropertyPriority("visibility")).toBe("important");
    expect(pill?.style.getPropertyValue("background")).toBe("rgb(255, 209, 102)");
    expect(pill?.style.getPropertyPriority("background")).toBe("important");
    expect(result).toContain('<p class="date">6:11am - America/Los_Angeles</p>');
    expect(result).toContain("Yahoo Finance snapshot generated at end-of-day after U.S. close · $USD");
    expect(result).not.toContain("Snapshot generated end-of-day after U.S. close · $USD");
    expect(result).not.toContain("Los Angeles date: 2026-07-16");
    expect(result).not.toContain("Generated at 2026-07-16T19:11:31-07:00");
    expect(result).toContain("<h1>Stock Brief</h1>");
    expect(result).toContain("Portfolio Position Comparison");
    expect(result.match(/id="hermes-portfolio-comparison"/g)).toHaveLength(1);
    expect(result).not.toContain('id="hermes-brief-player"');
  });

  it("adds one Stock header summary from the portfolio total without changing CSV bytes", () => {
    const stockHtml = `<!doctype html><html><head><title>Stock Brief</title></head><body><header>
      <h1>Stock Brief — 2026-07-16</h1><p class="date">Los Angeles date: 2026-07-16</p>
    </header><main aria-label="Tracked stock quote rows">
      <article class="stock-row"><h2>AAPL — Apple Inc.</h2><div class="price">$333.26</div></article>
      <article class="stock-row"><h2>AMZN — Amazon.com Inc.</h2><div class="price">$242.71</div></article>
      <article class="stock-row"><h2>NVDA — NVIDIA Corp.</h2><div class="price">$191.55</div></article>
      <article class="stock-row"><h2>SNAP — Snap Inc.</h2><div class="price">$4.75</div></article>
      <article class="stock-row"><h2>GOOGL — Alphabet Inc.</h2><div class="price">$195.40</div></article>
      <article class="stock-row"><h2>MSFT — Microsoft Corp.</h2><div class="price">$512.31</div></article>
      <article class="stock-row"><h2>DIS — Walt Disney Co.</h2><div class="price">$121.44</div></article>
    </main></body></html>`;
    const csvBefore = stockPortfolioCsv(stockHtml, "2026-07-16");
    const result = prepareBriefPreviewHtml(stockHtml, "stock", 1_784_293_891);
    const dom = new JSDOM(result);
    const summary = dom.window.document.querySelector("#hermes-stock-portfolio-summary");
    const comparisonTotal = dom.window.document.querySelector("#hermes-portfolio-comparison tfoot td:nth-last-child(2)");

    expect(summary).not.toBeNull();
    expect(summary?.querySelector(".hermes-stock-summary-label")?.textContent).toBe("SUMMARY");
    expect(summary?.querySelector(".hermes-stock-summary-value")?.textContent).toBe(comparisonTotal?.textContent);
    expect(result.match(/id="hermes-stock-portfolio-summary"/g)).toHaveLength(1);
    expect(stockPortfolioCsv(stockHtml, "2026-07-16")).toBe(csvBefore);
  });

  it("repairs historical Stock headers that have a fullscreen button but no canonical title wrapper", () => {
    const quoteRows = [
      ["AAPL", "$333.26"], ["AMZN", "$242.71"], ["NVDA", "$191.55"], ["SNAP", "$4.75"],
      ["GOOGL", "$195.40"], ["MSFT", "$512.31"], ["DIS", "$121.44"],
    ].map(([ticker, price]) => `<article class="stock-row"><h2>${ticker} — Company</h2><div class="price">${price}</div></article>`).join("");
    const historical = `<!doctype html><html><body><header><h1>Stock Brief — 2026-07-16</h1><button id="hermes-stock-fullscreen-button" type="button">old fullscreen</button><p class="date">Los Angeles date: 2026-07-16</p></header><main aria-label="Tracked stock quote rows">${quoteRows}</main></body></html>`;
    const result = prepareBriefPreviewHtml(historical, "stock", 1_784_293_891);
    const dom = new JSDOM(result);
    const titleRow = dom.window.document.querySelector(".hermes-stock-title-row");

    expect(titleRow).not.toBeNull();
    expect(titleRow?.querySelectorAll("#hermes-stock-fullscreen-button")).toHaveLength(1);
    expect(dom.window.document.querySelector("#hermes-stock-portfolio-summary .hermes-stock-summary-label")?.textContent).toBe("SUMMARY");
  });

  it("injects a dashboard-owned player for card-only AI archives", () => {
    const result = prepareBriefPreviewHtml(
      "<!doctype html><html><body><section><h2>Founder takeaways</h2><p>Summary</p></section><section><h2>First topic</h2><p>Detail</p></section></body></html>",
      "ai",
    );

    expect(result).toContain('player.id = "hermes-brief-player"');
    expect(result).toContain('id="tts-volume"');
    expect(result).toContain("ensureHermesPlayer");
    expect(result).toContain("main article, main section, article, section");
  });

  it("starts ArrowUp playback at founder takeaways, keeps topic headlines yellow, and removes tactical agendas", () => {
    const result = prepareBriefPreviewHtml(
      `<!doctype html><html><body><main><div class="takeaways"><h2>Founder takeaways</h2><ol><li>Start here.</li></ol></div><section><h2>First topic</h2><p>Detail</p></section><section class="agenda"><h2>Today’s tactical agenda</h2><p>Remove this.</p></section></main></body></html>`,
      "ai",
    );

    expect(result).toContain('founderTakeaways = document.querySelector(".takeaways")');
    expect(result).toContain('if (card.classList.contains("takeaways")) return takeawaySpeechText(card);');
    expect(result).toContain('playFounderTakeaways()');
    expect(result).toContain('.hermes-playable-card h2, .hermes-playable-card h3 { color: var(--hot, #ffd166) !important; }');
    expect(result).not.toContain("Today’s tactical agenda");
    expect(result).not.toContain("Remove this.");
  });

  it("counts all seven numbered sibling topics instead of counting their shared section as one card", () => {
    const topics = Array.from({ length: 7 }, (_, index) =>
      `<h3>${index + 1}) Topic ${index + 1}</h3><p>Detail ${index + 1}</p>`,
    ).join("");
    const result = prepareBriefPreviewHtml(
      `<!doctype html><html><body><main><div class="takeaways"><h2>Founder takeaways</h2></div><section><h2>What changed</h2>${topics}</section></main></body></html>`,
      "ai",
    );

    expect(result).toContain('function isNumberedTopicHeading(element)');
    expect(result).toContain('function wrapSiblingTopic(heading)');
    expect(result).toContain('document.querySelectorAll("main h2, main h3, body > h2, body > h3")');
    expect(result).toContain('statusElement.textContent = "Topic " + (index + 1) + " of " + cards.length + state');
  });

  it("does not add portfolio comparisons to AI briefs", () => {
    const result = prepareBriefPreviewHtml(
      "<!doctype html><html><body><h2>AAPL — Apple $312.59</h2></body></html>",
      "ai",
    );

    expect(result).not.toContain('id="hermes-portfolio-comparison"');
  });

  it("recognizes only the requested global player shortcuts", () => {
    expect(isBriefPlayerShortcut(" ")).toBe(true);
    expect(isBriefPlayerShortcut("Spacebar")).toBe(true);
    expect(isBriefPlayerShortcut("ArrowLeft")).toBe(true);
    expect(isBriefPlayerShortcut("ArrowRight")).toBe(true);
    expect(isBriefPlayerShortcut("ArrowUp")).toBe(true);
    expect(isBriefPlayerShortcut("ArrowDown")).toBe(false);
    expect(isBriefPlayerShortcut("Enter")).toBe(false);
  });

  it("starts first previous or next navigation on topic one before advancing", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><article class="card"><h2>1) One</h2></article><article class="card"><h2>2) Two</h2></article></main></body></html>',
      "ai",
    );

    expect(result).toContain("let navigationStarted = false");
    expect(result).toContain("navigationStarted = true");
    expect(result).toContain('if (!navigationStarted) selectAndPlay(index);\n      else selectAndPlay(index - 1);');
    expect(result).toContain('if (!navigationStarted) selectAndPlay(index);\n      else selectAndPlay(index + 1);');
  });

  it("captures reserved player shortcuts from initially focused buttons but not text editors", () => {
    const dom = new JSDOM('<button id="selected-date">2026-07-16</button><a id="download">HTML</a><input id="filter"><textarea id="notes"></textarea><div id="editor" contenteditable="true"></div>');
    const document = dom.window.document;

    expect(isBriefPlayerTextEditingTarget(document.getElementById("selected-date"))).toBe(false);
    expect(isBriefPlayerTextEditingTarget(document.getElementById("download"))).toBe(false);
    expect(isBriefPlayerTextEditingTarget(document.getElementById("filter"))).toBe(true);
    expect(isBriefPlayerTextEditingTarget(document.getElementById("notes"))).toBe(true);
    expect(isBriefPlayerTextEditingTarget(document.getElementById("editor"))).toBe(true);
  });

  it("gives every active playable topic an explicit visual highlight", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><div class="takeaways"><h2>Founder takeaways</h2></div><section><h2>Topic 1</h2></section><section><h2>Topic 5</h2></section></main></body></html>',
      "ai",
    );
    expect(result).toContain(".hermes-playable-card.active");
    expect(result).toContain('card.classList.toggle("active", active)');
  });

  it("uses a compact Apple-like AI hierarchy without labels or header summary", () => {
    const result = prepareBriefPreviewHtml(`<!doctype html><html><head><style>
      body { font: 16px/1.55 system-ui; max-width: 1000px; background: #f5f7fb; color: #182033; }
      header, .takeaways, .card { background: white; }
    </style></head><body>
      <header class="hero"><span class="pill">AI Morning Brief</span><div class="tag">Legacy label</div><h1>AI Morning Brief — 2026-07-16</h1><p class="date">July 16, 2026 · America/Los_Angeles</p><p class="meta">For founders and operators · Regulation, implementation, model economics, open weights, infrastructure, monetization, and safety.</p></header>
      <section class="takeaways"><h2>Founder takeaways</h2><ol><li>Readable title.</li></ol></section>
      <section class="topics"><article class="card"><h2>1) Topic</h2><p>Body copy.</p></article></section>
    </body></html>`, "ai", 1_784_214_000);

    expect(result).toContain('id="hermes-ai-restored-style"');
    expect(result).not.toContain('<div class="tag">AI Morning Brief</div>');
    expect(result).toContain('<span class="pill">July 16, 2026</span>');
    expect(result).toContain('data-hermes-date-normalized="true"');
    expect(result).not.toContain('<div class="tag">Legacy label</div>');
    expect(result).toContain("<h1>AI Morning Brief</h1>");
    expect(result).not.toContain("<h1>AI Morning Brief — 2026-07-16</h1>");
    expect(result).toContain('<p class="date">8am - America/Los_Angeles</p>');
    expect(result).not.toContain("For founders and operators");
    expect(result).toContain("background: #0b1020 !important");
    expect(result).toContain("--card: #121a33");
    expect(result).toContain("linear-gradient(135deg, #182345, #10182f)");
    expect(result).toContain("border: 1px solid #263456 !important");
    expect(result).toContain("border-radius: 22px !important");
    expect(result).toContain("letter-spacing: .015em !important");
    expect(result).toContain("content: none !important");
    expect(result).toContain("html body .hero .tag");
    expect(result).toContain("color: #eef3ff !important");
    expect(result).toContain("padding: 22px 26px !important");
    expect(result).toContain("padding: 24px !important");
    expect(result).toContain("font-size: 38px !important");
    expect(result).toContain("color: #ffd166 !important");
    expect(result).toContain("font-size: 42px !important");
    expect(result).toContain("font-size: 36px !important");
    expect(result).toContain("line-height: 1.34 !important");
    expect(result).toContain("margin: 0 0 10px !important");
    expect(result).toContain("padding-left: 1.5em !important");
    expect(result).toContain(".hermes-playable-card:not(.takeaways)");
    expect(result).toContain("function normalizeAiVisualStructure()");
    expect(result).toContain('document.querySelectorAll(".tag").forEach((label) => label.remove())');
    expect(result).toContain('document.querySelector(".hero, body > header, body > main > header, .wrap > header, header")');
    expect(result).toContain('const dateParagraph = header.querySelector(".date")');
    expect(result).toContain('const dateLine = dateParagraph?.textContent?.trim()');
    expect(result).toContain('const alreadyNormalized = header.dataset.hermesDateNormalized === "true"');
    expect(result).toContain('if (dateLine && !alreadyNormalized)');
    expect(result).toContain('const [pillDate, ...metadataParts] = dateLine.split("·").map((part) => part.trim())');
    expect(result).toContain('if (pillDate && pill) pill.textContent = pillDate');
    expect(result).not.toContain('header.querySelectorAll("p").forEach((paragraph) => paragraph.remove())');
    const runtimeStart = result.indexOf("function normalizeAiVisualStructure()");
    const runtimeEnd = result.indexOf("function isNumberedTopicHeading", runtimeStart);
    const runtimeNormalizer = result.slice(runtimeStart, runtimeEnd);
    const runtimeDom = new JSDOM(result, { runScripts: "outside-only" });
    runtimeDom.window.document.body.insertAdjacentHTML("afterbegin", '<nav id="hermes-brief-player"><div class="hermes-player-shell"></div></nav>');
    runtimeDom.window.eval(`${runtimeNormalizer}; normalizeAiVisualStructure(); ensureDateNavigator();`);
    const runtimeHero = runtimeDom.window.document.querySelector(".hero");
    const runtimePlayer = runtimeDom.window.document.querySelector("#hermes-brief-player");
    expect(runtimeHero?.querySelector(".pill")?.textContent).toBe("July 16, 2026");
    expect(runtimeHero?.querySelector(".hermes-date-nav")).toBeNull();
    expect(runtimePlayer?.querySelector(".hermes-date-nav-label")?.textContent).toBe("DATE");
    expect(runtimePlayer?.querySelector(".hermes-date-nav")?.children[0]?.id).toBe("hermes-date-newer");
    expect(runtimePlayer?.querySelector(".hermes-date-nav")?.children[1]?.className).toBe("hermes-date-nav-label");
    expect(runtimePlayer?.querySelector(".hermes-date-nav")?.children[2]?.id).toBe("hermes-date-older");
    expect(runtimePlayer?.querySelector("#hermes-date-newer")?.getAttribute("aria-label")).toBe("Load newer cron date");
    expect(runtimePlayer?.querySelector("#hermes-date-older")?.getAttribute("aria-label")).toBe("Load older cron date");
    expect(runtimeHero?.querySelector(".date")?.textContent).toBe("8am - America/Los_Angeles");
    expect(runtimeHero?.querySelector(".meta")).toBeNull();
    expect(result).toContain("max-width: none !important");
    expect(result).toContain("margin: 0 0 18px 22px !important");
    expect(result).toContain("gap: 18px !important");
    expect(result).toContain("top: 50% !important");
    expect(result).toContain("left: 50% !important");
    expect(result).toContain("transform: translate(-50%, -50%) !important");
    expect(result).toContain("min-height: 42px !important");
    expect(result).toContain("#hermes-brief-player .hermes-date-nav-label { display: inline-flex !important; min-height: 42px !important; align-items: center !important; color: #67e8f9 !important; font-size: 42px !important; line-height: 42px !important; font-weight: 400 !important;");
    expect(result).toContain("#hermes-brief-player .hermes-date-nav button { width: 42px !important; height: 42px !important; min-width: 42px !important; min-height: 42px !important; margin: 0 !important; border: 1px solid #67e8f9 !important;");
    expect(result).toContain("<strong>Readable title.</strong>");
    expect(result).toContain(".takeaways li > strong:first-child");
  });

  it("reads every visible text block in a numbered topic card, not only its title", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><article class="card"><h2>1) Complete topic</h2><p>Summary text.</p><p>Why it matters text.</p><p>Actionable implication text.</p><p class="sources">Source citation.</p></article></main></body></html>',
      "ai",
    );
    const textForStart = result.indexOf("function textFor(card)");
    const textForEnd = result.indexOf("function configureNaturalVoice", textForStart);
    const textForSource = result.slice(textForStart, textForEnd);
    const runtimeDom = new JSDOM('<article class="card"><h2>1) Complete topic</h2><p>Summary text.</p><p>Why it matters text.</p><p>Actionable implication text.</p><p class="sources">Source citation.</p></article>', { runScripts: "outside-only" });
    const spoken = runtimeDom.window.eval(`(() => { ${textForSource}; return textFor(document.querySelector(".card")); })()`);

    expect(spoken).toContain("1) Complete topic");
    expect(spoken).toContain("Summary text.");
    expect(spoken).toContain("Why it matters text.");
    expect(spoken).toContain("Actionable implication text.");
    expect(spoken).not.toContain("Source citation.");
  });

  it("selects a natural English female voice and rejects macOS novelty voices", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><article class="card"><h2>1) Voice test</h2><p>Natural speech.</p></article></main></body></html>',
      "ai",
    );

    expect(result).toContain("preferredVoiceNames");
    expect(result).toContain("blockedVoiceNames");
    expect(result).toContain("utterance.voice = selectedVoice");
    expect(result).toContain("utterance.pitch = 1");
    expect(result).toContain("utterance.rate = 1");
    expect(result).toContain("return Boolean(selectedVoice)");
    expect(result).toContain("function speakWhenNaturalVoiceReady(utterance, attempt = 0)");
    expect(result).toContain("if (configureNaturalVoice(utterance))");
    expect(result).toContain('statusElement.textContent = "Natural voice unavailable"');
    expect(result).toContain("window.setTimeout(() => speakWhenNaturalVoiceReady(utterance, attempt + 1), 100)");
    expect(result).toContain("synth.cancel();\n    synth.getVoices();");
    expect(result).not.toContain("configureNaturalVoice(utterance);\n    utterance.onend");
    expect(result).toContain("utterance.rate = 1.15");
  });

  it("opens external source links in a normal new window and preserves internal links", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><article><h2>1. Topic</h2><p class="sources">Sources: <a href="https://techcrunch.com/story" target="_self" rel="nofollow">TechCrunch</a> · <a href="/local">Local</a></p></article></main></body></html>',
      "ai",
    );
    expect(result).toContain('<a href="https://techcrunch.com/story" target="_blank" rel="noopener noreferrer">TechCrunch</a>');
    expect(result).toContain('<a href="/local">Local</a>');
    expect(result).not.toContain('target="_self"');
  });

  it("uses a non-overlapping two-row mobile player layout", () => {
    const result = prepareBriefPreviewHtml('<html><body><main><article><h2>1. Topic</h2></article></main></body></html>', "ai");
    expect(result).toContain("grid-template-columns: repeat(3, auto) minmax(96px, 1fr) !important;");
    expect(result).toContain("grid-column: 1 / -1 !important; grid-row: 2 !important;");
    expect(result).toContain("position: static !important;");
    expect(result).toContain("max-width: 160px !important;");
  });

  it("allows trusted inline controls and external-source popups without granting same-origin access", () => {
    expect(BRIEF_PREVIEW_SANDBOX).toBe("allow-scripts allow-popups allow-popups-to-escape-sandbox");
    expect(BRIEF_PREVIEW_SANDBOX).not.toContain("allow-same-origin");
  });

  it("focuses the iframe and its window after the preview loads", () => {
    let iframeFocused = false;
    let windowFocused = false;
    const iframe = {
      focus: () => {
        iframeFocused = true;
      },
      contentWindow: {
        focus: () => {
          windowFocused = true;
        },
      },
    } as unknown as HTMLIFrameElement;

    focusBriefPreview(iframe);

    expect(iframeFocused).toBe(true);
    expect(windowFocused).toBe(true);
  });

  it("uses the full Takeaways width and exactly one cyan-or-yellow card border", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><section class="takeaways"><h2>Founder Takeaways</h2><ol><li><strong>One</strong><div><p>Detail.</p></div></li></ol></section><section class="card"><h2>1. Topic</h2><p>Body.</p></section></main></body></html>',
      "ai",
    );

    expect(result).toContain(".takeaways ol, .hermes-playable-card.takeaways ol { box-sizing: border-box !important; width: 100% !important; max-width: none !important;");
    expect(result).toContain(".takeaways li, .hermes-playable-card.takeaways li { box-sizing: border-box !important; width: 100% !important; max-width: none !important;");
    expect(result).toContain(".takeaways li > *, .hermes-playable-card.takeaways li > * { box-sizing: border-box !important; width: 100% !important; max-width: none !important;");
    expect(result).not.toContain("border-inline: 1px solid #67e8f9");
    expect(result).toContain("border: 1px solid #67e8f9 !important");
    expect(result).toContain("border-color: #ffd166 !important");
    expect(result).toContain("box-shadow: none !important");
    expect(result).not.toContain("rgba(255, 209, 102, .38)");
    expect(result).toContain("body .hermes-topic-container { border: 0 !important;");
    expect(result).toContain("font-size: 36px !important; font-weight: 400 !important; line-height: 1.34 !important;");
    expect(result).toContain("font-size: 42px !important; font-weight: 700 !important; line-height: 1.16 !important;");
    expect(result).toContain("max-width: min(92ch, 100%) !important;");
    expect(result).toContain("text-align: left !important; text-align-last: auto !important;");
    expect(result).toContain("text-wrap: pretty !important; word-spacing: normal !important;");
    expect(result).not.toContain("text-align-last: justify !important;");
    const hoverFocusRule = result.indexOf('.card[role="button"]:hover');
    const activeInteractionRule = result.indexOf(".hermes-playable-card.active:hover");
    expect(hoverFocusRule).toBeGreaterThan(-1);
    expect(activeInteractionRule).toBeGreaterThan(hoverFocusRule);
    expect(result.slice(activeInteractionRule, activeInteractionRule + 520)).toContain("border-color: #ffd166 !important");
    expect(result.slice(activeInteractionRule, activeInteractionRule + 520)).toContain("outline: none !important");
  });

  it("wraps raw and element-backed Takeaway details into one full-width runtime target", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><section class="takeaways"><h2>Founder Takeaways</h2><ol><li><strong>Raw title</strong> Raw detail.</li><li><strong>Nested title</strong><div><p>Nested detail.</p></div></li></ol></section><section class="card"><h2>1. Topic</h2><p>Body.</p></section></main></body></html>',
      "ai",
    );
    const helperStart = result.indexOf("function normalizeTakeawayDetails");
    const helperEnd = result.indexOf("function ensureDateNavigator", helperStart);
    const helperSource = result.slice(helperStart, helperEnd);
    const runtimeDom = new JSDOM('<main><section class="takeaways"><ol><li id="raw"><strong>Raw title</strong> Raw detail.</li><li id="nested"><strong>Nested title</strong><div><p>Nested detail.</p></div></li></ol></section></main>', { runScripts: "outside-only" });
    const details = runtimeDom.window.eval(`(() => { ${helperSource}; normalizeTakeawayDetails(); return ["raw", "nested"].map((id) => { const item = document.getElementById(id); const detail = item.querySelector(":scope > .hermes-takeaway-detail"); return { tag: detail?.tagName, text: detail?.textContent.trim(), count: item.querySelectorAll(":scope > .hermes-takeaway-detail").length }; }); })()`);

    expect(details).toEqual([
      { tag: "SPAN", text: "Raw detail.", count: 1 },
      { tag: "DIV", text: "Nested detail.", count: 1 },
    ]);
    expect(result).toContain("normalizeTakeawayDetails();");
    expect(result).toContain(".takeaways .hermes-takeaway-detail");
  });

  it("writes cyan or yellow directly onto the exact card with inline important priority", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><section><h2>1. One</h2><p>First.</p><h2>2. Two</h2><p>Second.</p></section></main></body></html>',
      "ai",
    );
    const helperStart = result.indexOf("function applyCardVisualState");
    const helperEnd = result.indexOf("function mark(", helperStart);
    const helperSource = result.slice(helperStart, helperEnd);
    const runtimeDom = new JSDOM('<main><section id="one"></section><section id="two"></section></main>', { runScripts: "outside-only" });
    const states = runtimeDom.window.eval(`(() => { ${helperSource}; const one = document.querySelector("#one"); const two = document.querySelector("#two"); applyCardVisualState(one, true); applyCardVisualState(two, false); return [one, two].map((card) => ({ border: card.style.getPropertyValue("border-color"), borderPriority: card.style.getPropertyPriority("border-color"), outline: card.style.getPropertyValue("outline"), outlinePriority: card.style.getPropertyPriority("outline") })); })()`);

    expect(states).toEqual([
      { border: "rgb(255, 209, 102)", borderPriority: "important", outline: "none", outlinePriority: "important" },
      { border: "rgb(103, 232, 249)", borderPriority: "important", outline: "none", outlinePriority: "important" },
    ]);
    expect(result).toContain("applyCardVisualState(card, active);");
  });

  it("builds separately queued Takeaway number-title and detail segments", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><section class="takeaways"><h2>Founder Takeaways</h2><ol><li><strong>Build carefully</strong><p>Detail follows</p></li><li><strong>Measure outcomes</strong><p>Second detail</p></li></ol></section><article><h2>1. Topic</h2></article></main></body></html>',
      "ai",
    );
    const helperStart = result.indexOf("function sentenceForSpeech");
    const helperEnd = result.indexOf("function configureNaturalVoice", helperStart);
    const helperSource = result.slice(helperStart, helperEnd);
    const runtimeDom = new JSDOM('<section class="takeaways"><h2>Founder Takeaways</h2><ol><li><strong>Build carefully</strong><p>Detail follows</p></li><li><strong>Measure outcomes</strong><p>Second detail</p></li></ol></section>', { runScripts: "outside-only" });
    const segments = runtimeDom.window.eval(`(() => { ${helperSource}; return takeawaySpeechSegments(document.querySelector(".takeaways")); })()`);

    expect(segments).toEqual([
      { text: "Founder Takeaways.", pauseAfter: 300 },
      { text: "Takeaway 1. Build carefully.", pauseAfter: 500 },
      { text: "Detail follows.", pauseAfter: 350 },
      { text: "Takeaway 2. Measure outcomes.", pauseAfter: 500 },
      { text: "Second detail.", pauseAfter: 350 },
    ]);
    expect(result).toContain("function speakTakeawayQueue(segments, segmentIndex, queueToken)");
    expect(result).toContain("segment.pauseAfter");
  });

  it("splits a real shared-section shape into sibling cards without nested play buttons", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><section class="card"><h2>1. One</h2><p>First.</p><h2>2. Two</h2><p>Second.</p><h2>3. Three</h2><p>Third.</p></section></main></body></html>',
      "ai",
    );
    const helperStart = result.indexOf("function isNumberedTopicHeading");
    const helperEnd = result.indexOf("function controls()", helperStart);
    const helperSource = result.slice(helperStart, helperEnd);
    const runtimeDom = new JSDOM('<main><section class="card"><h2>1. One</h2><p>First.</p><h2>2. Two</h2><p>Second.</p><h2>3. Three</h2><p>Third.</p></section></main>', { runScripts: "outside-only", url: "https://briefs.test/" });
    const cards = runtimeDom.window.eval(`(() => { ${helperSource}; return playableCards(); })()`);
    const parent = runtimeDom.window.document.querySelector("main > section");

    expect(cards).toHaveLength(3);
    expect(cards.map((card: Element) => card.querySelector("h2")?.textContent)).toEqual(["1. One", "2. Two", "3. Three"]);
    expect(cards.some((card: Element) => cards.some((other: Element) => card !== other && card.contains(other)))).toBe(false);
    expect(parent?.classList.contains("hermes-topic-container")).toBe(true);
  });

  it("selects, focuses, scrolls, highlights, and speaks the exact clicked card", () => {
    const result = prepareBriefPreviewHtml(
      '<html><body><main><section><h2>1. One</h2><p>First.</p><h2>2. Two</h2><p>Second.</p></section></main></body></html>',
      "ai",
    );

    expect(result).toContain("event.stopPropagation();");
    expect(result).toContain("const selectedCard = event.currentTarget;");
    expect(result).toContain("const selectedIndex = cards.indexOf(selectedCard);");
    expect(result).toContain("selectedCard.focus({ preventScroll: true });");
    expect(result).toContain('card.scrollIntoView({ behavior: options.behavior || "smooth", block: "start" });');
    expect(result).not.toContain('founderTakeaways.scrollIntoView({ behavior: "smooth", block: "start" });');
    expect(result).not.toContain("selectAndPlay(cardIndex);");
  });
});
