# LAYOUTS_FINAL_JB — Hermes Briefs restoration archive

Created: 2026-07-17  
Target profile: `local-ai-assist1`  
Target preview: `http://127.0.0.1:9120/briefs-ai?profile=local-ai-assist1`  
Production port `9119` must not be touched.

## What this preserves

This folder preserves the accepted BRIEFS-AI dashboard layout and all files needed to rebuild it later:

- centered cyan `‹ DATE ›` navigator in the fixed player bar;
- dark navy full-width AI layout;
- yellow date pill and `AI Morning Brief` hero;
- compact Founder Takeaways hierarchy;
- exactly seven numbered topics;
- pointer-only volume and dashboard-owned speech controls;
- clean HTML and Markdown exports;
- machine-readable `HERMES_BRIEFS_RESTORE_MANIFEST` in both references.

## Fast restoration

1. Open this folder in Finder.
2. Double-click `VERIFY_AND_RESTORE_CURRENT_LAYOUT.command`.
3. The script verifies every preserved file before making changes.
4. It applies the cumulative V42 installer to `/Users/jb3/.hermes/hermes-agent`.
5. It runs the Briefs test suite and production frontend build.
6. It restarts **only** isolated preview port `9120` and opens BRIEFS-AI.

The installer creates a timestamped rollback snapshot before replacing managed files.

## Assistant restoration procedure

A future assistant should:

1. Read `RESTORE_MANIFEST.json`.
2. Run `shasum -a 256 -c CHECKSUMS.sha256` from this folder.
3. Prefer `PACKAGES/PRIMARY-2026-07-17-v42-restore-safe-exports.zip` for the complete preserved state.
4. Use `PACKAGES/EMBEDDED-MANIFEST-2026-07-16-v41-restore-safe-exports.zip` only as the exact package referenced inside the exported HTML/Markdown manifest.
5. Use `SOURCE_SNAPSHOT/` for source inspection or manual recovery.
6. Compare the rebuilt dashboard against `REFERENCES/BRIEFS-AI-ACCEPTED-LAYOUT-REFERENCE.html` and the semantic structure in `REFERENCES/BRIEFS-AI-ACCEPTED-SEMANTIC-REFERENCE.md`.
7. Require 32/32 Briefs tests, a successful production build, the expected V42 frontend asset, and live port-9120 acceptance before reporting success.

## Reference-file roles

- `BRIEFS-AI-ACCEPTED-LAYOUT-REFERENCE.html` — self-contained visual/interactive layout reference generated through V42.
- `BRIEFS-AI-ACCEPTED-SEMANTIC-REFERENCE.md` — one Founder section and exactly seven topic sections.
- `BRIEFS-AI-CURRENT-SHAPE-SOURCE.html` — normalized source shape used to regenerate the two references.

The HTML/Markdown are references. The ZIP packages are the actual source-level restoration mechanism.

## Safety

- Never stop or rebuild production port `9119` while validating.
- Never skip checksum verification.
- Do not restore by copying compiled assets alone; apply the source installer and rebuild.
- Do not claim success from tests alone—verify the running isolated preview.
