# Briefs gold-master architecture — V34

## Ownership model

### Canonical references

`REFERENCES/AI` and `REFERENCES/STOCK` hold the five sealed canonical archive inputs per stream. Stock structured payloads and exact-session evidence live under `REFERENCES/STOCK-DATA`.

### Dashboard source

`TEMPLATE-SOURCE/dashboard/src/lib/briefs.ts` owns direct HTML/Markdown/CSV export assembly. Its tests enforce the visual, interaction, cyclic navigation, AI volume, and gold-master documentation contracts.

### HTML gold masters

Each file in `EXPORTS/AI/*.html` and `EXPORTS/STOCK/*.html` is standalone and offline-capable:

1. semantic HTML is embedded directly;
2. every CSS block is inline and begins with purpose/restore documentation;
3. every JavaScript controller is inline and begins with purpose/state/input/output/dependency/restore documentation;
4. CSP blocks network connections and external scripts/styles;
5. the end manifest declares schema `briefs-v34-gold-master`.

AI sibling HTML files form an offline date archive and use a stable frame to preserve focus, fullscreen, active-card position, and volume. Stocks sibling files use cyclic location navigation with viewport restoration.

### Companion formats

Markdown is semantic-only by design. CSV is data-only by design. Neither is a substitute for the HTML visual/interactive gold master.

## Restore order

1. Keep all five sibling HTML files for one stream together so relative date links resolve.
2. Open the selected HTML file directly; no build step or service is required.
3. Use Markdown when presentation/interaction is not needed.
4. Use CSV only for data interchange.
5. To rebuild from source, use `TEMPLATE-SOURCE/dashboard/scripts/export-v34.ts` with the bundled dashboard toolchain and canonical references, then run the package verifier.

## Security boundary

Exports use a restrictive CSP: no network connections, remote media, workers, objects, or external scripts/styles. Inline code is required because the HTML files are intentionally portable and self-contained.

## Unchanged production boundary

V34 is an isolated review/restoration package. Production port `9119`, production UI files, V32, V33, installed materializer state, and active cron jobs are not modified. The review server defaults to local port `9128`.
