# Stock Wrapper Spacing Fix — v16

This checksum-gated follow-up applies only to the exact v15 canonical-header state.

It restores the missing 28px inner wrapper padding for Stock artifacts that use a direct bare `<main>`, matching the accepted historical `.wrap` geometry exactly.

Measured at the same 993px iframe viewport:

- July 17 before: header x=28, y=32, width=937
- Accepted July 16: header x=56, y=60, width=881
- July 17 with v16: header x=56, y=60, width=881

Historical `.wrap` dates are untouched. Raw archived HTML, cron jobs, Gateway, and production port 9119 are not modified.

The launcher backs up source, permanent test, and build output; runs 55 focused tests, typecheck, and build; restarts only isolated port 9120; verifies the live v16 marker; and automatically rolls back on failure.
