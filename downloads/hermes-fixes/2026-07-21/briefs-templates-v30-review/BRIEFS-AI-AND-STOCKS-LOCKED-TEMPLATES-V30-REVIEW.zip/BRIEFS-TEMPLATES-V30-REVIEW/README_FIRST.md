# Locked Brief templates V30 — AI + Stocks review

This cumulative read-only package contains the deterministic templates, full-dashboard HTML/Markdown exports, unchanged Stocks CSV files, compiled dashboard, and verification source.

## V30 additions

- Stocks navigator arrows and date remain cyan (`#67e8f9`).
- Every Stocks date pill uses `Month Day, Year - Day.`; for example `July 20, 2026 - Mon.`.
- `[` activates the visible left/previous date control.
- `]` activates the visible right/next date control.
- Bracket date navigation works in BRIEFS-AI and BRIEFS-STOCKS.
- AI topic-card and Sources date pills are removed at renderer/export level.
- All five AI and five Stocks `.html` and `.md` exports were rebuilt through the real dashboard export functions.
- All five Stocks CSV files are byte-for-byte unchanged.

## Existing V29 interaction contract

- `S`: one speed step faster.
- `Shift+S`: one speed step slower.
- Speeds: `1x → 1.25x → 1.5x → 1.75x`; default `1.25x`.
- Space: play/pause active AI card.
- Left/Right: previous/next AI topic.
- Up: Founder Takeaways.
- Enter: fullscreen.

## Review

Double-click:

```text
1_OPEN_BRIEFS_TEMPLATES_V30_REVIEW.command
```

It opens AI and Stocks in Brave on isolated port `9124`. Opening is silent; Play or Space may produce narration.

Stop with:

```text
2_STOP_BRIEFS_TEMPLATES_V30_REVIEW.command
```

## Safety

No production files, cron jobs, port `9119`, V28/V29 package files, or `_BRIEFS-DASHBOARD-V3-PREVIEW` files are modified.
