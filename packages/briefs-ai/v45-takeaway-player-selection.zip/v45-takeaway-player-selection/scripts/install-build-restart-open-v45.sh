#!/bin/bash
set -euo pipefail

PREVIEW_ROOT="${1:-/Users/jb3/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
PROFILE_ROOT="${2:-/Users/jb3/.hermes/profiles/local-ai-assist1}"
AGENT_PYTHON="${HERMES_PYTHON:-/Users/jb3/.hermes/hermes-agent/venv/bin/python}"
SCRIPT_ROOT="$(cd "$(dirname "$0")" && pwd)"
LOG="$PREVIEW_ROOT/v45-dashboard-9120.log"

[ -x "$AGENT_PYTHON" ] || { echo "Required Hermes Python is missing: $AGENT_PYTHON" >&2; exit 1; }

HERMES_PYTHON="$AGENT_PYTHON" bash "$SCRIPT_ROOT/apply-v45-takeaway-player-selection.sh" "$PREVIEW_ROOT" "$PROFILE_ROOT"

INDEX="$PREVIEW_ROOT/hermes_cli/web_dist/index.html"
EXPECTED_ASSET="$(grep -Eo 'assets/index-[A-Za-z0-9_-]+\.js' "$INDEX" | head -1 | sed 's#assets/##')"
[ -n "$EXPECTED_ASSET" ] || { echo "Could not resolve the new V45 asset" >&2; exit 1; }

PID="$(lsof -tiTCP:9120 -sTCP:LISTEN 2>/dev/null || true)"
if [ -n "$PID" ]; then
  kill "$PID" 2>/dev/null || true
  for _ in {1..30}; do
    if ! lsof -tiTCP:9120 -sTCP:LISTEN >/dev/null 2>&1; then break; fi
    sleep 0.2
  done
fi

: > "$LOG"
cd "$PREVIEW_ROOT"
nohup env \
  PYTHONPATH="$PREVIEW_ROOT" \
  HERMES_WEB_DIST="$PREVIEW_ROOT/hermes_cli/web_dist" \
  "$AGENT_PYTHON" -m hermes_cli.main \
  --profile local-ai-assist1 \
  dashboard --isolated --port 9120 --no-open \
  >"$LOG" 2>&1 &
DASHBOARD_PID=$!

READY=0
for _ in {1..60}; do
  if ! kill -0 "$DASHBOARD_PID" 2>/dev/null; then
    echo "Dashboard exited before readiness:" >&2
    tail -80 "$LOG" >&2
    exit 1
  fi
  if curl -fsS http://127.0.0.1:9120/ 2>/dev/null | grep -q "$EXPECTED_ASSET"; then
    READY=1
    break
  fi
  sleep 1
done

if [ "$READY" -ne 1 ]; then
  echo "Dashboard did not serve $EXPECTED_ASSET within 60 seconds:" >&2
  tail -80 "$LOG" >&2
  exit 1
fi

open "http://127.0.0.1:9120/briefs-ai?profile=local-ai-assist1&v45=takeaway-player-selection"
printf '\nV45_LIVE_ACCEPTANCE=PASS asset=%s port=9120 pid=%s route=/briefs-ai\n' "$EXPECTED_ASSET" "$DASHBOARD_PID"
