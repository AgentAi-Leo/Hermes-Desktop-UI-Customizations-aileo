#!/usr/bin/env python3
"""Read-only, self-contained review server for locked AI and Stocks Brief templates."""
from __future__ import annotations
import json, mimetypes, os
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse
from zoneinfo import ZoneInfo

HOST = "127.0.0.1"
PORT = int(os.environ.get("BRIEFS_TEMPLATES_REVIEW_PORT", "9128"))
ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web_dist"
REFS = ROOT / "REFERENCES"
DATES = {
    "ai": ["2026-07-20", "2026-07-18", "2026-07-17", "2026-07-16", "2026-07-15"],
    "stock": ["2026-07-20", "2026-07-18", "2026-07-17", "2026-07-16", "2026-07-15"],
}


def listing(kind: str) -> dict:
    label = "BRIEFS-AI" if kind == "ai" else "BRIEFS-STOCKS"
    stream = "AI" if kind == "ai" else "STOCK"
    hour = 8 if kind == "ai" else 14
    briefs = []
    for date in DATES[kind]:
        base = REFS / stream / f"{label} - {date}"
        generated_at = int(datetime.fromisoformat(f"{date}T{hour:02d}:00:00").replace(tzinfo=ZoneInfo("America/Los_Angeles")).timestamp())
        briefs.append({
            "date": date,
            "generated_at": generated_at,
            "html_exists": base.with_suffix(".html").is_file(),
            "markdown_exists": base.with_suffix(".md").is_file(),
            "csv_exists": base.with_suffix(".csv").is_file(),
            "html_route": f"/preview-api/{kind}/{date}.html",
            "markdown_route": f"/preview-api/{kind}/{date}.md",
            "csv_route": f"/preview-api/{kind}/{date}.csv",
        })
    return {"kind": kind, "label": label, "root": f"bundled://{stream}", "count": len(briefs), "briefs": briefs}


class Handler(BaseHTTPRequestHandler):
    server_version = "HermesBriefTemplatesReview/34"

    def log_message(self, fmt: str, *args) -> None:
        print(f"{self.command} {self.path} :: {fmt % args}", flush=True)

    def send_bytes(self, data: bytes, content_type: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, value: object, status: int = 200) -> None:
        self.send_bytes(json.dumps(value).encode(), "application/json; charset=utf-8", status)

    def do_GET(self) -> None:
        path = unquote(urlparse(self.path).path)
        if path == "/api/briefs/ai":
            return self.send_json(listing("ai"))
        if path == "/api/briefs/stock":
            return self.send_json(listing("stock"))
        if path == "/api/profiles":
            return self.send_json({"profiles": [{"name": "local-ai-assist1", "description": "Locked Brief templates review"}]})
        if path == "/api/profiles/active":
            return self.send_json({"active": "local-ai-assist1", "current": "local-ai-assist1"})
        if path == "/api/status":
            return self.send_json({"status": "ok", "gateway": "review", "version": "briefs-templates-v34"})
        if path == "/api/auth/me":
            return self.send_json({"user_id": "local-review", "display_name": "Locked Brief templates", "provider": "local", "authenticated": True, "required": False})
        if path == "/api/config":
            return self.send_json({"dashboard": {"show_token_analytics": False}})
        if path == "/api/dashboard/plugins":
            return self.send_json([])
        if path == "/api/dashboard/themes":
            return self.send_json({"active": "default", "themes": []})
        if path == "/api/dashboard/font":
            return self.send_json({"font": "theme"})
        if path.startswith("/preview-api/"):
            parts = path.strip("/").split("/")
            if len(parts) == 3 and parts[1] in {"ai", "stock"}:
                kind, name = parts[1], Path(parts[2]).name
                stream = "AI" if kind == "ai" else "STOCK"
                label = "BRIEFS-AI" if kind == "ai" else "BRIEFS-STOCKS"
                candidate = REFS / stream / f"{label} - {name}"
                if candidate.is_file() and candidate.parent == REFS / stream:
                    content_type = {".html": "text/html; charset=utf-8", ".md": "text/markdown; charset=utf-8", ".csv": "text/csv; charset=utf-8"}.get(candidate.suffix, "application/octet-stream")
                    return self.send_bytes(candidate.read_bytes(), content_type)
            return self.send_json({"error": "not found"}, 404)
        if path.startswith("/api/"):
            return self.send_json({"error": "disabled in read-only template review", "path": path}, 404)

        rel = "index.html" if path in ("/", "/briefs-ai", "/briefs-stock", "/briefs-stocks") else path.lstrip("/")
        target = (WEB / rel).resolve()
        if not str(target).startswith(str(WEB.resolve())) or not target.is_file():
            target = WEB / "index.html"
        mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        return self.send_bytes(target.read_bytes(), f"{mime}; charset=utf-8" if mime.startswith("text/") else mime)


if __name__ == "__main__":
    print(f"BRIEFS_AI_REVIEW=http://{HOST}:{PORT}/briefs-ai?profile=local-ai-assist1", flush=True)
    print(f"BRIEFS_STOCKS_REVIEW=http://{HOST}:{PORT}/briefs-stocks?profile=local-ai-assist1", flush=True)
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
