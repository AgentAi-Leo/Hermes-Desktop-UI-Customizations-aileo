# Briefs locked-template architecture — V32

## Runtime flow

```text
AI cron data / Stocks fresh Yahoo Chart acquisition
                    │
                    ▼
strict stock session/freshness gate + paired v1 JSON marker
                    │
                    ▼
profile-local no-agent host materializer
                    │
                    ▼
strict schema validation → deterministic renderer
                    │
                    ▼
output validation → atomic replace → retain five dates
                    │
                    ▼
dashboard-owned presentation/controller/export functions
                    │
          ┌─────────┴─────────┐
          ▼                   ▼
 live sandboxed preview   standalone HTML/Markdown
                          (inline CSS/JS + comments)
```

## Ownership boundary

Cron/model output is data only. It cannot define CSS, JavaScript, navigation, filesystem paths, or dashboard controls. Presentation and interaction remain in tracked dashboard/materializer source.

## V32 Stock freshness boundary

`stock_quote_collector.py` and the active Stocks producer contract obtain each symbol from Yahoo Chart, select the requested completed market session, calculate movement from the prior completed session, and require all seven tickers to agree on the session date. Any stale, incomplete, or inconsistent response emits no marker, allowing the materializer to preserve the last valid archive.

## V32 AI volume boundary

The stable dashboard parent owns one volume preference and restores it into every sandboxed date iframe. Standalone exports use an equivalent same-window/date-frame relay. Slider input mutates only the active utterance’s `volume` property and persistence metadata; it never calls cancel or speak and never changes the active card or viewport.

## Locked assets

- `TEMPLATE-SOURCE/materializer/schemas/`: strict AI and Stocks JSON contracts.
- `TEMPLATE-SOURCE/materializer/stock_quote_collector.py`: deterministic Yahoo acquisition and freshness enforcement.
- `TEMPLATE-SOURCE/materializer/brief_renderer.py`: deterministic HTML/Markdown/CSV renderer.
- `TEMPLATE-SOURCE/materializer/brief_materializer.py`: fail-closed session reader and atomic publisher.
- `TEMPLATE-SOURCE/dashboard/src/lib/briefs.ts`: canonical presentation, volume controller, CSV generation, inline export controllers, and cyclic archive ring.
- `TEMPLATE-SOURCE/dashboard/src/pages/BriefsPage.tsx`: archive rail, parent-owned AI volume, downloads, fullscreen, and per-date state.
- `REFERENCES/*-DATA/`: canonical data-only payloads for the five review dates.
- `REFERENCES/AI` and `REFERENCES/STOCK`: deterministic raw renderer output; Stock CSV is date-specific and carries `Agent=HERMES`.
- `EXPORTS/`: transformed HTML, semantic Markdown, and Position Comparison CSV generated from the same functions.
- `web_dist/`: compiled read-only review application.

## Export contract

HTML is the accepted visual/interactive standalone form. Every HTML export embeds required CSS and JavaScript, includes explanatory comments, has no external script/stylesheet dependency, and implements the same cyclic date ring and AI volume persistence as the dashboard. Markdown carries semantic content and hierarchy; its note points to the companion HTML for accepted presentation and behavior.

## Safety boundary

The package review server serves bundled files only on isolated port `9126`. Production dashboard port `9119`, production UI files, V31, and older packages are untouched. The active Stocks producer prompt was updated to the compatible deterministic data contract; the installed host materializer remains unchanged.
