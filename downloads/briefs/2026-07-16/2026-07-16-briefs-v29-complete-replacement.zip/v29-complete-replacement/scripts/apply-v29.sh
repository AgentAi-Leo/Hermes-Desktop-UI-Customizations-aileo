#!/usr/bin/env bash
# Complete-file V29 replacement for the isolated Briefs preview.
set -u
PREVIEW="${1:?Usage: apply-v29.sh /absolute/path/to/_BRIEFS-DASHBOARD-V3-PREVIEW}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FILES="$SCRIPT_DIR/../files"
for file in web/src/lib/briefs.ts web/src/lib/briefs.test.ts web/src/pages/BriefsPage.tsx; do
  [ -f "$PREVIEW/$file" ] && [ -f "$FILES/$file" ] || { printf 'Missing required file: %s\n' "$file" >&2; exit 1; }
done
STAMP="v29-$(date +%Y-%m-%d-%H%M%S)-complete-replacement"
BACKUP="$PREVIEW/.hermes-ui-customization-backups/$STAMP"
mkdir -p "$BACKUP"
cp "$PREVIEW/web/src/lib/briefs.ts" "$BACKUP/briefs.ts.before"
cp "$PREVIEW/web/src/lib/briefs.test.ts" "$BACKUP/briefs.test.ts.before"
cp "$PREVIEW/web/src/pages/BriefsPage.tsx" "$BACKUP/BriefsPage.tsx.before"
cp "$FILES/web/src/lib/briefs.ts" "$PREVIEW/web/src/lib/briefs.ts"
cp "$FILES/web/src/lib/briefs.test.ts" "$PREVIEW/web/src/lib/briefs.test.ts"
cp "$FILES/web/src/pages/BriefsPage.tsx" "$PREVIEW/web/src/pages/BriefsPage.tsx"
printf 'V29 complete replacement applied. Rollback files are in: %s\n' "$BACKUP"
