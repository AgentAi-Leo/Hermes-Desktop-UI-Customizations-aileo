#!/usr/bin/env bash
# Applies standalone V26 (after V23) to the isolated Briefs preview source export or checkout.
set -u

PREVIEW="${1:?Usage: apply-v26.sh /absolute/path/to/_BRIEFS-DASHBOARD-V3-PREVIEW}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PATCH="$SCRIPT_DIR/../patches/001-v26-pointer-only-volume.patch"

for file in web/src/lib/briefs.ts web/src/lib/briefs.test.ts web/src/pages/BriefsPage.tsx; do
  if [ ! -f "$PREVIEW/$file" ]; then
    printf 'Missing required V23 preview file: %s\n' "$PREVIEW/$file" >&2
    exit 1
  fi
done

STAMP="v26-$(date +%Y-%m-%d-%H%M%S)-pointer-only-volume"
BACKUP="$PREVIEW/.hermes-ui-customization-backups/$STAMP"
mkdir -p "$BACKUP"
cp "$PREVIEW/web/src/lib/briefs.ts" "$BACKUP/briefs.ts.before"
cp "$PREVIEW/web/src/lib/briefs.test.ts" "$BACKUP/briefs.test.ts.before"
cp "$PREVIEW/web/src/pages/BriefsPage.tsx" "$BACKUP/BriefsPage.tsx.before"
printf 'Snapshot: %s\n' "$BACKUP"

if [ -d "$PREVIEW/.git" ]; then
  git -C "$PREVIEW" apply --check "$PATCH" || exit 1
  git -C "$PREVIEW" apply "$PATCH" || exit 1
else
  patch --batch --dry-run -p1 -d "$PREVIEW" -i "$PATCH" || exit 1
  patch --batch -p1 -d "$PREVIEW" -i "$PATCH" || exit 1
fi

printf 'V26 applied. Rollback files are in: %s\n' "$BACKUP"
