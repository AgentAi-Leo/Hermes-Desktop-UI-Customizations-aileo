import { PluginPage } from "@/plugins/PluginPage";

export function GitCommentsDashboardPage() {
  return <PluginPage name="git-comments" />;
}
