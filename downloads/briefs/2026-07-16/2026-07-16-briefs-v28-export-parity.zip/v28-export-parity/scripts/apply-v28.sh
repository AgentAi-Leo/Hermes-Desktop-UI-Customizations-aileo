#!/usr/bin/env bash
# Applies standalone V28 after V26 to the isolated Briefs preview source export or checkout.
set -u

PREVIEW="${1:?Usage: apply-v28.sh /absolute/path/to/_BRIEFS-DASHBOARD-V3-PREVIEW}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PATCHES=(
  "$SCRIPT_DIR/../patches/001-founder-focus-and-stock-fill.patch"
  "$SCRIPT_DIR/../patches/002-export-parity.patch"
)

for file in web/src/lib/briefs.ts web/src/lib/briefs.test.ts web/src/pages/BriefsPage.tsx; do
  if [ ! -f "$PREVIEW/$file" ]; then
    printf 'Missing required V26 preview file: %s\n' "$PREVIEW/$file" >&2
    exit 1
  fi
done

STAMP="v28-$(date +%Y-%m-%d-%H%M%S)-export-parity"
BACKUP="$PREVIEW/.hermes-ui-customization-backups/$STAMP"
mkdir -p "$BACKUP"
cp "$PREVIEW/web/src/lib/briefs.ts" "$BACKUP/briefs.ts.before"
cp "$PREVIEW/web/src/lib/briefs.test.ts" "$BACKUP/briefs.test.ts.before"
cp "$PREVIEW/web/src/pages/BriefsPage.tsx" "$BACKUP/BriefsPage.tsx.before"
printf 'Snapshot: %s\n' "$BACKUP"

if [ -d "$PREVIEW/.git" ]; then
  for PATCH in "${PATCHES[@]}"; do git -C "$PREVIEW" apply --check "$PATCH" || exit 1; done
  for PATCH in "${PATCHES[@]}"; do git -C "$PREVIEW" apply "$PATCH" || exit 1; done
else
  for PATCH in "${PATCHES[@]}"; do patch --batch --dry-run -p1 -d "$PREVIEW" -i "$PATCH" || exit 1; done
  for PATCH in "${PATCHES[@]}"; do patch --batch -p1 -d "$PREVIEW" -i "$PATCH" || exit 1; done
fi

printf 'V28 applied. Rollback files are in: %s\n' "$BACKUP"
