#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
PRIMARY="$ROOT/PACKAGES/PRIMARY-BRIEFS-COMBINED-V61-V74-FINAL.zip"
EXPECTED_PRIMARY_SHA="46cb968ef30071c433bd17145cb3844698b64b9fc73b346ab1656608d9edf0f9"

cd "$ROOT"
echo "Verifying complete archive ledger..."
shasum -a 256 -c CHECKSUMS.sha256

ACTUAL_PRIMARY_SHA="$(shasum -a 256 "$PRIMARY" | awk '{print $1}')"
if [[ "$ACTUAL_PRIMARY_SHA" != "$EXPECTED_PRIMARY_SHA" ]]; then
  echo "Primary package checksum mismatch." >&2
  exit 1
fi
unzip -t "$PRIMARY" >/dev/null
echo "All archive and nested-package checks passed."
echo
echo "Accepted shared state: AI V61 + Stock V74"
echo "Target default: ~/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW"
echo "No Gateway or production dashboard changes are made."
echo
read -r -p "Type RESTORE to apply the fail-closed restore, or press Return to verify only: " ANSWER
if [[ "$ANSWER" != "RESTORE" ]]; then
  echo "Verification complete; no files changed."
  read -r -p "Press Return to close..." _ || true
  exit 0
fi

TMP="$(mktemp -d "${TMPDIR:-/tmp}/briefs-combined-restore.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$PRIMARY" -d "$TMP"
set +e
/bin/bash "$TMP/BRIEFS-COMBINED-V61-V74-FINAL/scripts/apply-briefs-combined-v61-v74.sh"
STATUS=$?
set -e
exit "$STATUS"
