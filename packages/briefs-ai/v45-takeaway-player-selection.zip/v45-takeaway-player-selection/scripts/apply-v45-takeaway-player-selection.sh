#!/usr/bin/env bash
set -euo pipefail

PREVIEW_ROOT="${1:-/Users/jb3/.hermes/zDownloads/_BRIEFS-DASHBOARD-V3-PREVIEW}"
PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
AGENT_PYTHON="${HERMES_PYTHON:-/Users/jb3/.hermes/hermes-agent/venv/bin/python}"
STAMP="$(date +%Y-%m-%d-%H%M%S)"
BACKUP="$PREVIEW_ROOT/.hermes-ui-customization-backups/v45-$STAMP-takeaway-player-selection"
BRIEFS="$PREVIEW_ROOT/web/src/lib/briefs.ts"
TESTS="$PREVIEW_ROOT/web/src/lib/briefs.test.ts"
DIST="$PREVIEW_ROOT/hermes_cli/web_dist"
V42_BRIEFS_SHA="a5208fcf3c8e9976eda283dabc00f01be830c22a209417d30974929201773603"
V42_TESTS_SHA="564f3aa62c1fff29be092acda688f41ca0efb07ad455c5e0276ca60a977103ca"
V45_BRIEFS_SHA="19d4b7916f0816d38a6a181d220a88a7fc41e12697c1dbd69df5ce925caa6f8c"
V45_TESTS_SHA="17c741c1b48d8149ac95677315e4cdf764e74ebe3c59906c1070ba37dd7db4fd"
SUCCESS=0

sha256_file() { shasum -a 256 "$1" | cut -d ' ' -f 1; }
restore_on_error() {
  status=$?
  if [ "$SUCCESS" -eq 0 ] && [ -d "$BACKUP" ]; then
    printf '\nV45 validation failed; restoring the pre-install preview snapshot.\n' >&2
    cp "$BACKUP/briefs.ts" "$BRIEFS"
    cp "$BACKUP/briefs.test.ts" "$TESTS"
    rm -rf "$DIST"
    if [ -d "$BACKUP/web_dist" ]; then cp -R "$BACKUP/web_dist" "$DIST"; fi
  fi
  exit "$status"
}
trap restore_on_error ERR INT TERM

[ -x "$AGENT_PYTHON" ] || { echo "Required Hermes Python missing: $AGENT_PYTHON" >&2; exit 1; }
for path in "$BRIEFS" "$TESTS" "$PACKAGE_ROOT/files/briefs.ts" "$PACKAGE_ROOT/files/briefs.test.ts"; do
  [ -f "$path" ] || { echo "Missing required file: $path" >&2; exit 1; }
done

current_briefs_sha="$(sha256_file "$BRIEFS")"
current_tests_sha="$(sha256_file "$TESTS")"
case "$current_briefs_sha:$current_tests_sha" in
  "$V42_BRIEFS_SHA:$V42_TESTS_SHA"|"$V45_BRIEFS_SHA:$V45_TESTS_SHA") ;;
  *)
    echo "Preview source is neither the accepted V42 baseline nor this V45 candidate; refusing to overwrite." >&2
    echo "briefs.ts=$current_briefs_sha" >&2
    echo "briefs.test.ts=$current_tests_sha" >&2
    exit 1
    ;;
esac

[ "$(sha256_file "$PACKAGE_ROOT/files/briefs.ts")" = "$V45_BRIEFS_SHA" ] || { echo "Packaged briefs.ts checksum mismatch" >&2; exit 1; }
[ "$(sha256_file "$PACKAGE_ROOT/files/briefs.test.ts")" = "$V45_TESTS_SHA" ] || { echo "Packaged briefs.test.ts checksum mismatch" >&2; exit 1; }

mkdir -p "$BACKUP"
cp "$BRIEFS" "$BACKUP/briefs.ts"
cp "$TESTS" "$BACKUP/briefs.test.ts"
if [ -d "$DIST" ]; then cp -R "$DIST" "$BACKUP/web_dist"; fi

cp "$PACKAGE_ROOT/files/briefs.ts" "$BRIEFS"
cp "$PACKAGE_ROOT/files/briefs.test.ts" "$TESTS"

[ "$(sha256_file "$BRIEFS")" = "$V45_BRIEFS_SHA" ]
[ "$(sha256_file "$TESTS")" = "$V45_TESTS_SHA" ]
grep -Fq 'border-inline: 1px solid #67e8f9' "$BRIEFS"
grep -Fq 'border-color: #ffd166' "$BRIEFS"
grep -Fq '"Takeaway " + (itemIndex + 1) + "."' "$BRIEFS"
grep -Fq 'event.stopPropagation();' "$BRIEFS"
grep -Fq 'block: "nearest"' "$BRIEFS"

TEST_LOG="$BACKUP/tests.log"
BUILD_LOG="$BACKUP/build.log"
(
  cd "$PREVIEW_ROOT/web"
  npm test -- --run src/lib/briefs.test.ts 2>&1 | tee "$TEST_LOG"
)
(
  cd "$PREVIEW_ROOT/web"
  npm run build 2>&1 | tee "$BUILD_LOG"
)

INDEX="$DIST/index.html"
[ -f "$INDEX" ] || { echo "Build did not produce $INDEX" >&2; false; }
ASSET_REL="$(grep -Eo 'assets/index-[A-Za-z0-9_-]+\.js' "$INDEX" | head -1)"
[ -n "$ASSET_REL" ] || { echo "Could not resolve built JavaScript asset" >&2; false; }
ASSET="$DIST/$ASSET_REL"
[ -f "$ASSET" ] || { echo "Missing built asset: $ASSET" >&2; false; }
grep -Fq 'Takeaway ' "$ASSET"
grep -Fq '#ffd166' "$ASSET"
grep -Fq 'nearest' "$ASSET"

SUCCESS=1
trap - ERR INT TERM
printf '\nV45_APPLY=PASS tests=35/35 asset=%s\nRollback snapshot: %s\n' "$(basename "$ASSET")" "$BACKUP"
