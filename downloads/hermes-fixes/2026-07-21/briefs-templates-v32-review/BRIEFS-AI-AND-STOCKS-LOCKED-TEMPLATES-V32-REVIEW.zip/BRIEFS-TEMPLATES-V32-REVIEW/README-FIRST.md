# Start here

Read `README_FIRST.md`, then double-click `1_OPEN_BRIEFS_TEMPLATES_V32_REVIEW.command` to open the isolated V32 review in Brave.
