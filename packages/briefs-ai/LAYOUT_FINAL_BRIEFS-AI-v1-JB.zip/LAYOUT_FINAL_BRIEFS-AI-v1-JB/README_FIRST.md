# LAYOUT FINAL — BRIEFS-AI V61

Accepted AI identity: `v61-date-load-keyboard-focus`  
Accepted Stock identity preserved by the same shared source: `v74-ticker-above-company`

This archive is independently restorable. Its primary package contains the complete accepted shared `briefs.ts`, `BriefsPage.tsx`, temporary focused regression suite, and fail-closed cumulative installer. Restoring this AI archive does not downgrade the accepted Stock layout.

## Verify or restore on macOS

Double-click:

`VERIFY_AND_RESTORE_CURRENT_LAYOUT.command`

The launcher verifies this archive's complete SHA-256 ledger and the nested ZIP before offering restoration. The installer accepts only four exact source/page/test tuples: the audited Mac preview, the known V74 predecessor, the final V61/V74 candidate, or the exact post-audit candidate state. It snapshots source and built assets, runs 54 focused tests, preserves the permanent host test file, typechecks, builds, validates AI and Stock markers, and automatically rolls back on failure.

## Offline references

`REFERENCES/` contains five self-contained V61 HTML exports and five semantic Markdown exports for the accepted retained dates. Keep the dated HTML files together for offline cross-date navigation.

## Safety

- No Gateway changes.
- No production dashboard target.
- No restore without an explicit `RESTORE` response.
- No success claim before checksum, tests, typecheck, build, and marker validation pass.
