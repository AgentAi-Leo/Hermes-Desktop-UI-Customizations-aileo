(() => {
  const sdk = window.__HERMES_PLUGIN_SDK__;
  const { React, fetchJSON } = sdk;
  const { useEffect, useMemo, useState } = sdk.hooks;
  const e = React.createElement;
  const API = "/api/plugins/git-comments-v27-review";

  let successAudioContext = null;
  function getSuccessAudioContext() {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return null;
    if (!successAudioContext) successAudioContext = new AudioContext();
    return successAudioContext;
  }
  function unlockSuccessChime() {
    try {
      const context = getSuccessAudioContext();
      if (context?.state === "suspended") context.resume().catch(() => {});
    } catch (_error) {}
  }
  function playSuccessChime() {
    try {
      const context = getSuccessAudioContext();
      if (!context) return;
      const schedule = () => {
        const now = context.currentTime;
        const frequencies = [523.25, 659.25];
        frequencies.forEach((frequency, index) => {
          const start = now + index * .12;
          const oscillator = context.createOscillator();
          const gain = context.createGain();
          oscillator.type = "sine";
          oscillator.frequency.setValueAtTime(frequency, start);
          gain.gain.setValueAtTime(.0001, start);
          gain.gain.exponentialRampToValueAtTime(.055, start + .018);
          gain.gain.exponentialRampToValueAtTime(.0001, start + .22);
          oscillator.connect(gain);
          gain.connect(context.destination);
          oscillator.start(start);
          oscillator.stop(start + .23);
        });
      };
      if (context.state === "suspended") context.resume().then(schedule).catch(() => {});
      else schedule();
    } catch (_error) {}
  }
  if (sdk.testing) sdk.testing.playSuccessChime = playSuccessChime;

  const styles = `
@font-face{font-family:"Alumni Sans SC";font-style:normal;font-weight:800;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAADZQAA8AAAAAdigAADXuAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoJcG6R2HIhWBmA/U1RBVEQAhRIRCAqBj0jvYQuFEAABNgIkA4ocBCAFhUoHjgIbqGIVcvMauR0ICX3aQY5ECBsHvHjw/KwINg6QGK5b8v+3BE5k2LIZ6NTfQtlWmURgUsc3w2nPSUsFJpU+nhaaV1Jpae/lnohfIQ/bQJHyAog7qTQ/M8p/KyOxolj+NpwdvgZ8FXcvvQKdbgl7zsC2sX2SqTcTI7IVpcjpQ/YI7LPQYvaA0OInsABNNmxiwwLGreH5ufX+soCt2V/Dgq2J2thgg22MEhBaWlExSEEFFQZIqpfaqKd9xZkBVp1n5KUBxuld6/fqyhnLDszffdcFEDqilgRe6xCKJuFVK7WHEKKK66So8M+13vf28P8Cjk+JPiFnk+xu7rLJ4pHwxfGdCtMa3bqy0GxrS/Uy+Dl74CyCeBQCiSGeBFHzmzRNhdGV9vnlfvbhhTYbKAGPrzAV6hQJf+F/tmZbYStsrQGOrzJl42sU0oM6YJiNgSuduZtJdRd3gieQ/ExVgLtM5AtDVbolwmcGDa+s2HM+mFl4oP+Hc/b6J8wLBazQy7ebRUpzgRKlHQBk/SvVynSaONyDvHuDd3apE994yqZ7p1AXvclkXeWDHoDgYIglCe7+EsSZNTJr3pBLmeXxDbGWeyvvozc+kye5Z5yjvA11Cl2kIPpUqYJISags9DaIAgWxItHz/H6pvjsq+9ULoDERMlYmBTqyij2Bqkdb+7pX/rfvUjatjVfSRfyVLo8kRBer42EKQogl/hj79IFpdV/jGHHG2Hb7r9wo+HbbztwiIiGEECR1rvBwjr9+dX8/zSQ3h7hSTAPyTtr9eRvHjWVsPvDd1AGVEudQP8WCkAc4FOhUFGgOFiFgbAiQVosBQYE8yTd3GwIBBtRukB8qsNq+hoN33+oiaCQQChoIAxOETQQioQLRCQeJFAkSLRHEKRnEzQeSrhCkWBVIrZkgs80HadAA0mSBwjBCuy63Wy/UPkPqCp+ra6yL3mAbyE671D2+4aPjypB9DoMSnw5KVQCZpjCl6jOpcVlPSMiRBjUVOAuOxX5UKH2OlIqmNdWQUY3Pyu1AFJg+PcCBrGqhLrpkaQvkP/VIgfxXJMrAfdBEgxwKeAibZZt6MA95+N5Ig/Sv2gX83+VRAIGAYYHOT0JAbg8E2PcA5f7L91lqi04UGKUnEECpfdL4IqDtFtIXokC2NCkc4kQwUJODcUEK9hvI/I2BdO0EyJydBynPvMadxMFBtX716tIVeIVbAqIJksXSBKT2ez80XvwM6apopvU6oADBgbYD+8lBmxXJR89hW8gm3vgbc6NtBBQK+T8198/QA+vnR3duXBo7cWh07/aRtZ8ML+9c3DLfcWdV9+ZMK8hOS3HE3Y/rab9Z9rnO7YBA/Dvvib/qW/dsfpwHc3uuzYU5M8fmwHwzu83WfjEbZ/V8NIPTM0tn4TTN3KmdytK8ksmbrEkd1yRMzFhGN8qRTvCwhzEkBAYBoP/0exP9Gqrv6kn3utWVznXKcY+0b2zbV+1sS+v7bFa3sv78ddTKqNRATXd1TVe8PN+MonLLyFPSTp51F1jU9GQqDJS5H0F2NQlprfVyEO3Jq2wccIZCbRu59Tuils1Il7KjU1OwK74fjDce6oWuxGIYKx965bx4hpUbazG6L3CK3fKFM50WulXzRWsoTmv11mmr+lZlT1u7b7c0raY7qcUbJw13OLOlI9J9RHTEfC8c6QSuE7DK1tBYVmm1UhOKZlGGa0hZZbgKiI63kuKguZ51PHSwK2EdVdBRc3ziqAYTjr5aPx9X500YX5aqzZ2/V9e5udgb6ByirZnrjd3hNjZGMeaVsS7hugT1Z276LBu6Kroq/aq6AM7qtNNON+x0vjOdKG5cuid+1KbYON241zP+rhgJAEhk9Hhjz9HszNoszNSMTF8dYxxf8ze6pOjWWInN1YOltJZp/EXnf+xw52Tz97j2M/H/LAeq6RsmMP8wwPQRiuOGke7XDk+sey0D0F3Y4j/wI4xOY1ZjnlN5ICvTYyG+BfP304e44kqxcFJrDehMPrhiR+WjrOipO4bRemulg9GY1qd6ovWrq2FLD5FXWYt6m1G/w+19dgA825/tk29GnLLSFRvXlTXodNytep4DdprNSRscWaW3vDJQ7oRjjj8b493idjD4uMPsLLa66VLnwDq3LVLlgjHbne96D50J2DP+aoCAN0UBcIhouCRU1MJFiecxRY7CiuYn09SoNUeLNp38+g1AVr5KK4EA+4JYgdnnk4mAg9TJgAQhEApwMi4IAlgmCOQ0yAlQ/VtAmFCAfaWyimIiZwLBOOa0G2EhCpQICblqxxY4sVKQo1Qgt5YJuQxIUT5s2YOrtEl3pWBoExThRLDCM/dfvR8qtKE+8D6/2/ZiYdo/9nKAVawMtaEVv78FAB5Ero4kwM+tAICykomlffD++j/i/s5tvnoYnuqqXG4ZTfZxs92RuHB9N4FCm0jMnVr1Elgf/1JxPHFnrsmzPwMwu54oi19dEXcWlsATsblWNjDR48BrnLM8zi7RYrCndaUmE6bL60m9kP7MK38ccaLxFx18aER+yIjGoqHDYf15T8DBRQRTIdMIw6Gjw2NgwBchhkCSJGLJUkikySBToFiIUlXUatQwmq2eSaNG0Vq1itHOL1av5RING+a00iouH/tcirW28tlmp6n22KPQtw4ogmCCRoRCRgahoEKgYYGwsSFwcEGEhKhgUhAZNQSNMBAtLQQdHYieHo6BAV6ECDSRIhFEiUIXLQZWnERoTj5IadIwlKqGNMMMSDPNRDLbbGR15sOoVy9QgwaUjkuDNGlB1IpohnZdUPz4wn7JHgi9hikyQ1gAegFZjXdUa23kbzfZCmEbFsL2BdmxEHYuyK5wNg3+FotmdBF8d51unwOwhf4gAILaPlC0IaMPYuCnIvqEIya1LIpZ/2JtuskQEPoagIwIPwdKlwGjYCyqwh+JihTDXBWQg7xFJOOgCrIsplkCQdGuEHQITwkI2l2ydeMGnPU2WtOaUo01pTVDCpgJDZINBTj9NZQtmuJzW2FtlZEgTCPguYC/eJH/RX52r+DXaNkxR7zwjS2kIgCRQ5q6PpiImISUQYQos4rTtGo33E30xz7xqc98Tpu73oa291/YYY9vjfrOPvsdgJR5kzad54vzIQxgSNz24x2RAbhQ9H93sX1xF2GXX7jnLiCbsgIicKTrCr4lPiouJDMnIIlCJspKUAnY/bKLyTVXAEIgFJSgAjVooRt6YAVsghHYDFtgK2yDHYMQ2WULasQpjveyC9ETNlAfVvsQDFezJuUQLhRg/zloqUnYHw75g2gRIu1kFjEecE5CL8EVRIr+4WnetP/+QEon4uST0/qv62O9j28RuP21sUjg8hdRmLoJ0k7V9dY4SUr1tBiSTevkpc0P8wPgWeV/Z7UeOHlIl8LewzAFG1/rWPqjUx9m/lYiDSP/yuI+IMzmJToJGyUpKckDeTuZD2bD03Vjv62PeZ0za8bqOP/OD3XZndaWFQqUg6HgQNG2mLh2uWBsDCSLIRRa9FAztYbTLIT0CrUt4UwQyIMA+kMfoVW0dh2WWGqZTl38uvXotVyffgMGDRm2wkqrfHSlv/Vqa6729W8yYrMttvrCNtvtmLJh9wfe60tf+do394I42PFMcRyAS1TB+sj9h5phAaXGnw7kaKHAmHHnnHfBRZdcdsVVz72ICJEgMkBAQ0ICPussyB13EUNDaEAOC+EAhVMLrumoY4474aRTTjuTZAmQSHEQRHNXAZkuhFDjwoAUESID85WYrUIqE2H9KD9A+sUJCBQY31cWH3O7cVsIwlHHQfS3lsKECBMWRj8BxYM8FQHMYhFoowIHnFIIEoASo3sY6FSd2fXbPoN5qbcxM4JHgFQTe9ETwEj8Yx96xRCA0c9Qyc2Z6u1lyUfcASdT3gcFJlm+yRZDiSIbYYDk0QaIQbRYoA1xs+MMTSLmpctW19krmdFMitVKO590DoLQU6l6KAGixJKaOxgWIgFUTTsYGpi3TS7gyvz+u42hUPtHfxm4H/CQT9mln6uzcAz55GOQS/duILD7TPoTAfQ+gP44PsCJkCBpDzg6I6eWPX+/lyABgH9i1Y1EAE0FCh1GRALA7jSo/ZFwFQZ24mgs5ipqForz/eA7i49MK9JCHxrtZc6hOTN35t4OQqKQeKTkxECYCwfDYlgOG+Eo2EF2isSiIdEKMUMc9AEjh4DpRFmfvgyGMEDukLh5ATAb5l+lAY5kr47iXa75k9YC9h6bV1Ks+T8MgL0jHj0BgB998dE+Lnp0eTTM9X+EePh2dsbAgxxAgHMBt3gA9EEI9Z4nrHc1/IXceRgC/BwW4iUMCV6a8FNUcNdbd/zinvsFFVCgxwVDI6OgYWBhr+ZJ4TKzjIaWjp6BcTXCtX3/Yr32qzdx/FG4OEmckrmlSZdxXXkFCmegwVI1ZnyKoE2tUy8a0/+lJwvxKhaUR6EhPISBCFBooiyJHfJ/bL8nKSZZTNfdKCJusKfFuuawD+i/7/3gCTwMLCIcAhIqpgCBggTj4ROgkwolp6ASEp1SOBMzixhhZkkQz8rBxi6Ri4+HV6qppsiWI0WJCtOUqVIeQ6X55phrnmbTtVCrTpXRv/7zp7/94y8QaGEtgHICzLuAzgSOegHguDcA9nkC2DYAsAGAWXu2vrZBudkQfPDVAggdbUZLnTogEkCjsbw+LHpaDtEawRpmGJe0nEvQaIuvfL0gJWPu3PdnYTFL40h+nI04VfTuhwpkRU2HmM2mJr+k/1AFFJjiZq5jfAPzs7QhsWa1Gs3BZja99J8kyDeMsXRXYV7q3TTee6XzKBqW5kwMYtowgoR0VCyiiJdPMDsKVCtW6arr2rGlSZiEnqmEYa08CGiZ1qJYR0EC43r07bqaply5FVarxcu7WbvtR43W+32zrfOapaG1FpZpzkAoONMedKOfZRVfo+1blx2lRuGcdhrcwqvNp32vFj4MvBkfbA4uSh4w7IqhjXrFavV61RqSJGiw7fId91cNDHTJQqmeX5eqimKknTLmE85cWM3LpWGMZeO0YxXBLSj3t9Dgronf5RNkq6LmKih//c23+7U/OXi6oQQdaBMr2qGSjjqJQebUXHUz/eY2FEgnwCqnQxwkhfdrgMM9YpEKVuTAiDASJ1Jeq4nJDaowuaXpug70sQIDiVkTpFnStxoANeWVcnoVnzjDq6XRaimFGKGLgW4GaW06DbDBOgnhuaL8zpq49ohhNUsYmWxrZjldSAsQGLmwEArk12NaQDznqJC1QlXlUTZqX7ULVubJRcMnBlQpVVYBipoRtCwlMnuaBGVIBpTfVfd/DDpaqXCMYdzyqpXSx9yRJ4+IkLKDDeRQt1w1fSQ8y7jTLhuzRM0bGFa0MYXP8Ig8rVsRO11W4vdsMacMpWbNtnlBryxW+uyEf9IDvLT9aS0vglpZLu/Sfs5XwnWS7B+8eeXG0kYYsFpvUNqi7WjAo/Xe8peuVqnK07oVjEPZEKvB5fTW3vMeSrEXmC1By7J+AjlcXr6MI9DJGxSj+y1Hn9I0RHhyyxJfOIo4XREgTWZHiscRwOrt209yioZT6KV87VIMYwk63qHUNFreF7qkAM3E4rJoBlg9G0dNzGxoijO+kVAvlhKoEDJZI1rsjuBDtW/bKCmxB9rMGc/7i77ZtkKgo/DOKCTRlfDl4oS+M0AgIUE2tnk/746xo1pMIeVmadBlWnn9RrVIk5enNI5JJMB4Md8vBAQcm60OBC2VLZbIeXvCI3ZAhNul025tTx1VHXVmWyenDy+XFgYLonc6VKjMprg7UMj0OBYwgRhMwwitHLT2XFdh58yBpl43WbgEj0JQ3w7EPZCsQTfyP3ylNu1i2r5topHKvBDA+OnGZ12+2DYRIUPlHolRB3iXGKeGAn9ewExrxVRLIdgL1ZGwIb3TWLk4w3paKR+qfsI4znE+FWpIQGMG4jcU1IEoUZHKKK2LNC/7RRzQzJbxBRzL8PocxBjxYtjYO0rwKwI6dggOOIt4wBKHpJFOIjLBbcqjrWC3EiK8mw7xhZp0B5Qi+1pRBiiCRvESsmtySyurvGfTi5ditTgb1IZmVzpX45hCE3QaKwJH528JGkZwYwkHZ/z0uH/Q6gIXFumziilRYtBjyCXlqREFvTK8mJfGYWbsmjwr38+DhGLwrhTnX7z3qTBnVp9IERLz6xi4XwiPBk5nLdTtDjvAR0ROSiKVZRip7SGYxQX+ZHTFsmJEDyANzS+xuQVfA7hy3lrBhk8VIElhKHzGpphHSUkZtVZ21ZF4ToLXb161C3NU1uBAxeh8O+uatQrgN2Ap5QmY2rDp2Kn0ujVQtLWSxiuYLXNnbOfLlg4fkUfbFbF7oC7H9ITR4FjnSZhX6Gd2lQSJ2EbOn4VdBf5mkg1iK3bW5KMn1Vz4sWHvGT7iSM5YClbN3CmN6uleGDhplAySrMjCf+I9WicONrpezU1qC9zsl9er/PIJcMKAEFpPeP+XwRTNEf4sB07XirHzeH2sAmWF69U8exaGOF2xjVLLRmrQyESL9STEpmHyxqzpPfp5WmyGsrBHBhKyYDmEQgXb+m7SRhSxVlycjGWUU5UX70CAb1MZvSGkOQC9Fo0gXV2n0xgv5Xwh0sZeyy2xWZvPi7hdgq/3IN7L08tgdDhmPF2IJ5ckrrVTvU7iWa5/l0BES+4KKkxd45fxGM0cB2etymWLgtxQYQfVklSLShYWubiXL3gjkhhMTD7EYw4g5m9v0WUs7ED2y5cRDJrYD8JAs8gqHx17HYu8O0p5Ncyshdaarvg9jBHnZ4J8+wCMX4Jo5E6/seoRHqA2r0OEZNz8NyHE6YgNPM/KEGuyD9RcMgJlJ39I3G9gmMQkWe8eHjH7eGFjoZ3RVGedOAE7BzqkBfGG64aacn4Eg13DGOr6lbzR7mu+fUru8eoKvF6fLyj85eKmMHz3LhYxH6OVQnz93XGSjX8gQDjxByeRkDCMEXJjoPYuBKslKS/y6ZitcivyvMITQRJDPeHAEC8FIkgbSejVC2qU3kiNhUAaphTRg4jn3Hn3C5Dk0nKZUYiSO0JQV1vIhDugxYa9OBi749npsZ2pqN1ZPdia0bWpcG8ll/FWALv3DH8OvHLjcAlBz1dxR7G8gxGG4Mwdn2hzTwJ3x43XMXxo7pofqfTLbuv3N74qt+wzl8R7lgYY+iR2wR6Lb7Ovje1lLDdZGObKm7ESaUerdDk+K8ch5PRog8Iu5oSAHBlpKPq98FvnFoUxrXtgmeW/3Wrp9subz8oUZwStnO84+4aSL7mB5YIHu+pjljbgYe9D3HOfBd6hF7weq8MNVzj3hXH1u2f+nhedXqOJNJu2LjsSVUoEvf8Dn9cHi4GwjYTJ6UJ+tS/neSddHO595xrXM++QGb1XgWxsxDWjWSJx3/EaIxi0wMyg+/UI+96YSsrYqfq8tr4hXWVX5WzKlDd0Ajor8S/46X171hs98uyWxDOGRvPpSy4aC1J6CND4Yb2MLGpa8MShUz2ZstePn6+9uyI8g9KcFTnJO7KmgZR2MrBkaXd6+29YpPyd5eNKTGZenzOb9TwDSbNo4vyCh5iMmsKcJoEYGY/qivD3FBX3Qm57ukuRSyE54JvjWr17Xs/kcGhiVAVpecG/KqdXjl15GazOzWpQxga+vkUov1py9D3CQ5LCwItfpf/Lclpnxe3Or1mco2NVcZF6euPx1K33JdZFIela1R42mzI+qbltgaPjWUSiwDNI+hysjJctwuCf2blDfD9pCGuxdBtCXSTk72zBehqWJvVm6QgDeAUdbVZjlVHIKnxf1BEZBv6/1yb0ufpz5PZ/tjDFMqCjRy6c63C7dcFLz+ODXg9LpzidZbCQcfdwJEzGr5i316iIdFItfWaQtIXsInf3ZCb8tJMbiA/YfxNhhRmS1cuLVcUx4IVXT+PEugno0cCtNtAxq485RZMBKQwmER5rRzWVNVv9FV1OnLZM5O8hqMYvXor94t2LAFOYej4/9XNSSQyhhDgSzbcAxJbU2tL1UNfAzD7o083FcVCJmVkCjxjJcJAZiHwPoj/SJHCfvdz+z2uIevYfklfs06F/UjuSZIQfWth2aRBdnANTo+QRgvcUGRgnmrxstdujMY6nso1mN7vbuKS3mzHnDAF/aw6jmj7vJp5weh59UW+yN8TtZgOR756qereoWie3MjWWJJj8ml3JfkOGgdk3+TWwtu57Dfpv3x1f8NehTPoFl8EMTR4Fu7TL3zCz4bOu4orPxV/Ahoc3y+0JccbtbpbJ6GWPG3O6ihntP5MI79sZ1fQl7wh0CWuuNHWHrqYGYoBFE3/QoPe57XmPr+c/23+wtz6wGC9eXBx8RRp8pGc0BrY7OYBcrC/ir5zBm2XouKQFc92vml3X3BOTGZu529eyPWFb0cG3u31NJVHRzapBsRAGp4lGD1vZG8o2DwunS+1Vu/VhGtII2Lm0auo8LIHwxxJqNa3jD5D1fRzj+3gZy5gav5DJJNSR+nEypuFvltGrGaW38IRbpYxqetlNH2eEJbGbUwo3V2sg+MuKdQ3/onH4QkvX+QdmDny2rni17mPcqKZCGeBS6dJ+MfDp/4Szdd/RREDgGyr3xH8b1twSo03vuHRhooWj30IXb0lbQj16MdroZas8bqVxPI1tNttt6jaGxvCShkwF2wcJP3fQKxjtPxOi/Yutgt7xHvT7foob1RSo1XYHImjvSvP5z+QnEj/D03+fIgwMDXYEv2NIwUlshE8Q4nZKpclSHVz3nEgnhEis7xbpDjJsmlhhshu2T8lJciaLEyVC5VFmwG0+vLguZ++0NVEJKk8GDEonckujS6dOgHGi/M5ldkLkN733aHNv4fE/z6Xd6/k6kmW//AxU5qUOhB2HjMd7ClLBtOxbn3atbu38g37+T2gwJ3WjTqlTAlyG3sfvUe5W7F6RJkjV9ap2yXeB+j9nZfeErGxtVa5cNLfoFbiX3fjxrFKSfdH2xaWgAcu7tF2ZonGdugvucIKJM8/i6YflygXhslwrbEtwBp5QL/ObppfwcgOOCOfIUzrHTwZEUDP3gwY0ifHKJU8xnoTuaP/hwOIZw+/Mk7VmJAK7hJWdteR17T/B+LMra/+VDEl1YYAt4naE2+lKz7Qk95zwUzPOEAhnM6hZfk5kkG33mF0ZVcw8QaNeY4KnGPXbIlVJg3/X4llSPv2N/qUlLBYfk08aN9F+Z1+lUp4wf2efBYexpuQghTP5si8rMj0t05Ls8WexjlOpj1kU1hMq9Ti7yK9NkTtdQWANJpgQpzFPSlL+SGaEJK/Z5m8oeBCebIfc+NECmCSGKr7GEzZPFxKxFPs4OIQ1pDAVzpRjyWmWRGLpPLIAjQhizl8xRZoUGu0UyB3kOZln3HK3i21Kot7gEohFY0TqCRYx6LFi741ja9527hGYCpf7hjvLMsTdc2Ip+3FQK8zyczxyl4uZrovK7u6vPRA6AHvhUIU3qDOQeUKMiqsbogWi2Jocb84AONFI+2rjU9h5tZxB36z+hOGK/Ecm4dQO3dcfizVbTeI0zzRGcvMnYpzr5buYH4nnEinvGRWbCOTH7IdkX9cKIGxYdHzvE1HYh6ZFg382PjhvlIj72sHoA8JJ/yQIrKu7qnPi15cMLg987N+XbE7JYoF3C4KpVzqLrxXyahr9jUCYa8rk/B19LFHkpJeSVKmwqazWJv+coBMUAk7h988LPE4h/mLuDd4w7+BCC+yQEIo3E7BfNzB6+4Sw1pAy7suKSU/PjE4bc8td7pE0plKecAis61TKGzaB8waUAgz6QMMc2JLMkblc48aYZG5EhIsbYxxLbvSxTlMqcdxOIVASxomk8QQKYW2RUTupxQ8jiWtWWkWFqrGIYK9Vpswa30z1JqXlHfdkJNnc6VvhsEXsq1TqVbavDUmQuBMFOasFa5vMAsHzyrpk6/iKYMYr7UQs184VS3IHP+Hvx4/MCCZiicLpm/G4kaoQFJdiP/uLKz3z77wpFwXTpcky4bJvwaf8ffiN6otB1NaM4An708lIEq12C7gzb/28WYqg6RMC06TE/YeLEZrcj+wqG9mH21KrxbNRIVUjuK0RXWH0/zrfVfacSfNXg2vTxlN4wUqwH5vggnkOo9SfwP2OQT3JUHJCirc3n7so5dudCcXxicE8m168NIo3SqN/Qw1l7d/l9O8/KBFpP8zDgDJM7Kjz6jA66yOCrFkwpCxU8uR70pip+SXK8GJlwFVU6bffBy8wfe2jWfSJgsD4trC4gOZZbCZIDGGehM2hCAmzeEEAeBAusmf8C9aRbGzncoVeZz/IyKvJn+qbymE84JIZiHSEGyzHhP3PDZ3nn0mynSPhNtUzuv2T83f3YcGsyonlxmxIld1ePgGqyic6DB6jZ2mUR+VpL5tYE/pM8QwgCj94Jjpk3brutuyJ9A/t835DP6ibJ9yHdJaWUUjfm7CQqvhqX9gshHZWe95+ep7XC3DmRdPm5hCjmnNbCvasfY1MirBrz7+rGF5BDUSzNPZQyz9xMsOc+LQv6YHvg8L2sxf5B+wDgjUZJ5KlCbjq8mFGIAvDDS1bpFufSFPqHaSu+KoaPrutnqi8dq8nUmSh9qGaUc7wKHUCyVE1XE9ZFI7y4IwJcVnyNLQLt6zcn2YznSKJc9hqh8cx6B+yD3nbNWu6Pt2UTPT3hecKhSyW8vo9/4C7K78R4xKN+SI32olbNq0rVe/4hijJYSvtXvsAwORPnM2b+JSYFE1IIvojef+BvskfogakFs33W++8RlBu/kBICraarUZXQqIEf7OdYWa/CYCzgsnFYlXgE6oEnMZHujkyR+zvsYVGb2quMbbev4BMoFCekXXkv8gUPLneHxcrcTi5AJ68HZL1LcdgthtTzA4h7mQT3kB6RhEC0+QzZdbmxnrQRc8tD9+vIDE+DbgEluK3R8EoWlo8f/r8GUsLK5o7Bj7FCjemRKJj84weT5EhzrN0ConLoBNIenIoleqiFEo9X6CrZkE00HsXDfxHrUe7JrsuWC9AYjL3I1GHEy8uEPC83Bn+Gt32RN4hbEXYwg8FE0M1L2tBizjXOdwYTHZH9PuRv2OyMdeWU7DwXPfj21D46HHjZH3R2TFwHB+ZzJU4Yn6PzTe63cXG2LcxUoebF5lKjSHoCWoaVZ03DlJvcn1wC1w7n9/YPdJMKcMaok09gOLREDqMbDMdBqwZtnLdYkx4Cldmj3sVW2z0peYZY18Zdg0avVsXU7mkMBKXSv+b/msVgCcfxe6ReiQHTcigj9eatn8s3aCe1YChn5YG04pZlqDXNCk4hCn0xKYI+xWCd3Q6UiRIeV2oGZHJnG5XcWZOdKzFz5SMBgVcZ3NbChODpxkVGRWOQ8EWfR7KLjIX5QyB0/jwlEBfXKW/n1y1Yw/7uyrifMlBoCx3ok9Tg9DXdE2dAPnpE8uVDpVjTqGctzxtYp3y+vglALDpkPdFV+hCxcIB70s38CvbZG1g3sUZos6QstZaZdmC2aGnASmrPqa2CGNd4GstBukI2ic4rob32rNNy2QQmvHEUhYnRcS8mhmiOETmPssQxr/9iUsDHIHfOupbSGJcdAWYj4cPL9A0ayV6nUTbpGk9PInroa6j9uAILWhKCzhJ0nkUyhzPb1OLMn3ugsypv3pDp3rkxjSqglvAlVPJ8vIfBwWYs70qlVb2Pb7FBxjC2OBItrX5W23qXyL4SmDQHbW8J82Vk5Rj98DC5FinMrMgP+vWopZe6FYdOIyO9sJya5irN1h9lxnwlB/FL6tTpagZZzrPLCGpuE8DWAeVAb2xSdnO3OL0OLvJoBFDKcYwU5yHD47M3Td738zu9riCuLk3L3pWg5NYu4cF263RvboQbgDjX0UVxTVBpckQPdFTpl1oq/1ckzAt9vMomdXLBScIZq9YkRyhTi5MTM3IsaeE9kSy3tBoKGb7j3qe3qY1DGlVtlSxIY1qZw8xdxLJGsLnLBPgrXv5TWlc2drn4Dg2yiuS23TS4MXHdv2Unkb6lzYjmKP6xcW1Jbi4v6g4kl82dNo+Y8UGSUPENrcizhv4R0BB4G1m0H1aPuOXAC7FyTdzrgcxv2GaA7v+ApvEzBx7iqnH0ZU/b3pu2HiiiLumUp3K6hObLR6xwhWpTi5ITLWQw/ArWCYq1cj2M1eDxOfQat2/qx1hZSDoRZix6ZR1kTCgkUr+miPP5NpEMWG//sZWxBI9yOFcMxHd5wALnkfWKlXZdObyV+QtVDFtAZ8XxhcUUbmUVRRaK5OYI1O1RNjPSWDBT5AwMJineg46nid2mHt/TflJHilP7G6zFIM6q7fU5gX1eH49j1/P56/i81YBw1pUC4tpsQRx64OFFqGA5ZI4VcB1iLkP82Gl/Jd1UH5KuJXP3yo0uoBLmXNOv9Ft6IekVuEWAe/sa4Un2ALmbVoA/Xz6/eZHQRr+jUDmN5yYHu/ArgSvEE6MYqjYSfcU7YCYHreLX8nlV/IFnXxuJ5A4WsFPt96vesXU8H4MDMo9rDd1YLdtR6LpGpbjJWuQRsiI3Smo4PErBF0e/k2//IZXLvfcEOWU5/PkPQVOestThnsuUNRdu2uVZzsUZ/ZUhbSOB33UXeXKGgVtpq2rOBmrxDM/BtyMTxSLc0IWN4acX3iAkzkgnjk0bMi4Jde0pQFczqb+3VhrNgFi1obiKRtAg2qKJll7DzeUFMUmVcmXJnmUQ+76UmeaJ3KmNJ8+IzKCViOewkCEUt4IN5xHnxkVvq6sAIQ7ojAuqVK+xOlWrhD9QgChXXmgWqV2SELmvl0USMO+ZMsDHgvolFknF8KhysQqVSFwLjnQLhUQ7Cg25XHIY/oLWcC1oJdC6e1Fr8BEV9Kr2belwvuyawGyf6HHIVcpbJSdIJAOfbbCWQCqVMrEUHjW9VkUuuYxQ878D0sLXPR0bohE5ahRgU/2vHLWieqcP9hZjVd7ADyZdy0P8KrUR2rXBvcmLUkC/8du2fXZKddTyu1AzboUaYWYh870DfXDQGf5sqOdJ5qPpUuP5pa6AaJ8aS9o6jrReTQHyFC8Fthi7wBR2eDK7m9gXJ9Nv37XaAeemj8dwArbPGPooYh/5UcUhqlZBb9zDoprG+dTd73DY9/tomqpe95h8e/2UGc0xhvOk35vBCXWixWV64YDFXBV1YWaappMDmqmX6iq1oXI4Zqqe9Ons0MC5B+mXWwah0NnsyEOB4BXWqch3Slut9IUBymk7Xq8kqPUtTTtOCITRBkSrNg0YEPrnA5xawx3lEYfoSo52xbmVPfslIqCN42ekormpXoepwIq0ehlh7o98Z7ZZom3xFJt3O5hGY0e9qdGaa/6NRcgbF1db908Sfls73z6vJsEws0yemIv1Zv8KmIDttn9PyNJnpQRlyM8zjWmxU/xFsQ4dU161sRCMmMri6ENoSRmuBwc+4mdGzJ4QFcsVtabrYjTP6XgvWSZqBgsaplqm2qQNboK4W7dVuPWhUVwlC3VkFqiWgB1RZCxtKgO2B/e6+/3d/d31y3oBQk3CmYWAF1BVWVFmTW+slxnrdZK21UZby2/b3EVCH2VH5G/+kuensM18nh2LsfGdfAMt9MNPG5CaQLQJ+WX5pec3fOAqLVlWeZa2PBuSzJgtbLzbmvlL5MM8MX6Hn++vye/pzu/u+fJ+im1U8Dsv/Xv/yj9UshwyMg3h+Cbp1+nHdR5cJ8+Ad/OPj1Y9ksIgCdW3UpYeavWVeeqA/DiOn+35T0BP1pKne2fp+L+q4bNA4SjIC0htcyeCv4hu6eGNjBWVKvUX93g1anydv1FaCWvIy0k4Bq5uHVYXsOr/4SHU66ds6RJpVL/JLaF24jYBuUeqBrBDRRicn6z1fZM9lxus85pRb4BKvBCjn9RzG1DvpkBoMl5LVYbqLQ3dyVb+is3fvTVVlAIVsZM6Zieoaiy6UOCc/WS8ZeNYbqNMfzxt23LbrHQfCzzIZOJ5AQXSCShc8OjRotk21SPWPSL1GRbmmV+XWxOzhyzZWFthqQywVLIHNTZ0W7Ch187Fe6gcrL+ZqCoHOel/bZq1cVyKvsO2IcwORXSZKNK7qwauSaMvG+F/+QumUZzWbgBJQtmrzPvOXbsYiJIX5OVRMbICKT9N5tZDtHNk7l3AwvotXldv+Pq22mKWDAahVf9I8qKjwpOVvRzDy2NCNGEgFP+CK9A4U4KHFLDi+8S6YRQsfnXWanvMsSmqDV/LVidKeTE3Yr7ByLQ1Akqjw8Wb7s8oFdIbrk4Jf/1k2WxQpdbZJ+Sm+TU9cYy9zEDbvMVjSvO7e4fDTfIbGeASRBVofR4lRVRUcoKj6dCGXUie4h3TUO6DMmkOFNrja2sjLVq174JcYZWS/FJc2S1DknYWn2PuTM8Yr7ekB9BWU0kLqd8Q+slEj+nxeUL9evCwCGmKik0NEmlEnpfrFInlilqHpIM4yRS3KBEspjDR5zTDq2P4TGCGPsYwIQQ2yTu77am0J25QZTLFEIblQN+1AVPDb9guZAXHP1L3M/a+on/5fIbp/q0OvEN8Hkc8SlmS7Q7RT/cLImMd9mjBcxg/l8wnyMQyEHU19GCrqlg172zu+vkoQpKXpY3lIOIzVMbptZ/GdsQCxLnJInHpwOziPUyiPmCxbrHDLo/o1wA7GJOAoctLtYGtdLyyuaISiCLrGwyx/9VBXi4ZFZK6azc+xdBLU8BS2SwQmaTStJMVBGZJqJS9TSyHnwtpR36fnMNiXydKlc7hPRzo99OJVKv8pWUGjTAaxy3HCBSSqSmxhIx2EIcBfWFoE2u3KJCsUqqSQQQ38OaCGJOsJgUZhAFxG0N0pb9VeHHU/4j4/fhMEvExgnDyrIMC1nwe5AgFMxtmVvYllwIsC3e0pYFpQBqmFadUlZVOLL5wPrFdG4xfVmx73ExY3cxwMgBGgAoQFawCNR85CFbwtlOlZG9i7eCna4gYqG35iSK2soMOpyhjWnGyOTsWQXMIJvxksQlsQrE9minepW9iH8ALpIAQqLLfGKhyYItypDe1uzjQTwAjUqIj0a0mzE4ohGZ0QgbohfWZoC4VRgYQtydVlsWlUs0UaLLoD4aTpob3a2MPnNnKhBVIjUWZIk6WMJMor32huqFhJoHyKdagGLqY700KAxYaaZBUTlFEwm91ylgldVlRhCVl5o4bxKhE01JxcZ2fIT2O60ZRZUqGqvocqm3efcWjEXep41m60ts7DDX2640QIJVd2FmFO11Ub0UtZCah9hAveN2U5Tipga6AOCNmzz+tlEprBOwFx/b3mShDuCLe2FL+2gXBgab7faKwoAjAoNHY3iMyuNkngjiSS5P8Xm1fvo8njlucLbyXlz79RluGQXs53rVK5Cxm5NulijfkH9ZX81i7atwB+hwGHdCc+4ezlPrQtFS0p2T7jhecKelwL46DPjFdtb6cwkeBJO+Q5tz90mCplv+W/j/36Kk2EMn3RBagUNYYQj3IqQiaaQwSSvpJL1kIGZrX4mVzYX2ctJ72a5qlLrliScA5J+PDyZeOQz/57trjw6jpu9RyfFXWqs+KPiw+09rgmP4ALu9cwFgX6C3z/1MfiQ/kH9I/o/RvGs3f3KJ+DlZHeVH8oPADym/jyiLVfxRWZ7i+8pi5vpMpqc1IbLvo/woxiV/qLNhWxmWYRkWGM1b3hd4WYWz3JQHl+fn5DOlXdjXblp/gGTHznJ5MOmHYiHg4/sc4r/wgouK/zp6oWUBvh2zCS4FPr5kd3NJbw9Ol5Zd5kMuk8p8HI2GBZdXrZvyoOy/4vIFa9FMSi0YoNcNkAdHBPmM6FqH4Zn9AeZnRXSSB6f4KeWXCC46/htWlj3Xd4p8Yp8vFXQN8bC2lYRmkDy4PD+ndhHyWtJRHkz6UWA1DdQo2nxhvZMtKXz2+IjdN086uUWtxLkEH+zXXFY/Sk0XNzhTJABeASVfFh0eeFF1k4UEZW5lJF/A70NtwyUO1cN4ExeBdV0Trxlp97heMbRT+nOu/0C6UoYjwfjFIzcpzBwpP0zNh29aORvXHaltuoXfvgUzAr2itkw2MCd7OX64kTmw5UCBr9ZOGFGsGRQwvrNzBoHc/6cL5WEezVxgtY/gM5sXvJwHcNPqXziSSz2cMcSZb+8TBMLv1ILZ+jrl8Y9/1756r+p+JUz43/WxY1Qc9crnSr0P6MLrZFca/8dT/P7i/q9TIEDb6jeYX39WHGL+jkMifwX43nvQCMBPXtqveQ2u5hzeQQDYFwJAwBdjU/P7gLL3Gwp91KBL+5ah/4DnuT7yBPVemBlHu6AVRC3Hy/gq++APIeQmAnDxvhj55DoXIbhY8AoZ/0O3DXE1lHGPbeVVD+Dl1iCZmcl8Uw4PEfQR34LCfgF54PPLh59bhhFn+iPVAVczzAtKg1SDQGUGLcOFVrAROkQrjAKDaIBvsd3bCJ2B4KJsiwYUJ9YO2hsgZXaUMbzqBdiJpaayCNMWOrgMP+gWAd1bf0lh6yKgo2+FnTyIKtb/Tc+ilXBdgZ8ZpCPYevjumnXDXLIX3DI83mf51xnu4BHJttneYQBsDIKLtu3yoOov6FjEN7CSXBmlo166Zn48vgS8X8MauysGrhM+O53w2SVMyvz2LbDNhf0NQfIGy2/odWInQKgbow6U+mG0effMzYD1RUCde5BZIAnEwAMuaMAECaDcm0CjSP4X5F+kSACy9zZTjzTphbSVmWAwyWiSD8HNyb2kgjP7hAD5vW469VLJdoegd0RLJDIEbfnVHTQMdyQfiLe7HJGYF5adkgfGSzVAX8XfCMTp/a7UmBBcDSHyYdcJ3UL7xHBstpZ6UX4s6CDQ83OAS2fjdBe7EVDmNOIugvD1oRtDGxIYFsXeUMsTsspOeyQhDuHdROMNhpG3B0Op1C1t4cTj2PKXtI1hL9dCztKuoJZZLgTeP3ZFI+A3QGcr9ZtIffbKvubuTzmQfVSEA+WDChUAvhcll4KdRO4Eo8Gz5CM+iQcWBP1kHdQ79vp9g4AuVQbNBwUiil0td6jdxS02PAA+U90SgURliSBQCokgpXhQjcJF0LhORTBMBiMUFnkRGjnTw+kYxK8N4SBCACRMIMoEjGsDbrAxDR+lzUtatCIxu4Tr8nx3Wu2+PxFqgqFw45SUT5OITQYRFzNNIrZ4JP2HUmkgNqBVKwoDgubwYi0REyJ8YKGFEXH5jYTJTNM90cR3iEdRITeFRLsWbaq6r4geNGvVqtkJl4GNjw5XSqEiE6YjXGLSiqV1kcUe0aHT7ia/cwKR4Gt31yjFBIvuuJSFZx9iln/feM8lN8UpWws2cGxwM7hLSTESHs+qqXTvA5b901tVBl+2PgBaO3mbsQ/OmuatMu8MkrmLu+enEMJ755wX6qFHHhtLFMNSXkGr2s7BtDGDVb4YSkuz2OhvsoSV9+rz1U3VvotM7XTDb7Gm0jtsX4nmeyPRDGPWLy5BTCj/tp2XgxRuHt+br0FjaFDPGwak8kmTrkmGZgu0arFBmy9lmpBlimzdcuRaaLF2i0yVJ1+BFw4oDAvhIDw45ngEiAiRIDJEgagQLXqMAgosKGas2HHixoufoOCEwYkSJ0maLHmKQgpNmSp1msLSpkvxujOmzFkKL6LIoooupthELrbtfPEaa5NNJJmJM75bePgllpQzV8ml5M6Tt9R8pZVehkN+9857dFQCwXZA2URso5O6kGEwxJdZVlPKRkRSpEQcK1o5vvK1BKecThXkbbM9Wc+vQzRCuZY6DNtUy3xUXvkVVIhi0iv7wESEVig1wlYRXMWVkMDz69Srx3JLYkzRhlM/YshRoIMueiixhGVU6KOGZ+yeuu2+H9zxIIMBhhhhjAmmWMFqdmV7acma3CikWra1jbc1yRZlmNraWKwt6ejszTinTk4yp/K8vsrSlpg1UcrSRJjXvUhnqh/7RyC0szuep1yKP5XFLM90I1pxinRqAFZ9ZiIVd7J2DljfOcYEn4QUBd6TF4lXBtHZJLwtQMwnZgsn61DAZToge85xk6TzR+pskpoLkK1l8nxfsHamAyjZzb2D11Y5F1ABH3Rnk36RYDqbjM8FmCnmJUiGlebFisaeuTQryAXCQARxgwuuiHyqua1qnGwCkHY2pT4XkM6Xzk6dbAUC1UDNqluIug62nF1HHhpWYV7HQxInb7TIO0m1RhTHStC6VZhAgZkZWbE5MZY1NlEEXrNxH/D6RC21vvF1lJoQacqGgPF6gy7cxBtpwS6bXoOtmpzdlvVLCl8JJp/AN6HH2Pz8TU+ezYGbeEE7tVCzBrGwYu0kgZ9EA22xyZC8yGDQmwOimgborLexvg6POCFDAjM5RgIzRoS+w2QS7HCKUReRCcf3tf8XHwp8v2LJ4G3DjWPDr2ofW2QiV8+ePWNcCWR6SeWz508mUbHYYkM4yRmLRZJyp1cxdyYYi88yxBz6ecmUZLg2bWxWdIYnZNjs7sSssAb7Crba+To9N2ojNwMAAAA=) format("woff2")}
.git-comments-page{padding:0 24px 32px;color:#f0f6fc}.git-comments-health,.git-comments-panel{border:1px solid #334155;background:#0c1624;margin-top:20px}.git-comments-health{padding:22px 28px;text-align:left}.git-comments-health-title,.git-comments-toolbar,.git-comments-add-form,.git-comments-panel-heading{display:flex;align-items:center;gap:14px}.git-comments-health-top{display:flex;align-items:flex-start;justify-content:space-between;gap:24px}.git-comments-health-title{justify-content:flex-start}.git-comments-health-actions{display:flex;align-items:center;justify-content:flex-end;gap:12px;flex-wrap:wrap}.git-comments-button.retry-connection{border-color:#ef4444;background:#4a151b;color:#fff}.git-comments-health-dot{width:15px;height:15px;flex:0 0 15px;border-radius:50%;background:#64748b;box-shadow:0 0 0 4px rgba(100,116,139,.15)}.git-comments-health-dot.healthy{background:#4ade80;box-shadow:0 0 0 4px rgba(74,222,128,.17),0 0 14px rgba(74,222,128,.48)}.git-comments-health-dot.broken{background:#ef4444;box-shadow:0 0 0 4px rgba(239,68,68,.17),0 0 14px rgba(239,68,68,.48)}.git-comments-kicker{font-size:18px;letter-spacing:.16em;text-transform:uppercase}.git-comments-muted{color:#9ca9bd}.git-comments-repo-line{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.git-comments-repo-primary{font-size:20.8px;color:#fff;font-weight:900}.git-comments-watch-state{font-size:18.75px;line-height:1.1;font-weight:800;letter-spacing:.12em;text-transform:uppercase}.git-comments-watch-state.open{color:#4ade80}.git-comments-watch-state.closed{color:#ef4444}.git-comments-watch-state.merged{color:#a78bfa}.git-comments-number-link{font-size:25px;color:#f0f6fc;font-weight:800;text-decoration:none}.git-comments-issue-author{color:#9ca9bd;font-size:16px;font-weight:650;white-space:nowrap}.git-comments-issue-avatar{width:40px;height:40px;flex:0 0 40px;border-radius:50%;object-fit:cover;border:1px solid #475569;background:#0c1624}.git-comments-owner-star{color:#facc15;font-size:22px;line-height:1;text-shadow:0 0 10px rgba(250,204,21,.55)}.git-comments-number-link:hover{text-decoration:underline;text-underline-offset:3px}.git-comments-summary{margin-top:10px;font-size:16px;font-weight:400;letter-spacing:.08em}.git-comments-toolbar{justify-content:space-between;margin-top:16px;flex-wrap:wrap}.git-comments-button{min-height:38px;padding:8px 14px;border:1px solid #5db3ff;border-radius:9px;background:#102541;color:#8dccff;font-weight:800;letter-spacing:.04em;cursor:pointer}.git-comments-button:hover{background:#17365d}.git-comments-button:disabled{opacity:.5;cursor:wait}.git-comments-button.export-html{display:inline-flex;align-items:center;justify-content:center;gap:12px;min-height:54px;padding:0 24px;border:1px solid #FFE6CB;border-radius:0;background:#0b1324;color:#FFE6CB;font-size:18px;letter-spacing:.08em}.git-comments-button.add-toggle{border-color:#FFE6CB;background:#35291f;color:#FFE6CB}.git-comments-button.submit-add{border-color:#4ade80;background:#123c2b;color:#b7f7cc}.git-comments-button.cancel-add{border-color:#ef4444;background:#4a151b;color:#fecaca}.git-comments-button.archive{margin-left:auto;border-color:#22d3ee;background:#083344;color:#cffafe}.git-comments-button.delete{border-color:#ef4444;background:#4a151b;color:#fecaca}.git-comments-button.delete:hover{background:#651d24}.git-comments-button.view-archived{min-height:32px;padding:5px 11px;border-color:#facc15;background:#332b0b;color:#fef08a;font-size:12px}.git-comments-button.restore,.git-comments-button.unarchive{border-color:#94a3b8;background:#172033;color:#dbe5f4}.git-comments-add-form{width:100%;margin-top:12px;flex-wrap:wrap}.git-comments-panel-heading{justify-content:space-between;flex-wrap:wrap;border-bottom:1px solid #334155}.git-comments-panel-heading .git-comments-panel-title{flex:1 1 auto;border-bottom:0}.git-comments-panel-heading .add-toggle{flex:0 0 auto;margin-right:28px}.git-comments-panel-add{padding:0 28px 18px}.git-comments-input{flex:1 1 500px;min-height:42px;padding:9px 12px;border:1px solid #475569;border-radius:9px;background:#09111e;color:#f0f6fc;font:inherit}.git-comments-error{width:100%;color:#fca5a5}.git-comments-success{position:fixed;left:50%;top:50%;z-index:1100;width:max-content;min-width:min(589.7103px,calc(100vw - 70.3257px));max-width:calc(100vw - 70.3257px);min-height:min(245.1429px,calc(100vh - 70.3257px));box-sizing:border-box;transform:translate(-50%,-50%);display:flex;align-items:center;justify-content:center;margin:0;padding:83.5714px 70.3257px;border:1px solid rgba(187,247,208,.9);border-radius:25px;background:rgba(18,60,43,.95);color:rgba(255,255,255,.9);font-family:"Alumni Sans SC",sans-serif;font-size:48.43px;line-height:1.25;font-weight:800;text-align:center;white-space:nowrap;overflow-x:auto;overflow-y:hidden;box-shadow:0 15.6px 41.6px rgba(0,0,0,.6),0 5.2px 15.6px rgba(0,0,0,.36),0 0 14px rgba(134,239,172,.22),inset 0 1px 0 rgba(255,255,255,.16);backdrop-filter:blur(5.2px);opacity:1;transition:opacity .5s ease}.git-comments-success.cyan{border-color:rgba(165,243,252,.9);background:rgba(8,51,68,.95);color:rgba(255,255,255,.9);box-shadow:0 15.6px 41.6px rgba(0,0,0,.6),0 5.2px 15.6px rgba(0,0,0,.36),0 0 14px rgba(103,232,249,.22),inset 0 1px 0 rgba(255,255,255,.16)}.git-comments-success.red{border-color:rgba(254,202,202,.9);background:rgba(74,21,27,.95);color:rgba(255,255,255,.9);box-shadow:0 15.6px 41.6px rgba(0,0,0,.6),0 5.2px 15.6px rgba(0,0,0,.36),0 0 14px rgba(252,165,165,.22),inset 0 1px 0 rgba(255,255,255,.16)}.git-comments-success.fading{opacity:0;pointer-events:none}.git-comments-panel-title{padding:22px 28px;border-bottom:1px solid #334155;font-size:22px;font-weight:750}.git-comments-issue{margin:18px 28px;border:1px solid #334155;border-radius:16px;overflow:hidden;background:#101b30}.git-comments-issue.received{border-color:#4ade80;box-shadow:0 0 0 2px rgba(74,222,128,.24)}.git-comments-issue-head{display:flex;align-items:flex-start;gap:12px;padding:15px 18px;border-bottom:1px solid #334155;flex-wrap:wrap}.git-comments-issue-content{display:flex;align-items:flex-start;gap:12px;flex:1 1 720px;min-width:0}.git-comments-card-icon{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;flex:0 0 32px;line-height:1;font-size:22px}.git-comments-issue-identity{display:grid;gap:10px;flex:1 1 auto;min-width:0}.git-comments-issue-main,.git-comments-issue-meta,.git-comments-issue-context-meta{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.git-comments-issue-title{display:block;color:#FFE6CB;font-size:24px;font-weight:850;line-height:1.35;text-decoration:none}.git-comments-issue-title:hover{text-decoration:underline;text-underline-offset:3px}.git-comments-at-a-glance{margin-top:10px;color:#22d3ee;font-size:16px;line-height:1.45;font-weight:650}.git-comments-at-a-glance strong{font-weight:850;letter-spacing:.06em}.git-comments-issue-context-meta{display:flex;align-items:center;gap:12px;flex-wrap:nowrap;overflow-x:auto;color:#9ca9bd;font-size:14.95px}.git-comments-status-cluster{display:flex;align-items:center;gap:12px;flex:0 0 auto;white-space:nowrap}.git-comments-status-text{display:flex;align-items:center;min-height:44px;gap:12px;flex-wrap:nowrap;white-space:nowrap}.git-comments-current-state,.git-comments-comment-label{display:inline-flex;align-items:center;justify-content:center;min-width:200px;width:auto;min-height:44px;box-sizing:border-box;padding:6.25px 16px;border-radius:999px;white-space:nowrap;flex:0 0 auto;font-size:15px;font-weight:850;letter-spacing:.08em}.git-comments-current-state,.git-comments-comment-label{border:1px solid #64748b}.git-comments-comment-label.open{border-color:#4ade80;color:#fff;background:#166534}.git-comments-comment-label.closed{border-color:#ef4444;color:#fff;background:#7f1d1d}.git-comments-comment-label.merged{border-color:#a78bfa;color:#fff;background:#5b21b6}.git-comments-current-state.open{border-color:#4ade80;color:#d1fae5;background:rgba(22,101,52,.25)}.git-comments-current-state.closed{border-color:#ef4444;color:#fecaca;background:rgba(127,29,29,.25)}.git-comments-current-state.merged{border-color:#a78bfa;color:#e9d5ff;background:rgba(91,33,182,.25)}.git-comments-issue-description{padding:16px 18px;border-bottom:1px solid #334155;background:#0d1728;color:#c4cce0;line-height:1.55;white-space:pre-wrap;overflow-wrap:anywhere;max-height:260px;overflow:auto}.git-comments-status{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#9ca9bd}.git-comments-status.received{color:#4ade80;font-weight:800}.git-comments-comments{display:grid;gap:12px;padding:14px}.git-comments-comment-label{text-decoration:none}.git-comments-comment{padding:16px;border:1px solid rgba(255,255,255,.09);border-radius:13px;background:#17213b}.git-comments-comment.maintainer{border-color:rgba(74,222,128,.55)}.git-comments-author{display:flex;gap:10px;align-items:center;font-weight:750}.git-comments-avatar{width:32px;height:32px;border-radius:50%}.git-comments-time{font-weight:400;color:#9ca9bd;font-size:13px}.git-comments-association{margin-left:auto;padding:3px 9px;border:1px solid #64748b;border-radius:999px;color:#cbd5e1;font-size:11px;font-weight:750}.git-comments-body{white-space:pre-wrap;overflow-wrap:anywhere;margin-top:12px;color:#c4cce0;line-height:1.55}.git-comments-empty{padding:18px;color:#9ca9bd}.git-comments-button.activity-toggle{margin:0 14px 14px;border-color:#64748b;background:#172033;color:#dbe5f4}.git-comments-events{display:grid;gap:10px;padding:4px 14px 16px}.git-comments-event{display:flex;align-items:center;gap:10px;padding:10px 12px;border-left:3px solid #64748b;background:#0c1624;color:#c4cce0;flex-wrap:wrap}.git-comments-event-avatar{width:24px;height:24px;border-radius:50%}.git-comments-event strong{color:#f0f6fc}.git-comments-event-label{display:inline-flex;align-items:center;padding:4px 10px;border:1px solid currentColor;border-radius:999px;background:#2b250d;color:#facc15;font-weight:800}.git-comments-archived{display:grid;gap:10px;padding:16px 28px}.git-comments-archived-row{display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border:1px solid #334155;background:#0b1422;flex-wrap:wrap}.git-comments-archived-content{display:grid;gap:0;flex:1 1 560px;min-width:0}.git-comments-archived-primary{display:flex;align-items:center;gap:12px;flex-wrap:nowrap;overflow-x:auto}.git-comments-archived-primary>*{flex:0 0 auto}.git-comments-archived-primary .git-comments-time,.git-comments-archived-primary .git-comments-repo-primary{white-space:nowrap}
.git-comments-archived-actions{display:flex;align-items:center;gap:12px;margin-left:auto;flex:0 0 auto}.git-comments-archived-actions .git-comments-button{min-height:32px;height:32px;padding:5px 11px;font-size:12px}.git-comments-archived-summary{margin-top:7px;color:#22d3ee;font-size:15.6px;line-height:1.35;font-weight:650}.git-comments-archived-row .restore{margin-left:auto}.git-comments-archive-backdrop{position:fixed;inset:0;z-index:1000;display:flex;align-items:center;justify-content:center;padding:32px;background:rgba(2,6,23,.82)}.git-comments-archive-modal{width:min(960px,calc(100vw - 64px));max-height:calc(100vh - 64px);overflow:auto;border:1px solid #64748b;background:#0c1624;box-shadow:0 24px 80px rgba(0,0,0,.62);color:#f0f6fc}.git-comments-archive-modal-head{position:sticky;top:0;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:20px;padding:18px 22px;border-bottom:1px solid #334155;background:#0c1624}.git-comments-archive-modal-title{font-size:22px;font-weight:850;color:#FFE6CB}.git-comments-button.close-archive-view{border-color:#ef4444;background:#4a151b;color:#fecaca}.git-comments-archive-modal-body{display:grid;gap:16px;padding:22px}.git-comments-archive-readonly{color:#facc15;font-size:12px;font-weight:800;letter-spacing:.12em}.git-comments-archive-description{white-space:pre-wrap;overflow-wrap:anywhere;color:#cbd5e1;line-height:1.6}.git-comments-archive-labels{display:flex;gap:8px;flex-wrap:wrap}.git-comments-archive-label{padding:4px 9px;border:1px solid currentColor;border-radius:999px;font-size:12px;font-weight:750}.git-comments-archive-comment{padding:14px;border:1px solid #334155;background:#111d31}.git-comments-archive-comment-body{margin-top:8px;white-space:pre-wrap;overflow-wrap:anywhere;color:#cbd5e1;line-height:1.55}
`;

  function fmt(value) { if (!value) return "Never"; const d = new Date(value); return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString(); }
  function authorName(comment) { return comment.author?.login || comment.user?.login || comment.user || comment.author || "unknown"; }
  function avatar(comment) { return comment.author?.avatar_url || comment.user?.avatar_url || comment.avatar_url || ""; }
  function associationLabel(comment) { const value = String(comment.author_association || "").replaceAll("_", " ").trim(); return !value || value === "NONE" ? "" : value.toLowerCase().replace(/\b\w/g, (letter) => letter.toUpperCase()); }
  function archivedViewLabel(entry, hydratedIssue) {
    const kind = String(entry?.kind || hydratedIssue?.kind || "").toLowerCase();
    const isPull = kind === "pull" || /\/pull\/\d+/i.test(String(entry?.url || "")) || Boolean(hydratedIssue?.pull_request);
    return isPull ? "VIEW PR" : "VIEW ISSUE";
  }
  function eventActor(item) { return item.actor?.login || "unknown"; }
  function eventText(item) { if (item.event === "opened") return "opened this"; if (item.event === "closed") return `closed this as ${String(item.state_reason || "completed").replaceAll("_", " ")}`; if (item.event === "reopened") return "reopened this"; if (item.event === "labeled") return "added"; if (item.event === "unlabeled") return "removed"; return item.event || "updated this"; }
  function githubColor(value, fallback = "64748b") { const color = String(value || fallback).replace(/[^0-9a-f]/gi, "").slice(0, 6); return color.length === 6 ? `#${color}` : `#${fallback}`; }
  function labelColor(item) { return githubColor(item.label?.color, "facc15"); }
  function watchIdFromUrl(value) { try { const parsed = new URL(String(value || "").trim()); const parts = parsed.pathname.split("/").filter(Boolean); if (parsed.hostname.toLowerCase() !== "github.com" || parts.length !== 4 || !["issues", "pull"].includes(parts[2]) || !/^\d+$/.test(parts[3])) return ""; return `${parts[0]}/${parts[1]}/${parts[2]}/${Number(parts[3])}`.toLowerCase(); } catch (_) { return ""; } }
  function duplicateWatchId(value, active, archived) { const id = watchIdFromUrl(value); return Boolean(id && [...active, ...archived].some((entry) => String(entry.id || "").toLowerCase() === id)); }
  function issueStatus(issue) { if (issue?.merged === true || issue?.merged_at) return "merged"; return String(issue?.state || "open").toLowerCase() === "closed" ? "closed" : "open"; }
  function DownloadIcon() { return e("svg", { viewBox: "0 0 24 24", width: 24, height: 24, fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true" }, e("path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }), e("path", { d: "m7 10 5 5 5-5" }), e("path", { d: "M12 15V3" })); }
  function exportStandaloneHtml() {
    const currentPage = window.document.querySelector(".git-comments-page");
    if (!currentPage) return;

    // Clone the live rendered subtree so exported HTML matches the visible dashboard exactly.
    const snapshot = currentPage.cloneNode(true);

    // Remove only controls that need the unavailable Hermes backend, plus transient notices.
    snapshot.querySelectorAll(".git-comments-panel-add,.git-comments-success,.git-comments-error,.git-comments-button.add-toggle,.git-comments-button.archive,.git-comments-button.delete,.git-comments-button.restore,.git-comments-button.unarchive,.git-comments-button.view-archived,.git-comments-button.retry-connection,.git-comments-button.export-html").forEach((node) => node.remove());

    const exportedAt = new Date();
    const exportGuide = `<!-- GIT WATCH OFFLINE FILE GUIDE

PURPOSE
  This is one shareable HTML file containing the exact dashboard snapshot,
  all dashboard CSS, and all JavaScript behavior that can run without Hermes.

WHERE TO EDIT
  HTML: search for EXACT RENDERED DASHBOARD SNAPSHOT.
  CSS: search for DASHBOARD CSS. Class names begin with .git-comments-.
  JavaScript: search for GIT WATCH OFFLINE CONTROLLER.

API-DEPENDENT CONTROLS OMITTED
  Add, Archive, Delete, Unarchive, Retry Connection, API-backed archive View,
  and Export require the live Hermes plugin backend. They are intentionally
  removed instead of being left as broken offline buttons. Canonical GitHub
  links, retained activity disclosure, and an already-open archive viewer work.

SUCCESS POPUP TOKENS (Revision 50)
  selector: .git-comments-success
  font: embedded Alumni Sans SC ExtraBold 800
  border radius: 25px
  minimum width: 589.7103px
  minimum height: 245.1429px
  padding: 83.5714px 70.3257px
  text size: 48.43px
  background fill alpha: 95%
  dwell: 3000ms, then fade: 500ms
  live-only sound: embedded two-note C5/E5 success chime
  Popup elements are transient and therefore omitted from the snapshot, but
  their complete green, cyan, and red styling remains in DASHBOARD CSS.

SAFETY AND PORTABILITY
  No external stylesheet, external script, credential, or Hermes API call is
  embedded. Image and canonical GitHub link URLs may still load from GitHub.
-->`;
    const exportShellStyles = `/* EXPORT SHELL:
   These rules style only the standalone document background and export banner.
   They do not replace or modify dashboard component styling. */
html{background:#07101d}
body{margin:0;background:#07101d;color:#f0f6fc;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.git-comments-export-note{margin:20px 24px 0;padding:12px 16px;border:1px solid #475569;border-radius:10px;background:#0c1624;color:#cbd5e1;font-size:14px}

/* DASHBOARD CSS: byte-identical to the live Revision 50 renderer begins below.
   Edit .git-comments-* selectors to customize the offline copy. */
`;
    const inlineScript = `/* GIT WATCH OFFLINE CONTROLLER
   This controller uses only this document. It performs no network or API calls. */
(function () {
  /* 1. Harden every exported link opened in another browser context. */
  document.querySelectorAll("a").forEach(function (link) {
    link.setAttribute("rel", "noreferrer noopener");
  });

  /* 2. Preserve activity disclosure when its rendered timeline exists. */
  document.querySelectorAll(".git-comments-button.activity-toggle").forEach(function (button) {
    var region = document.getElementById(button.getAttribute("aria-controls"));
    if (!region) {
      button.remove();
      return;
    }
    function sync(expanded) {
      var count = (button.textContent.match(/\\((\\d+)\\)/) || ["", "0"])[1];
      button.setAttribute("aria-expanded", String(expanded));
      region.hidden = !expanded;
      button.textContent = (expanded ? "HIDE ACTIVITY" : "SHOW ACTIVITY") + " (" + count + ")";
    }
    sync(button.getAttribute("aria-expanded") === "true");
    button.addEventListener("click", function () {
      sync(button.getAttribute("aria-expanded") !== "true");
    });
  });

  /* 3. Close an exported archive viewer by button, backdrop, or Escape. */
  var modal = document.querySelector(".git-comments-archive-modal");
  if (modal) {
    var backdrop = modal.closest(".git-comments-archive-backdrop");
    var closeButton = modal.querySelector(".git-comments-button.close-archive-view");
    function closeModal() {
      if (backdrop) backdrop.remove();
      else modal.remove();
    }
    if (closeButton) closeButton.addEventListener("click", closeModal);
    if (backdrop) backdrop.addEventListener("click", function (event) {
      if (event.target === backdrop) closeModal();
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") closeModal();
    });
  }

  /* 4. Publish a ready marker for readers, tests, and future offline edits. */
  document.documentElement.dataset.gitCommentsExport = "ready";
})();`;
    const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="git-watch-export-version" content="50">
  <meta name="git-watch-visual-baseline" content="50">
  <title>GIT WATCH Export</title>
  <style>${exportShellStyles}${styles}</style>
</head>
<body>
${exportGuide}
  <div class="git-comments-export-note"><strong>GIT WATCH Export</strong> · Snapshot exported ${exportedAt.toISOString()} · Export format 49 · Visual baseline 49</div>

<!-- EXACT RENDERED DASHBOARD SNAPSHOT: edit this region to change offline content. -->
${snapshot.outerHTML}
<!-- END EXACT RENDERED DASHBOARD SNAPSHOT -->

<script>${inlineScript}<\/script>
</body></html>`;
    const blob = new window.Blob([html], { type: "text/html;charset=utf-8" });
    const href = window.URL.createObjectURL(blob);
    const link = window.document.createElement("a");
    link.href = href;
    link.download = `git-watch-${exportedAt.toISOString().slice(0, 10)}.html`;
    link.click();
    window.URL.revokeObjectURL(href);
  }

  function Issue({ issue, owner, onArchive, onDelete, busy }) {
    const comments = Array.isArray(issue.comments) ? issue.comments : [];
    const statusEvents = Array.isArray(issue.status_events) ? issue.status_events : [];
    const importantEventTypes = new Set(["opened", "closed", "reopened", "labeled", "unlabeled"]);
    const visibleStatusEvents = statusEvents.filter((item) => importantEventTypes.has(item.event));
    const [activityOpen, setActivityOpen] = useState(false);
    const activityId = `git-comments-activity-${String(issue.watch_id || issue.number || "item").replace(/[^a-z0-9_-]/gi, "-")}`;
    const received = comments.filter((comment) => authorName(comment).toLowerCase() !== owner.toLowerCase());
    const hasReceived = received.length > 0 || Number(issue.new_received_count || 0) > 0;
    const number = issue.number || issue.issue_number;
    const url = issue.html_url || issue.url;
    const sourceComment = received[received.length - 1];
    const sourceCommentUrl = sourceComment?.html_url || sourceComment?.url || url;
    const issueAuthor = issue.author?.login || "unknown";
    const isProfileOwner = issueAuthor.toLowerCase() === String(owner || "").toLowerCase();
    const status = issueStatus(issue);
    const currentState = status.toUpperCase();
    return e("section", { className: `git-comments-issue${hasReceived ? " received" : ""}` },
      e("div", { className: "git-comments-issue-head" },
        e("div", { className: "git-comments-issue-content" }, e("span", { className: "git-comments-card-icon", "aria-hidden": "true" }, "💬"), e("div", { className: "git-comments-issue-identity" },
          e("div", { className: "git-comments-issue-main" }, e("a", { className: "git-comments-number-link", href: url, target: "_blank", rel: "noreferrer", "aria-label": `Open ${issue.repo || "GitHub"} #${number} on GitHub` }, `#${number}`), e("span", { className: "git-comments-issue-author" }, `by ${issueAuthor}`), issue.author?.avatar_url ? e("img", { className: "git-comments-issue-avatar", src: issue.author.avatar_url, alt: `${issueAuthor} profile picture` }) : null, issue.author?.avatar_url && isProfileOwner ? e("span", { className: "git-comments-owner-star", role: "img", "aria-label": "Watchlist profile owner", title: "Watchlist profile owner" }, "★") : null),
          e("div", { className: "git-comments-repo-line" }, e("strong", { className: "git-comments-repo-primary" }, issue.repo || "GitHub"), e("span", { className: `git-comments-watch-state ${status}` }, "WATCHING")),
          issue.title ? e("a", { className: "git-comments-issue-title", href: url, target: "_blank", rel: "noreferrer" }, issue.title) : null,
          issue.at_a_glance ? e("div", { className: "git-comments-at-a-glance" }, e("strong", null, "AT A GLANCE:"), " ", issue.at_a_glance) : null,
          e("div", { className: "git-comments-issue-context-meta" }, sourceCommentUrl ? e("a", { className: `git-comments-comment-label ${status}`, href: sourceCommentUrl, target: "_blank", rel: "noreferrer" }, `COMMENTS (${received.length})`) : null, e("div", { className: "git-comments-status-cluster" }, e("span", { className: `git-comments-current-state ${status}` }, `STATUS: ${currentState}`), e("div", { className: "git-comments-status-text" }, e("span", null, `Opened by ${issueAuthor}`), e("span", null, `Created ${fmt(issue.created_at)}`), e("span", null, `Updated ${fmt(issue.updated_at)}`))))
        )),
        e("button", { className: "git-comments-button archive", type: "button", disabled: busy, title: "Archive and stop watching this URL", "aria-label": `Archive ${issue.repo || "GitHub"} #${number}`, onClick: () => onArchive(issue) }, "ARCHIVE"),
        e("button", { className: "git-comments-button delete", type: "button", disabled: busy, title: "Permanently delete and stop watching this URL", "aria-label": `Delete ${issue.repo || "GitHub"} #${number}`, onClick: () => onDelete(issue.watch_id) }, "DELETE")
      ),
      issue.body ? e("div", { className: "git-comments-issue-description" }, issue.body) : null,
      comments.length ? e("div", { className: "git-comments-comments" }, comments.map((comment) => {
        const fromMaintainer = authorName(comment).toLowerCase() !== owner.toLowerCase(); const association = associationLabel(comment);
        return e("article", { key: comment.id || `${authorName(comment)}-${comment.created_at}`, className: `git-comments-comment${fromMaintainer ? " maintainer" : ""}` },
          e("div", { className: "git-comments-author" }, avatar(comment) ? e("img", { className: "git-comments-avatar", src: avatar(comment), alt: "" }) : null, e("span", null, authorName(comment)), e("span", { className: "git-comments-time" }, fmt(comment.created_at)), association ? e("span", { className: "git-comments-association" }, association) : null),
          e("div", { className: "git-comments-body" }, comment.body || "")
        );
      })) : e("div", { className: "git-comments-empty" }, issue.pending ? "Waiting for the first successful GitHub check." : "No comments yet."),
      visibleStatusEvents.length ? [
        e("button", { key: "activity-control", className: "git-comments-button activity-toggle", type: "button", "aria-expanded": activityOpen, "aria-controls": activityId, onClick: () => setActivityOpen((open) => !open) }, `${activityOpen ? "HIDE ACTIVITY" : "SHOW ACTIVITY"} (${visibleStatusEvents.length})`),
        activityOpen ? e("div", { key: "activity-events", id: activityId, className: "git-comments-events", "aria-label": "Important GitHub status timeline" }, visibleStatusEvents.map((item) => e("div", { key: item.id || `${item.event}-${item.created_at}`, className: "git-comments-event" }, item.actor?.avatar_url ? e("img", { className: "git-comments-event-avatar", src: item.actor.avatar_url, alt: "" }) : null, e("span", null, e("strong", null, eventActor(item)), ` ${eventText(item)}`), item.label?.name ? e("span", { className: "git-comments-event-label", style: { color: labelColor(item) } }, item.label.name) : null, e("span", { className: "git-comments-time" }, fmt(item.created_at))))) : null
      ] : null
    );
  }

  function ArchivedViewModal({ view, onClose }) {
    const issue = view?.issue;
    const comments = Array.isArray(issue?.comments) ? issue.comments : [];
    const labels = Array.isArray(issue?.labels) ? issue.labels : [];
    const status = issue ? issueStatus(issue).toUpperCase() : "";
    return e("div", { className: "git-comments-archive-backdrop", onMouseDown: (event) => { if (event.target === event.currentTarget) onClose(); } },
      e("section", { className: "git-comments-archive-modal", role: "dialog", "aria-modal": "true", "aria-labelledby": "git-comments-archive-modal-title", tabIndex: -1 },
        e("div", { className: "git-comments-archive-modal-head" }, e("div", { id: "git-comments-archive-modal-title", className: "git-comments-archive-modal-title" }, view?.entry ? `${view.entry.repo} #${view.entry.number}` : "Archived GitHub item"), e("button", { className: "git-comments-button close-archive-view", type: "button", onClick: onClose }, "CLOSE")),
        e("div", { className: "git-comments-archive-modal-body" },
          e("div", { className: "git-comments-archive-readonly" }, "READ ONLY ARCHIVED ITEM"),
          view?.loading ? e("div", { className: "git-comments-muted" }, "Loading archived item…") : null,
          view?.error ? e("div", { className: "git-comments-error", role: "alert" }, view.error) : null,
          issue ? e(React.Fragment, null,
            e("a", { className: "git-comments-archive-modal-title", href: issue.html_url, target: "_blank", rel: "noreferrer" }, issue.title || `${issue.repo} #${issue.number}`),
            e("div", { className: "git-comments-muted" }, `STATUS: ${status} · Opened by ${issue.author?.login || "unknown"} · Created ${fmt(issue.created_at)} · Updated ${fmt(issue.updated_at)}`),
            labels.length ? e("div", { className: "git-comments-archive-labels" }, labels.map((label) => e("span", { key: label.name, className: "git-comments-archive-label", style: { color: githubColor(label.color, "facc15") } }, label.name))) : null,
            e("div", { className: "git-comments-archive-description" }, issue.body || "No description provided."),
            e("div", { className: "git-comments-kicker" }, `COMMENTS (${comments.length})`),
            comments.length ? comments.map((comment) => e("article", { key: comment.id || `${authorName(comment)}-${comment.created_at}`, className: "git-comments-archive-comment" }, e("div", { className: "git-comments-author" }, avatar(comment) ? e("img", { className: "git-comments-avatar", src: avatar(comment), alt: "" }) : null, e("span", null, authorName(comment)), e("span", { className: "git-comments-time" }, fmt(comment.created_at))), e("div", { className: "git-comments-archive-comment-body" }, comment.body || ""))) : e("div", { className: "git-comments-muted" }, "No comments.")
          ) : null
        )
      )
    );
  }

  function GitCommentsPage() {
    const [state, setState] = useState({ loading: true, data: null, error: null });
    const [addOpen, setAddOpen] = useState(false); const [url, setUrl] = useState(""); const [busy, setBusy] = useState(false); const [actionError, setActionError] = useState(""); const [actionSuccess, setActionSuccess] = useState(""); const [successTone, setSuccessTone] = useState("green"); const [successDuration, setSuccessDuration] = useState(0); const [successFading, setSuccessFading] = useState(false); const [successVersion, setSuccessVersion] = useState(0); const [archiveView, setArchiveView] = useState(null); const [archiveViewReturnFocus, setArchiveViewReturnFocus] = useState(null); const [archiveHydration, setArchiveHydration] = useState({});
    const load = () => fetchJSON(`${API}/data`).then((data) => setState({ loading: false, data, error: null })).catch((error) => setState({ loading: false, data: null, error: String(error) }));
    useEffect(() => { let alive = true; fetchJSON(`${API}/data`).then((data) => alive && setState({ loading: false, data, error: null })).catch((error) => alive && setState({ loading: false, data: null, error: String(error) })); return () => { alive = false; }; }, []);
    const mutate = async (path, payload) => { setBusy(true); setActionError(""); try { const data = await fetchJSON(`${API}${path}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }); setState({ loading: false, data, error: null }); return true; } catch (error) { setActionError(String(error)); await load(); return false; } finally { setBusy(false); } };
    const data = state.data || {}; const issues = Array.isArray(data.issues) ? data.issues : []; const watchlist = data.watchlist || { active: [], archived: [] }; const active = Array.isArray(watchlist.active) ? watchlist.active : []; const archived = Array.isArray(watchlist.archived) ? watchlist.archived : []; const owner = data.comment_owner || watchlist.comment_owner || ""; const health = data.watcher_health || {}; const watcherHealthy = health.ok === true && health.stale !== true && health.status === "healthy";
    const archiveHydrationKey = archived.map((entry) => `${entry.id}:${entry.snapshot ? "snapshot" : "legacy"}`).join("|");
    useEffect(() => {
      const pending = archived.filter((entry) => !entry.snapshot && !Object.prototype.hasOwnProperty.call(archiveHydration, entry.id));
      if (!pending.length) return undefined;
      let alive = true;
      Promise.all(pending.map(async (entry) => {
        try {
          const viewed = await fetchJSON(`${API}/watchlist/view-archived`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: entry.id }) });
          return [entry.id, viewed?.issue || null];
        } catch (_error) { return [entry.id, null]; }
      })).then((entries) => {
        if (!alive) return;
        setArchiveHydration((current) => ({ ...current, ...Object.fromEntries(entries) }));
      });
      return () => { alive = false; };
    }, [archiveHydrationKey, archiveHydration]);
    const displayedIssues = useMemo(() => {
      const byId = new Map(issues.map((issue) => [issue.watch_id, issue]));
      return active.map((entry) => {
        const liveIssue = byId.get(entry.id);
        const presentation = entry.presentation || {};
        if (!liveIssue && !Object.keys(presentation).length) return { ...entry, watch_id: entry.id, pending: true, comments: [], status_events: [] };
        return {
          ...presentation,
          ...(liveIssue || {}),
          watch_id: entry.id,
          repo: liveIssue?.repo || presentation.repo || entry.repo,
          number: liveIssue?.number || presentation.number || entry.number,
          kind: liveIssue?.kind || presentation.kind || entry.kind,
          html_url: liveIssue?.html_url || presentation.html_url || entry.url,
          at_a_glance: presentation.at_a_glance || liveIssue?.at_a_glance || "",
          pending: false,
        };
      });
    }, [issues, active]);
    const commented = useMemo(() => displayedIssues.filter((issue) => (issue.comments || []).some((comment) => authorName(comment).toLowerCase() !== owner.toLowerCase())).length, [displayedIssues, owner]);
    const closeAddForm = () => { setUrl(""); setActionError(""); setAddOpen(false); };
    useEffect(() => { window.addEventListener("pointerdown", unlockSuccessChime, { capture: true }); window.addEventListener("keydown", unlockSuccessChime, { capture: true }); return () => { window.removeEventListener("pointerdown", unlockSuccessChime, { capture: true }); window.removeEventListener("keydown", unlockSuccessChime, { capture: true }); }; }, []);
    const showSuccess = (message, duration, tone = "green") => { playSuccessChime(); setSuccessFading(false); setSuccessTone(tone); setSuccessDuration(duration); setActionSuccess(message); setSuccessVersion((version) => version + 1); };
    const retryConnection = async () => { setBusy(true); setActionError(""); setActionSuccess(""); try { const refreshed = await fetchJSON(`${API}/refresh`, { method: "POST" }); setState({ loading: false, data: refreshed, error: null }); if (refreshed?.refresh?.ok === true) showSuccess("CONNECTION RESTORED!", 3000, "green"); else setActionError(refreshed?.refresh?.error || refreshed?.watcher_health?.error || "Connection retry failed."); } catch (error) { setActionError(String(error)); await load(); } finally { setBusy(false); } };
    useEffect(() => { if (!actionSuccess || !successDuration) return undefined; const fadeTimer = window.setTimeout(() => setSuccessFading(true), successDuration); const removeTimer = window.setTimeout(() => setActionSuccess(""), successDuration + 500); return () => { window.clearTimeout(fadeTimer); window.clearTimeout(removeTimer); }; }, [actionSuccess, successDuration, successVersion]);
    const addUrl = async (event) => { event.preventDefault(); setActionSuccess(""); if (duplicateWatchId(url, active, archived)) { setActionError("This GitHub URL is already in the active or archived watchlist."); return; } if (await mutate("/watchlist/add", { url })) { closeAddForm(); showSuccess("URL ADDED SUCCESSFULLY!", 3000); } };
    const addFormKeyDown = (event) => { if (event.key === "Escape") { event.preventDefault(); closeAddForm(); return; } if (event.key === "Enter" && String(event.target?.tagName || "").toUpperCase() === "INPUT") { event.preventDefault(); event.currentTarget.requestSubmit(); } };
    useEffect(() => { const launchAddOnEnter = (event) => { if (event.key !== "Enter" || addOpen || busy || state.loading || archiveView || event.defaultPrevented || event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return; const target = event.target; if (target && typeof target.closest === "function" && target.closest("a,button,input,textarea,select,[contenteditable=true]")) return; event.preventDefault(); setActionSuccess(""); setActionError(""); setAddOpen(true); }; window.addEventListener("keydown", launchAddOnEnter); return () => window.removeEventListener("keydown", launchAddOnEnter); }, [addOpen, busy, state.loading, archiveView]);
    const closeArchiveView = () => { setArchiveView(null); const returnFocus = archiveViewReturnFocus; Promise.resolve().then(() => { if (returnFocus && typeof returnFocus.focus === "function") returnFocus.focus(); }); };
    const openArchiveView = async (entry, event) => { setArchiveViewReturnFocus(event?.currentTarget || null); setArchiveView({ loading: true, entry }); try { const viewed = await fetchJSON(`${API}/watchlist/view-archived`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: entry.id }) }); setArchiveHydration((current) => ({ ...current, [entry.id]: viewed?.issue || null })); setArchiveView({ ...viewed, loading: false, entry }); } catch (error) { setArchiveView({ loading: false, error: String(error), entry }); } };
    useEffect(() => { if (!archiveView) return undefined; const closeArchiveViewOnEscape = (event) => { if (event.key !== "Escape") return; event.preventDefault(); event.stopImmediatePropagation(); closeArchiveView(); }; window.addEventListener("keydown", closeArchiveViewOnEscape, true); const closeButton = window.document.querySelector(".git-comments-button.close-archive-view"); if (closeButton && typeof closeButton.focus === "function") closeButton.focus(); return () => window.removeEventListener("keydown", closeArchiveViewOnEscape, true); }, [archiveView, archiveViewReturnFocus]);
    const archive = async (issue) => { if (window.confirm("Archive this URL and stop watching it?") && await mutate("/watchlist/archive", { id: issue.watch_id, snapshot: issue })) showSuccess("URL SUCCESSFULLY ARCHIVED!", 3000, "cyan"); };
    const deleteWatch = async (id) => { if (window.confirm("Permanently delete this watched URL? This cannot be undone.") && await mutate("/watchlist/delete", { id })) showSuccess("SUCCESSFULLY DELETED!", 3000, "red"); };
    const unarchive = async (id) => { if (await mutate("/watchlist/restore", { id })) showSuccess("SUCCESSFULLY UNARCHIVED!", 3000, "green"); };
    const deleteArchived = async (id) => { if (window.confirm("Permanently delete this archived URL? This cannot be undone.") && await mutate("/watchlist/delete", { id })) showSuccess("SUCCESSFULLY DELETED!", 3000, "red"); };
    if (state.loading) return e("div", { className: "git-comments-page" }, "Loading GIT WATCH…"); if (state.error) return e("div", { className: "git-comments-page" }, `GIT WATCH failed: ${state.error}`);
    return e(React.Fragment, null, e("style", null, styles), e("div", { className: "git-comments-page" },
      e("section", { className: "git-comments-health" }, e("div", { className: "git-comments-health-top" }, e("div", { className: "git-comments-health-title" }, e("div", { className: "git-comments-kicker", style: { fontSize: "22.5px" } }, watcherHealthy ? "WATCHER HEALTHY" : "BROKEN"), e("span", { className: `git-comments-health-dot ${watcherHealthy ? "healthy" : "broken"}`, role: "img", "aria-label": watcherHealthy ? "Watcher status healthy" : "Watcher status broken", title: watcherHealthy ? "Watcher status healthy" : health.error || `Watcher status ${health.status || "unknown"}` })), e("div", { className: "git-comments-health-actions" }, !watcherHealthy ? e("button", { className: "git-comments-button retry-connection", type: "button", disabled: busy, onClick: retryConnection }, busy ? "RETRYING…" : "RETRY CONNECTION") : null, e("button", { className: "git-comments-button export-html", type: "button", onClick: exportStandaloneHtml, "aria-label": "Download HTML" }, e(DownloadIcon), "HTML"))), e("div", { className: "git-comments-muted" }, `Last successful check: ${fmt(data.checked_at || data.updated || health.checked_at)}`), !watcherHealthy && (actionError || health.error) ? e("div", { className: "git-comments-error", role: "alert" }, actionError || health.error) : null, e("div", { className: "git-comments-toolbar" }, e("div", { className: "git-comments-summary", style: { fontWeight: 400 } }, e("span", { className: "git-comments-summary-watching" }, `WATCHING (${active.length})`), " · ", e("span", { className: "git-comments-summary-commented", style: { color: "#4ade80" } }, `COMMENTED (${commented})`), " · ", e("span", { className: "git-comments-summary-archived", style: { color: "#22d3ee" } }, `ARCHIVED (${archived.length})`)))),
      e("section", { className: "git-comments-panel" }, e("div", { className: "git-comments-panel-heading" }, e("div", { className: "git-comments-panel-title", style: { fontSize: "26.4px", color: "#FFE6CB" } }, "*** WATCHED GITHUB ISSUES & PULL REQUESTS ***"), e("button", { className: "git-comments-button add-toggle", type: "button", disabled: busy, onClick: () => { if (addOpen) closeAddForm(); else { setActionSuccess(""); setAddOpen(true); } } }, "+ ADD URL TO WATCH")), addOpen ? e("div", { className: "git-comments-panel-add" }, e("form", { className: "git-comments-add-form", onSubmit: addUrl, onKeyDown: addFormKeyDown }, e("input", { className: "git-comments-input", type: "url", required: true, autoFocus: true, value: url, placeholder: "https://github.com/owner/repository/issues/123", onChange: (event) => setUrl(event.target.value), "aria-label": "GitHub issue or pull-request URL" }), e("button", { className: "git-comments-button submit-add", type: "submit", disabled: busy }, busy ? "CHECKING…" : "ADD URL"), e("button", { className: "git-comments-button cancel-add", type: "button", disabled: busy, onClick: closeAddForm }, "CANCEL")), actionError ? e("div", { className: "git-comments-error", role: "alert" }, actionError) : null) : null, actionSuccess ? e("div", { className: `git-comments-success ${successTone}${successFading ? " fading" : ""}`, role: "status", "aria-live": "polite" }, actionSuccess) : null, displayedIssues.length ? displayedIssues.map((issue) => e(Issue, { key: issue.watch_id, issue, owner, busy, onArchive: archive, onDelete: deleteWatch })) : e("div", { className: "git-comments-empty" }, "No active URLs. Add a GitHub issue or pull request to begin watching.")),
      e("section", { className: "git-comments-panel" }, e("div", { className: "git-comments-panel-title", style: { color: "#22d3ee" } }, `ARCHIVED (${archived.length})`), archived.length ? e("div", { className: "git-comments-archived" }, archived.map((entry) => { const hydratedIssue = entry.snapshot || archiveHydration[entry.id] || null; const summary = entry.presentation?.at_a_glance || entry.snapshot?.at_a_glance || hydratedIssue?.at_a_glance || ""; const summaryPending = !entry.snapshot && !Object.prototype.hasOwnProperty.call(archiveHydration, entry.id); const viewLabel = archivedViewLabel(entry, hydratedIssue); return e("div", { className: "git-comments-archived-row", key: entry.id }, e("div", { className: "git-comments-archived-content" }, e("div", { className: "git-comments-archived-primary" }, e("strong", { className: "git-comments-repo-primary" }, entry.repo), e("a", { className: "git-comments-number-link", href: entry.url, target: "_blank", rel: "noreferrer", "aria-label": `Open ${entry.repo} #${entry.number} on GitHub` }, `#${entry.number}`), e("span", { className: "git-comments-time" }, `Archived ${fmt(entry.archived_at)}`), e("button", { className: "git-comments-button view-archived", type: "button", disabled: busy, onClick: (event) => openArchiveView(entry, event), "aria-haspopup": "dialog" }, viewLabel)), summary ? e("div", { className: "git-comments-archived-summary" }, summary) : summaryPending ? e("div", { className: "git-comments-archived-summary" }, "Loading summary…") : null), e("div", { className: "git-comments-archived-actions" }, e("button", { className: "git-comments-button unarchive", type: "button", disabled: busy, onClick: () => unarchive(entry.id) }, "UNARCHIVE"), e("button", { className: "git-comments-button delete", type: "button", disabled: busy, onClick: () => deleteArchived(entry.id) }, "DELETE"))); })) : e("div", { className: "git-comments-empty" }, "No archived URLs.")),
      archiveView ? e(ArchivedViewModal, { view: archiveView, onClose: closeArchiveView }) : null
    ));
  }

  window.__HERMES_PLUGINS__.register("git-comments-v27-review", GitCommentsPage);
})();
