// One-time archive migration: convert preserved producer HTML into the same
// data-only contract consumed by the deterministic AI Brief renderer.
const fs = require("node:fs");
const path = require("node:path");
const { JSDOM } = require("jsdom");

const sourceRoot = process.argv[2];
const targetRoot = process.argv[3];
if (!sourceRoot || !targetRoot) {
  throw new Error("usage: node migrate-legacy-ai-archives.cjs <HTML directory> <JSON directory>");
}
fs.mkdirSync(targetRoot, { recursive: true });

const clean = (value) => value.replace(/\s+/g, " ").trim();
const withoutPrefix = (value, pattern) => clean(value.replace(pattern, ""));
function takeawayFromListItem(item) {
  const headlineNode = item.querySelector("strong");
  const headline = clean(headlineNode?.textContent || item.textContent.split(".")[0] + ".");
  const clone = item.cloneNode(true);
  clone.querySelector("strong")?.remove();
  const detail = clean(clone.textContent).replace(/^[-:–—]\s*/, "");
  return { headline, detail };
}
function sourceLinks(container) {
  return [...container.querySelectorAll("a[href^='https://']")].map((link) => ({
    label: clean(link.textContent),
    url: link.href,
  }));
}
function modernTopic(card, number) {
  const blocks = [...card.querySelectorAll(":scope > p")];
  const textFor = (label) => {
    const block = blocks.find((item) => clean(item.querySelector(".label")?.textContent || "").startsWith(label));
    if (!block) return "";
    const clone = block.cloneNode(true);
    clone.querySelector(".label")?.remove();
    return clean(clone.textContent);
  };
  const summary = textFor("Summary") || clean(blocks.find((item) => !item.classList.contains("sources"))?.textContent || "");
  return {
    number,
    headline: withoutPrefix(clean(card.querySelector("h2").textContent), /^\d+[.)]\s*/),
    summary,
    why_it_matters: textFor("Why it matters"),
    actionable_implication: textFor("Actionable implication"),
    sources: sourceLinks(card.querySelector(".sources") || card),
  };
}
function legacyTopic(section, number) {
  // Older five-topic briefs used unlabeled sections. Preserve each real block,
  // then map it to the stable summary / why / action JSON fields by its label.
  const blocks = [...section.children]
    .filter((node) => !["H2", "STYLE", "SCRIPT"].includes(node.tagName))
    .map((node) => clean(node.textContent))
    .filter((text) => text && !/^Sources?:/i.test(text));
  const summary = blocks[0];
  const whyIndex = blocks.findIndex((text) => /^Why it matters/i.test(text));
  const why = whyIndex >= 0 ? withoutPrefix(blocks[whyIndex], /^Why it matters(?: for operators)?:\s*/i) : blocks[1];
  const actionBlocks = blocks.filter((_, index) => index !== 0 && index !== whyIndex);
  const action = actionBlocks.map((text) => withoutPrefix(text, /^(?:Watch-outs|Action to take this week|Practical use|Founder move):\s*/i)).join(" ");
  return {
    number,
    headline: withoutPrefix(clean(section.querySelector("h2").textContent), /^\d+[.)]\s*/),
    summary,
    why_it_matters: why,
    actionable_implication: action,
    sources: sourceLinks(section),
  };
}

for (const filename of fs.readdirSync(sourceRoot).filter((name) => name.endsWith(".html")).sort()) {
  const date = filename.match(/(\d{4}-\d{2}-\d{2})/)?.[1];
  if (!date) continue;
  const document = new JSDOM(fs.readFileSync(path.join(sourceRoot, filename), "utf8")).window.document;
  const modernCards = [...document.querySelectorAll(".topics .card, article.topic")];
  const legacySections = [...document.querySelectorAll("section")].filter((section) => /^\d+[.)]\s/.test(clean(section.querySelector("h2")?.textContent || "")));
  const topicNodes = modernCards.length ? modernCards : legacySections;
  const takeaways = [...document.querySelectorAll(".takeaways li")];
  const takeawayNodes = takeaways.length ? takeaways : [...document.querySelectorAll("ol li")];
  const topics = topicNodes.map((node, index) => modernCards.length ? modernTopic(node, index + 1) : legacyTopic(node, index + 1));
  const payload = {
    contract_version: "ai-brief-data-v1",
    kind: "ai",
    date,
    timezone: "America/Los_Angeles",
    generated_at: `${date}T08:00:00-07:00`,
    founder_takeaways: takeawayNodes.slice(0, topics.length).map(takeawayFromListItem),
    topics,
  };
  fs.writeFileSync(path.join(targetRoot, `${date}.json`), JSON.stringify(payload, null, 2) + "\n");
  console.log(`${date}: ${payload.founder_takeaways.length} takeaways, ${topics.length} topics`);
}
