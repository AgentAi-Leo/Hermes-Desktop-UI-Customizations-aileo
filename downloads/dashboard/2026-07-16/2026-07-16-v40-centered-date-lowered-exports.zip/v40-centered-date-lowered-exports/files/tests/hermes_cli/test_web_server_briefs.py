"""Tests for the built-in AI and stock brief dashboard API."""

import os

import pytest
from starlette.testclient import TestClient

from hermes_cli import web_server


def _client():
    previous_auth = getattr(web_server.app.state, "auth_required", None)
    previous_host = getattr(web_server.app.state, "bound_host", None)
    web_server.app.state.auth_required = False
    web_server.app.state.bound_host = None
    client = TestClient(web_server.app)
    client.headers[web_server._SESSION_HEADER_NAME] = web_server._SESSION_TOKEN
    return client, previous_auth, previous_host


def _restore(client, previous_auth, previous_host):
    client.close()
    if previous_auth is None:
        if hasattr(web_server.app.state, "auth_required"):
            delattr(web_server.app.state, "auth_required")
    else:
        web_server.app.state.auth_required = previous_auth
    if previous_host is None:
        if hasattr(web_server.app.state, "bound_host"):
            delattr(web_server.app.state, "bound_host")
    else:
        web_server.app.state.bound_host = previous_host


@pytest.fixture
def briefs_client(monkeypatch, tmp_path):
    ai_root = tmp_path / "ai"
    stock_root = tmp_path / "stock"
    monkeypatch.setenv("HERMES_HOME", str(tmp_path / "hermes" / "profiles" / "test"))
    monkeypatch.setenv("HERMES_AI_BRIEFS_ROOT", str(ai_root))
    monkeypatch.setenv("HERMES_STOCK_BRIEFS_ROOT", str(stock_root))
    client, previous_auth, previous_host = _client()
    try:
        yield client, ai_root, stock_root
    finally:
        _restore(client, previous_auth, previous_host)


def _write_brief(root, date, stem):
    directory = root / date
    directory.mkdir(parents=True)
    html = directory / f"{stem} - {date}.html"
    markdown = directory / f"{stem} - {date}.md"
    html.write_text(f"<!doctype html><title>{stem}</title><h1>{date}</h1>")
    markdown.write_text(f"# {stem}\n\n{date}\n")
    return html, markdown


def _sandbox_brief_root(hermes_home, location, directory):
    sandbox = hermes_home / "sandboxes" / "docker" / "default"
    if location == "downloads":
        return sandbox / "home" / ".hermes" / "zDownloads" / directory
    return sandbox / location / directory


def test_empty_archive_returns_zero_items(briefs_client):
    client, ai_root, _ = briefs_client
    response = client.get("/api/briefs/ai")
    assert response.status_code == 200
    payload = response.json()
    assert payload["kind"] == "ai"
    assert payload["count"] == 0
    assert payload["briefs"] == []
    assert payload["root"] == str(ai_root.resolve())


def test_lists_ai_briefs_newest_first_and_ignores_invalid_directories(briefs_client):
    client, ai_root, _ = briefs_client
    _write_brief(ai_root, "2026-07-13", "AI Morning Brief")
    html, markdown = _write_brief(ai_root, "2026-07-14", "AI Morning Brief")
    os.utime(html, (1_700_000_000, 1_700_000_000))
    os.utime(markdown, (1_700_000_001, 1_700_000_001))
    (ai_root / "not-a-date").mkdir()

    response = client.get("/api/briefs/ai")
    assert response.status_code == 200
    payload = response.json()
    assert [item["date"] for item in payload["briefs"]] == ["2026-07-14", "2026-07-13"]
    assert payload["briefs"][0]["html_exists"] is True
    assert payload["briefs"][0]["markdown_exists"] is True
    assert payload["briefs"][0]["html_route"] == "/api/briefs/ai/html/2026-07-14"
    assert payload["briefs"][0]["generated_at"] == 1_700_000_001


def test_retains_only_five_newest_brief_dates_and_deletes_older_artifacts(briefs_client):
    client, ai_root, _ = briefs_client
    dates = [f"2026-07-{day:02d}" for day in range(10, 17)]
    for date in dates:
        _write_brief(ai_root, date, "AI Morning Brief")

    response = client.get("/api/briefs/ai")

    assert response.status_code == 200
    assert [item["date"] for item in response.json()["briefs"]] == list(reversed(dates[-5:]))
    assert not (ai_root / dates[0]).exists()
    assert not (ai_root / dates[1]).exists()
    assert (ai_root / dates[2]).is_dir()


def test_lists_stock_brief_with_expected_filename(briefs_client):
    client, _, stock_root = briefs_client
    _write_brief(stock_root, "2026-07-14", "Stock Brief")

    response = client.get("/api/briefs/stock")
    assert response.status_code == 200
    item = response.json()["briefs"][0]
    assert item["date"] == "2026-07-14"
    assert item["markdown_route"] == "/api/briefs/stock/markdown/2026-07-14"


@pytest.mark.parametrize(
    ("kind", "configured_index", "directory", "stem"),
    [
        ("ai", 1, "__AI-DAILY-BRIEFS", "AI Morning Brief"),
        ("stock", 2, "_STOCK-BRIEFS", "Stock Brief"),
    ],
)
def test_merges_configured_historical_and_current_sandbox_roots(
    briefs_client, kind, configured_index, directory, stem
):
    client, ai_root, stock_root = briefs_client
    configured_root = (client, ai_root, stock_root)[configured_index]
    profile_home = configured_root.parent / "hermes" / "profiles" / "test"
    hermes_root = profile_home.parent.parent

    _write_brief(configured_root, "2026-07-13", stem)
    _write_brief(
        _sandbox_brief_root(hermes_root, "workspace", directory),
        "2026-07-06",
        stem,
    )
    _write_brief(
        _sandbox_brief_root(
            profile_home,
            "home/hermes-built-in-briefs/upstream/web",
            directory,
        ),
        "2026-07-15",
        stem,
    )
    _write_brief(
        _sandbox_brief_root(profile_home, "home", directory),
        "2026-07-14",
        stem,
    )
    _write_brief(
        _sandbox_brief_root(profile_home, "downloads", directory),
        "2026-07-12",
        stem,
    )

    response = client.get(f"/api/briefs/{kind}")

    assert response.status_code == 200
    payload = response.json()
    assert [item["date"] for item in payload["briefs"]] == [
        "2026-07-15",
        "2026-07-14",
        "2026-07-13",
        "2026-07-12",
        "2026-07-06",
    ]
    assert client.get(f"/api/briefs/{kind}/html/2026-07-14").status_code == 200
    assert client.get(f"/api/briefs/{kind}/markdown/2026-07-06").status_code == 200


def test_discovers_global_and_profile_persistent_cron_archives(briefs_client):
    client, ai_root, _ = briefs_client
    profile_home = ai_root.parent / "hermes" / "profiles" / "test"
    hermes_root = profile_home.parent.parent
    _write_brief(
        hermes_root / "zDownloads" / "__AI-DAILY-BRIEFS",
        "2026-07-15",
        "AI Morning Brief",
    )
    _write_brief(
        profile_home / "_STOCK-BRIEFS",
        "2026-07-15",
        "Stock Brief",
    )

    assert client.get("/api/briefs/ai").json()["briefs"][0]["date"] == "2026-07-15"
    assert client.get("/api/briefs/stock").json()["briefs"][0]["date"] == "2026-07-15"


@pytest.mark.parametrize(
    ("kind", "configured_index", "directory", "stem"),
    [
        ("ai", 1, "__AI-DAILY-BRIEFS", "AI Morning Brief"),
        ("stock", 2, "_STOCK-BRIEFS", "Stock Brief"),
    ],
)
def test_sandbox_downloads_root_wins_duplicate_date(
    briefs_client, kind, configured_index, directory, stem
):
    client, ai_root, stock_root = briefs_client
    configured_root = (client, ai_root, stock_root)[configured_index]
    profile_home = configured_root.parent / "hermes" / "profiles" / "test"
    date = "2026-07-14"
    direct_html, _ = _write_brief(
        _sandbox_brief_root(profile_home, "home", directory), date, stem
    )
    downloads_html, _ = _write_brief(
        _sandbox_brief_root(profile_home, "downloads", directory), date, stem
    )
    direct_html.write_text("direct sandbox copy")
    downloads_html.write_text("sandbox downloads copy")

    listing = client.get(f"/api/briefs/{kind}")
    response = client.get(f"/api/briefs/{kind}/html/{date}")

    assert listing.status_code == 200
    assert listing.json()["count"] == 1
    assert response.status_code == 200
    assert response.text == "sandbox downloads copy"


def test_html_is_inline_with_defensive_headers(briefs_client):
    client, ai_root, _ = briefs_client
    html, _ = _write_brief(ai_root, "2026-07-14", "AI Morning Brief")

    response = client.get("/api/briefs/ai/html/2026-07-14")
    assert response.status_code == 200
    assert response.content == html.read_bytes()
    assert response.headers["content-type"].startswith("text/html")
    assert response.headers["content-security-policy"].startswith("sandbox")
    assert response.headers["x-content-type-options"] == "nosniff"
    assert "attachment" not in response.headers.get("content-disposition", "")


def test_markdown_is_an_attachment(briefs_client):
    client, _, stock_root = briefs_client
    _, markdown = _write_brief(stock_root, "2026-07-14", "Stock Brief")

    response = client.get("/api/briefs/stock/markdown/2026-07-14")
    assert response.status_code == 200
    assert response.content == markdown.read_bytes()
    assert response.headers["content-type"].startswith("text/markdown")
    assert "attachment" in response.headers["content-disposition"]
    assert "Stock%20Brief%20-%202026-07-14.md" in response.headers["content-disposition"]


@pytest.mark.parametrize("kind", ["crypto", "AI", "../ai"])
def test_unknown_kind_is_rejected(briefs_client, kind):
    client, _, _ = briefs_client
    response = client.get(f"/api/briefs/{kind}")
    assert response.status_code == 404


@pytest.mark.parametrize("date", ["2026-7-14", "2026-02-30", "../../etc", "not-a-date"])
def test_invalid_date_is_rejected(briefs_client, date):
    client, _, _ = briefs_client
    response = client.get(f"/api/briefs/ai/html/{date}")
    assert response.status_code in {400, 404}


def test_brief_file_symlink_cannot_escape_discovered_root(briefs_client, tmp_path):
    client, ai_root, _ = briefs_client
    date = "2026-07-14"
    directory = ai_root / date
    directory.mkdir(parents=True)
    outside = tmp_path / "outside.html"
    outside.write_text("must not be served")
    (directory / f"AI Morning Brief - {date}.html").symlink_to(outside)

    listing = client.get("/api/briefs/ai")
    response = client.get(f"/api/briefs/ai/html/{date}")

    assert listing.status_code == 200
    assert listing.json()["briefs"] == []
    assert response.status_code == 404


def test_missing_brief_file_returns_404(briefs_client):
    client, ai_root, _ = briefs_client
    (ai_root / "2026-07-14").mkdir(parents=True)
    response = client.get("/api/briefs/ai/html/2026-07-14")
    assert response.status_code == 404
