# Locked Brief templates V32 — AI + Stocks review

This cumulative, read-only review package contains the deterministic AI/Stocks templates, five canonical data payloads per stream, full-dashboard exports, compiled dashboard, and executable verification evidence.

## What V32 changes

### Briefs-AI

- Volume is one persistent player-level preference across all archive dates.
- Moving the volume slider updates the active utterance’s volume only.
- Volume changes never cancel, requeue, restart, scroll, or change the active card.
- Dashboard sandbox frames receive the level from the stable parent.
- Standalone HTML exports use the same volume relay across offline date changes.
- Playback speed, Founder Takeaways, cyclic date navigation, fullscreen, and existing keyboard behavior remain locked.

### Briefs-Stocks

- The producer contract now fetches each ticker directly from Yahoo Chart on every run.
- The freshness gate requires the correct completed market session and one identical session date across all seven tickers.
- Stale, partial, malformed, or cross-session data fails closed; the materializer preserves the last valid archive.
- Friday and Monday reference prices are genuinely different. Saturday carries Friday’s completed session while retaining Friday-versus-Thursday movement.
- Stock quote CSV and Position Comparison CSV files end with `Agent`; every data row contains `HERMES`.

### Exports

- 10 self-contained HTML exports and 10 semantic Markdown exports were rebuilt.
- Five Position Comparison CSV exports and five quote CSV references include `Agent=HERMES`.
- HTML uses the `briefs-v32-inline-cyclic` manifest and contains all CSS/JavaScript inline.

## Review

Double-click:

```text
1_OPEN_BRIEFS_TEMPLATES_V32_REVIEW.command
```

It opens AI and Stocks in Brave on isolated port `9126`. Opening is silent; Play or Space may produce narration.

Stop with:

```text
2_STOP_BRIEFS_TEMPLATES_V32_REVIEW.command
```

Verify checksums and every offline package contract with:

```text
3_VERIFY_BRIEFS_TEMPLATES_V32.command
```

## Evidence

- `EXPORT_AUDIT.json`: hashes and static assertions for all 25 dashboard exports.
- `QA/BROWSER_AUDIT.json`: 37 Chromium checks across dashboard and standalone contexts.
- `QA/DOWNLOAD_PARITY_AUDIT.json`: all 25 live browser downloads byte-identical to bundled exports.
- `QA/*.png`: AI/Stocks dashboard and standalone visual evidence.
- `VERIFICATION_REPORT.md`: consolidated results and safety scope.

## Safety and live state

- This package does not modify production dashboard port `9119`, production UI files, V31, or older packages.
- The active `02_BRIEF-STOCKS` producer prompt was explicitly updated to the deterministic Yahoo/freshness contract requested for the cron defect.
- The installed host materializer remains on its compatible `stock-brief-data-v1` paired-marker contract.
